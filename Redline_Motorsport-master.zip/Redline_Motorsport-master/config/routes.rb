Rails.application.routes.draw do
  devise_for :users, skip: [:sessions], controllers: { omniauth_callbacks: 'users/omniauth_callbacks' }
  as :user do
    get 'signin', to: 'users/omniauth_callbacks#discord_auth', as: :new_user_session
    post 'signin', to: 'devise/sessions#create', as: :user_session
    delete 'signout', to: 'devise/sessions#destroy', as: :destroy_user_session
  end

  devise_scope :user do
    get '/users/omniauth_callbacks/discord_auth', to: 'users/omniauth_callbacks#discord_auth', as: "discord_auth"
  end

  resources :affiliates, only: [:index]

  resources :championships do
    resources :races do
      resources :race_signouts, only: [:create, :destroy]
    end
    
    member do
      get :results
      get :drivers
      get :standings
    end
  end

  resources :games
  resources :incident_reports
  resources :pages, path: '', only: [:index] do
    collection do
      get :calendar
      get :esports
      get :fuel_estimator
      get :privacy_policy
      get :rules
      get :store
      get :terms_of_use
    end
  end

  resources :teams, param: :name do
    member do
      patch :remove_member
    end
  end
  
  resources :team_registrations
  resources :user_championships
  resources :users, param: :username, path: :drivers
  
  namespace :admin do
    resources :affiliates
    resources :championships do
      member do
        get :scoring
      end

      resources :championship_car_classes, only: [:destroy]

      resources :races, only: [:destroy, :edit, :index, :update] do
        member do
          resources :incident_reports, only: [:index, :destroy], shallow: true do
            collection do
              get :text_index
            end
          end

          patch :bulk_update
          delete :destroy_results
        end

        resources :session_incidents do
          member do
            patch :mark_as_reviewed
          end
        end

        resources :session_results

        member do
          post :json_upload
        end
      end

      resources :team_registrations
      resources :user_championships, path: :registrations
    end
    
    resources :games do
      resources :cars
      resources :car_classes
    end

    resources :teams, param: :name
    resources :users, param: :username, path: :drivers
  end

  namespace :api do
    namespace :v1 do
      resources :car_classes, only: [:show] do
        resources :car_class_cars, only: [:index]
        resources :championship_car_class_car_class_cars, only: [:index]
      end

      resources :teams, only: [:show]
    end
  end

  root  'pages#index'
end
