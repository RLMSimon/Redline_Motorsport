# README

## Environment Setup
### Setup DB
```
rake db:create:all
rake db:migrate
rake db:seed
```

### Setup ENV vars
#### local_env.yml Vars
- Create `/config/local_env.yml`
- Insert the following vars
```
DISCORD_APP_ID: [key]
DISCORD_APP_SECRET: [key]
DISCORD_BOT_TOKEN: [key]
RLM_DISCORD_SERVER_ID: [key]
```
#### Rails Credentials
Currently only Backblaze credentials are stored in Rails credentials. This can be edited by running `rails credentials:edit`.
Ultimately we probably want to move all env vars here.

### Start the server
- `rails s`

## Test Suite
### Run rspec
- `rspec`

## Deployment
### Push to Heroku
- `git push heroku master`
