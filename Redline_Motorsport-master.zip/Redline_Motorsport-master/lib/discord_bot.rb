class DiscordBot

  require 'discordrb'

  ADMIN_ROLE       = "531872680572616704"
  WEB_PAGE_CHANNEL = "586946472839217178"
  LOBBY_CHANNEL    = "464522442426286082"
  SIGN_OUT_CHANNEL = "613712387781951498"
  BOT              = Discordrb::Bot.new(token: ENV['DISCORD_BOT_TOKEN'], client_id: ENV['DISCORD_APP_ID'])

  def self.initialize
    BOT.run(:async)
  end

  def self.server_roles
    BOT.server(ENV['RLM_DISCORD_SERVER_ID']).roles
  end

end
