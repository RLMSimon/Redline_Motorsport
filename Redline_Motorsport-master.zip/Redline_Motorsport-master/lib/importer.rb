class Importer

  def self.assetto_corsa(file, race, session_type, car_class_id)
    file               = Importer.parse(file)
    results            = file['Result']
    laps               = file['Laps']
    incidents          = file['Events']
    users              = race.championship.users
    user_championships = race.championship.user_championships
    lap_count          = {}
    incident_types     = { "COLLISION_WITH_CAR" => 0, "COLLISION_WITH_ENV" => 1 }

    laps.group_by{ |l| l["DriverName"] }.each do |lap_group|
      next if lap_group[0].blank?

      user         = users.find_by(steam64_id: lap_group[1][0]["DriverGuid"])
      car_class_id = user_championships.find_by(user: user).try(:car_class_id) || car_class_id

      race.session_laps.create(
        sessionable:   user,
        imported_name: lap_group[0],
        car_class_id:  car_class_id,
        session_type:  session_type,
        times:         lap_group[1].map{ |l| { lap_time: l['LapTime'], sectors: l['Sectors'] }},
      )

      lap_count[lap_group[0].parameterize.to_sym] = lap_group[1].count
    end

    results.each do |result|
      next if result['DriverName'].blank?

      user         = users.find_by(steam64_id: result['DriverGuid'])
      car_class_id = user_championships.find_by(user: user).try(:car_class_id) || car_class_id
      
      if ['race_1', 'race_2', 'race_3'].include?(session_type) && result['TotalTime'].to_i <= 0
        # DNS
        assign_dns_penalty_points(race, user)

        race.session_results.create(
          sessionable:      user,
          imported_name:    result['DriverName'],
          car_class_id:     car_class_id,
          best_lap:         result['BestLap'],
          total_time:       result['TotalTime'],
          session_type:     session_type,
          dns:              true,
          penalty_points:   @penalty_points,
          skip_recalculate: true,
        )
      elsif result['TotalTime'].to_i > 0
        race.session_results.create(
          sessionable:      user,
          imported_name:    result['DriverName'],
          car_class_id:     car_class_id,
          best_lap:         result['BestLap'],
          total_time:       result['TotalTime'],
          session_type:     session_type,
          skip_recalculate: true,
          lap_count:        lap_count[result['DriverName'].parameterize.to_sym].to_i,
        )
      end
    end

    incidents.each do |incident|
      user         = users.find_by(steam64_id: incident['Driver']['Guid'])
      car_class_id = user_championships.find_by(user: user).try(:car_class_id) || car_class_id
      
      race.session_incidents.create(
        sessionable:   user,
        imported_name: incident['Driver']['Name'],
        car_class_id:  car_class_id,
        session_type:  session_type,
        description:   incident['Type'],
        incident_type: incident_types[incident['Type']]
      )
    end

    race.assign_dns_for_missing_registrants!(car_class_id, session_type)
    race.calculate_points(session_type)
  end

  def self.assetto_corsa_competizione(file, race, session_type, car_class_id)
    file                      = Importer.parse(file, 'utf-16le')
    results                   = file["sessionResult"]["leaderBoardLines"]
    laps                      = file["laps"]
    championship              = race.championship
    participants              = championship.participants
    participant_registrations = championship.participant_registrations

    laps.group_by{ |l| l["carId"] }.each do |lap_group|
      result = results.select{ |r| r["car"]['carId'] == lap_group[0] }.first
      next unless result.present?

      if championship.teams_enabled?
        user = User.find_by(steam64_id: result["currentDriver"]["playerId"].split('S')[1])
        if user.present?
          participant = championship.team_registration_by_user(user).try(:team)
          if participant.present?
            car_class_id = participant_registrations.find_by(team: participant).try(:car_class_id) || car_class_id
          end
        end
      else
        participant  = championship.users.find_by(steam64_id: result["currentDriver"]["playerId"].split('S')[1])
        car_class_id = participant_registrations.find_by(user: participant).try(:car_class_id) || car_class_id
      end

      race.session_laps.create(
        sessionable:   participant,
        imported_name: [result["currentDriver"]["firstName"], result["currentDriver"]["lastName"]].join(' '),
        car_class_id:  car_class_id,
        session_type:  session_type,
        times:         lap_group[1].map{ |l| { lap_time: l['laptime'], sectors: l['splits'] }},
      )
    end

    results.each do |result|
      if championship.teams_enabled?
        user         = User.find_by(steam64_id: result["currentDriver"]["playerId"].split('S')[1])
        # FIXME: May be able to retrieve this from teamName if Kunos plans to fill this field. Pending response from Kevin.
        if user.present?
          participant = championship.team_registration_by_user(user, true).try(:team)
          if participant.present?
            car_class_id = championship.team_registrations.find_by(team: participant).try(:car_class_id) || car_class_id
          end
        end
      else
        participant  = championship.users.find_by(steam64_id: result["currentDriver"]["playerId"].split('S')[1])
        car_class_id = championship.user_championships.find_by(user: participant).try(:car_class_id) || car_class_id
      end

      if ['race_1', 'race_2', 'race_3'].include?(session_type) && (result['timing']['totalTime'].to_i <= 0)
        # DNS
        assign_dns_penalty_points(race, participant)

        race.session_results.create(
          sessionable:      participant,
          imported_name:    [result["currentDriver"]["firstName"], result["currentDriver"]["lastName"]].join(' '),
          car_class_id:     car_class_id,
          best_lap:         result['timing']['bestLap'],
          total_time:       result['timing']['totalTime'],
          lap_count:        result['timing']['lapCount'],
          session_type:     session_type,
          dns:              true,
          penalty_points:   @penalty_points,
          skip_recalculate: true,
        )
      elsif (result['timing']['totalTime'].to_i > 0) && (result['timing']['lapCount'].to_i > 0)
        race.session_results.create(
          sessionable:      participant,
          imported_name:    [result["currentDriver"]["firstName"], result["currentDriver"]["lastName"]].join(' '),
          car_class_id:     car_class_id,
          best_lap:         result['timing']['bestLap'],
          total_time:       result['timing']['totalTime'],
          lap_count:        result['timing']['lapCount'],
          session_type:     session_type,
          skip_recalculate: true,
        )
      end
    end

    race.assign_dns_for_missing_registrants!(car_class_id, session_type)
    race.calculate_points(session_type)
  end

  def self.project_cars_2(file, race, session_type, car_class_id)
    file           = Importer.parse(file)
    history        = file['stats']['history']
    quali_session  = history[0]['stages']['qualifying1'] || history[1]['stages']['qualifying1']
    race_session   = history[0]['stages']['race1'] || history[1]['stages']['race1']
    car_class_id  ||= race.championship.championship_car_classes.first.try(:car_class_id)
    # incident_types = { "COLLISION_WITH_CAR" => 0, "COLLISION_WITH_ENV" => 1 }

    quali_session['results'].each do |result|
      user         = race.championship.users.find_by(steam_username: result['name'])
      car_class_id = race.championship.user_championships.find_by(user: user).try(:car_class_id) || car_class_id

      if result['attributes']['FastestLapTime'].to_i > 0
        race.session_results.create(
          sessionable:   user,
          imported_name: result['name'],
          car_class_id:  car_class_id,
          best_lap:      result['attributes']['FastestLapTime'].to_i,
          session_type: 'qualifying',
        )
      end
    end

    race_session['results'].each do |result|
      user         = race.championship.users.find_by(steam_username: result['name'])
      car_class_id = race.championship.user_championships.find_by(user: user).try(:car_class_id) || car_class_id

      if result["attributes"]['State'] == 'DidNotStart'
        # DNS
        assign_dns_penalty_points(race, user)

        race.session_results.create(
          sessionable:      user,
          imported_name:    result['name'],
          car_class_id:     car_class_id,
          best_lap:         result['attributes']['FastestLapTime'],
          total_time:       result['attributes']["TotalTime"],
          session_type:     'race_1',
          dns:              true,
          penalty_points:   @penalty_points,
          lap_count:        result['attributes']['Lap'].to_i,
          skip_recalculate: true,
        )
      else
        race.session_results.create(
          sessionable:      user,
          imported_name:    result['name'],
          car_class_id:     car_class_id,
          best_lap:         result['attributes']['FastestLapTime'],
          total_time:       result['attributes']["TotalTime"],
          dnf:              result["FinishStatus"] == 'DidNotFinish',
          session_type:     'race_1',
          lap_count:        result['attributes']['Lap'].to_i,
          skip_recalculate: true,
        )
      end
    end

    race.assign_dns_for_missing_registrants!(car_class_id, 'race_1')
    race.calculate_points('race_1')
  end

  def self.raceroom(file, race, session_type, car_class_id)
    file            = Importer.parse(file)
    quali_session   = file["Sessions"].select{ |k| k["Type"] == 'Qualify' }
    race_session    = file["Sessions"].select{ |k| k["Type"] == 'Race' }
    race_session_2  = file["Sessions"].select{ |k| k["Type"] == 'Race2' }
    car_class_id  ||= race.championship.championship_car_classes.first.try(:car_class_id)
    incident_types = { 0 => "Car to car collision", 1 => "Collision with a track object",
      3 => "Going off track", 5 => "Losing control of the vehicle",
      6 => "Not serving a penalty", 7 => "Disconnecting / Giving up before the end of a race" }

    quali_session[0]["Players"].each do |player|
      user         = race.championship.users.find_by(raceroom_username: player["FullName"])
      car_class_id = race.championship.user_championships.find_by(user: user).try(:car_class_id) || car_class_id
      
      if player["BestLapTime"].to_i > 0
        race.session_results.create(
          sessionable:   user,
          imported_name: player['FullName'],
          car_class_id:  car_class_id,
          best_lap:      player["BestLapTime"],
          session_type: 'qualifying',
        )

        race.session_laps.create(
          sessionable:   user,
          imported_name: player['FullName'],
          car_class_id:  car_class_id,
          session_type:  'qualifying',
          times:         player["RaceSessionLaps"].map{ |l| { lap_time: l['Time'], sectors: l['SectorTimes'] }},
        )

        player["RaceSessionLaps"].each_with_index do |lap, i|
          next unless lap["Time"].to_i > 0

          lap["Incidents"].each do |incident|
            race.session_incidents.create(
              sessionable:   user,
              imported_name: player['FullName'],
              car_class_id:  car_class_id,
              session_type:  'qualifying',
              description:   "Lap: #{i+1}, Points: #{incident['Points']}, #{incident_types[incident['Type']]}",
              incident_type: incident['Type']
            )
          end
        end
      end
    end


    [race_session, race_session_2].each_with_index do |rs, i|
      next unless rs.present? # Don't process if session did not take place.

      race_number = "race_#{i+1}"

      rs[0]["Players"].each do |player|
        user         = race.championship.users.find_by(raceroom_username: player["FullName"])
        car_class_id = race.championship.user_championships.find_by(user: user).try(:car_class_id) || car_class_id

        if player["FinishStatus"] == 'DidNotStart'
          # DNS
          assign_dns_penalty_points(race, user)

          race.session_results.create(
            sessionable:      user,
            imported_name:    player['FullName'],
            car_class_id:     car_class_id,
            best_lap:         player["BestLapTime"],
            total_time:       player["TotalTime"],
            session_type:     race_number,
            dns:              true,
            penalty_points:   @penalty_points,
            lap_count:        player["RaceSessionLaps"].count,
            skip_recalculate: true,
          )
        else
          race.session_results.create(
            sessionable:      user,
            imported_name:    player['FullName'],
            car_class_id:     car_class_id,
            best_lap:         player["BestLapTime"],
            total_time:       player["TotalTime"],
            dnf:              player["FinishStatus"] == 'DidNotFinish',
            session_type:     race_number,
            lap_count:        player["RaceSessionLaps"].count,
            skip_recalculate: true,
          )

          race.session_laps.create(
            sessionable:   user,
            imported_name: player['FullName'],
            car_class_id:  car_class_id,
            session_type:  race_number,
            times:         player["RaceSessionLaps"].map{ |l| { lap_time: l['Time'], sectors: l['SectorTimes'] }},
          )

          player["RaceSessionLaps"].each_with_index do |lap, i|
            next unless lap["Time"].to_i > 0

            lap["Incidents"].each do |incident|
              race.session_incidents.create(
                sessionable:   user,
                imported_name: player['FullName'],
                car_class_id:  car_class_id,
                session_type:  race_number,
                description:   "Lap: #{i+1}, Points: #{incident['Points']}, #{incident_types[incident['Type']]}",
                incident_type: incident['Type']
              )
            end
          end
        end
      end

      race.assign_dns_for_missing_registrants!(car_class_id, race_number)
      race.calculate_points(race_number)
    end
  end

  def self.rfactor_2(file, race, session_type, car_class_id)
    file = Importer.parse(file, 'iso-8859-1')

    if session_type == 'qualifying'
      quali_session = file['rFactorXML']['RaceResults']['Qualify']
      drivers       = quali_session['Driver']
      
      drivers.each do |driver|
        user         = race.championship.users.find_by(rfactor_2_name: driver["Name"])
        car_class_id = race.championship.user_championships.find_by(user: user).try(:car_class_id) || car_class_id
        
        if driver["BestLapTime"].to_i > 0
          race.session_results.create(
            sessionable:   user,
            imported_name: driver['Name'],
            car_class_id:  car_class_id,
            best_lap:      driver["BestLapTime"].to_f * 1000,
            session_type: 'qualifying',
          )
        end
      end
    elsif ['race_1', 'race_2', 'race_3'].include?(session_type)
      race_session = file['rFactorXML']['RaceResults']['Race']
      drivers      = race_session['Driver']
      
      drivers.each do |driver|
        user         = race.championship.users.find_by(rfactor_2_name: driver["Name"])
        car_class_id = race.championship.user_championships.find_by(user: user).try(:car_class_id) || car_class_id

        if driver['FinishStatus'] == 'DNS'
          # DNS
          assign_dns_penalty_points(race, user)

          race.session_results.create(
            sessionable:      user,
            imported_name:    driver['Name'],
            car_class_id:     car_class_id,
            best_lap:         driver['BestLapTime'].to_f * 1000,
            total_time:       driver['FinishTime'].to_f * 1000,
            session_type:     session_type,
            dns:              true,
            penalty_points:   @penalty_points,
            lap_count:        driver['Laps'].to_i,
            skip_recalculate: true,
          )
        else
          race.session_results.create(
            sessionable:      user,
            imported_name:    driver['Name'],
            car_class_id:     car_class_id,
            best_lap:         driver['BestLapTime'].to_f * 1000,
            total_time:       driver['FinishTime'].to_f * 1000,
            dnf:              driver['FinishStatus'] == 'DNF',
            session_type:     session_type,
            lap_count:        driver['Laps'].to_i,
            skip_recalculate: true,
          )
        end
      end

      race.assign_dns_for_missing_registrants!(car_class_id, session_type)
      race.calculate_points(session_type)
      
      race_session['Stream']['Incident'].each do |incident|
        race.session_incidents.create(
          session_type: session_type,
          car_class_id: car_class_id,
          description:  incident,
        )
      end
    end
  end

  private

  # We are intentionally assigning DNS penalty points here during import rather than during
  # Race#calculate_points so that penalties can be manually managed by admins; otherwise any
  # changed values would be overwritten when the session_result record was next saved.
  def self.assign_dns_penalty_points(race, participant=nil)
    @penalty_points = 0
    
    return if participant.blank? || race.warm_up?

    registration    = race.championship.registration_record(participant.id)
    @penalty_points = race.race_signouts.where(signoutable: registration).present? ? 0 : race.championship.missed_race_penalty.to_i
  end

  def self.parse(file, encoding='utf-8')
    case file.content_type
    when "application/json"
      JSON.parse(file.read.force_encoding(encoding))
    when "text/xml"
      Hash.from_xml(Nokogiri.XML(file.read, nil, encoding).to_s)
    end
  end

end
