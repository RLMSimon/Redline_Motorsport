function fetchCarsFromClass(car_select, selected_class_id, championship_id) {
  var html = "<option value=''>Select a Car</option>";

  $.get("/api/v1/car_classes/" + selected_class_id + "/championship_car_class_car_class_cars?championship_id=" + championship_id, function(data) {
    $.each(data, function(i, cccccc) {
      html += "<option value='" + cccccc.car_id + "'>" + cccccc.car_name + "</option>";
    });

    car_select.html(html);
  });
};
