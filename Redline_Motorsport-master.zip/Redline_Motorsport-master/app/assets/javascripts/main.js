$(document).on('turbolinks:load', function() {

  $('[data-toggle="tooltip"]').on('hover', function(){
    $(this).tooltip('show')
  })

  $('[data-toggle="tooltip"]').on('click', function(){
    $(this).tooltip('hide')
  })

  $('[data-toggle="tooltip"]').tooltip();

  $('a.disabled').click(function(e) {
    e.preventDefault();
  });

});
