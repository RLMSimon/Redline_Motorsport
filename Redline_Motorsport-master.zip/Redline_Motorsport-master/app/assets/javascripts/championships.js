function addClass() {
  var new_row = $('#classGroup li').last().clone();
  new_row.find('input, select').each(function() {
    // Update all the inputs and attrs with the `id` from our new record.
    $(this).attr('name', $(this).attr('name').replace(/\d+/, null));
    $(this).val(null);
  });

  new_row.find('a.collapse-link').attr('href', '#collapse' + (new_row.attr('data-id')));
  new_row.find('div.collapse').attr('id', 'collapse' + new_row.attr('data-id'));
  new_row.attr('data-id', null);
  new_row.find('a').last().addClass('removeClass');
  new_row.find('a').last().attr('data-confirm', null);
  new_row.find('a').last().attr('href', 'javascript:void(0);');
  new_row.css('display', 'none');
  new_row.appendTo($('#classGroup'));
  new_row.slideDown();
};

function autofillScores(element) {
  var inputs          = $('input[name="championship[score_matrix][]"]');
  var total_positions = inputs.length;
  var point_value     = 0;

  if(element.data('autofill-type') == 'linear') {
    for(var i=0; i<total_positions; ++i) {
      ++point_value;
      
      $(inputs[total_positions-(i+1)]).val(point_value);
    };
  } else if(element.data('autofill-type') == 'progressive') {
    for(var i=0; i<total_positions; ++i) {
      if((total_positions - i) <= 3) {
        point_value = point_value + 3 + (3 - (total_positions - i - 1));
      } else if(i > (total_positions * 0.666)) {
        point_value = point_value + 3;
      } else if(i > (total_positions * 0.333)) {
        point_value = point_value + 2;
      } else {
        ++point_value;
      }

      $(inputs[total_positions-(i+1)]).val(point_value);
    };
  }
};

$(document).on('turbolinks:load', function() {
  
  $('.scoring-autofill').click(function() {
    autofillScores($(this));
  });

  $('#addClass').click(function() {
    addClass();
  });

  $('div').on('click', 'a.removeClass', function() {
    $(this).parents('li.list-group-item').slideUp(400, function() {
      $(this).remove();
    });
  });

  $('#classGroup').on('change', '.car-class-select', function() {
    var select                    = $(this);
    var selected_car_class_id     = select.val();
    var championship_car_class_id = select.parents('li.list-group-item').data('id') || null;

    $.get("/api/v1/car_classes/" + selected_car_class_id + "/car_class_cars.json", function(data) {
      var html = "<input type='hidden' name='championship[championship_car_classes_attributes][" + championship_car_class_id + "][car_class_car_ids][]' value=''>"
      
      $.each(data, function(i, car_class_car) {
        html += "<label class='btn btn-secondary btn-sm mb-1 mr-1 checkable' for='championship_championship_car_classes_attributes_" + championship_car_class_id + "_car_class_car_ids_" + car_class_car.id + "'><input type='checkbox' value='" + car_class_car.id + "' name='championship[championship_car_classes_attributes][" + championship_car_class_id + "][car_class_car_ids][]' id='championship_championship_car_classes_attributes_" + championship_car_class_id + "_car_class_car_ids_" + car_class_car.id + "'>" + car_class_car.name + "</label>";
      });

      select.parents('li.list-group-item').find('.car-class-car-ids-inputs').first().html(html);
    });
  });

});
