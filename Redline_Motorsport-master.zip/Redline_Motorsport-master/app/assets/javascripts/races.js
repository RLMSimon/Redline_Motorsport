function convert_time_to_ms(time_string) {
  var min = parseInt(time_string.split(':')[0]);
  var sec = parseFloat(time_string.split(':')[1]);

  return parseInt(((min * 60) + sec) * 1000);
};

function highlightFastest(column) {
  var columnNo = $(column).index();
  var rows     = $(column).closest("table").find("tr td:nth-child(" + (columnNo+1) + ")");
  rows         = rows.filter(function(i, elem) { return parseInt($(elem).data('milliseconds')) > 0 });

  rows.sort(function(a, b) {
    return $(a).data('milliseconds') > $(b).data('milliseconds');
  }).first().addClass('bg-danger');
};

$(document).on('turbolinks:load', function() {
  $('#session_result_best_lap, #session_result_total_time').change(function() {
    if($(this).val().includes(':')) {
      $(this).val(convert_time_to_ms($(this).val()));
    };
  });

  $('#filter_class').change(function() {
    $(this).parents('form').submit();
  });

  $(".highlight-fastest").each(function() {
    highlightFastest($(this));
  });

  $(".anytime_picker").AnyTime_picker({
    format:          "%Y-%m-%d %H:%i %:",
    formatUtcOffset: "%: (%@)",
    labelDayOfMonth: 'Day',
  });
});
