class SessionLap < ApplicationRecord
  
  include Sessionable

end
