class CarClassCar < ApplicationRecord

  belongs_to(:car)
  belongs_to(:car_class)

  has_many :championship_car_class_car_class_cars
  has_many :car_class_cars, through: :championship_car_class_car_class_cars

  validates_uniqueness_of(:car_id, scope: :car_class_id)

  def name
    car.name
  end

end
