class Affiliate < ApplicationRecord

  validates_presence_of(:name)
  validates_presence_of(:url)

  def image_path
    return "affiliates/thumbnail/#{name.parameterize}.jpg"
  end

end
