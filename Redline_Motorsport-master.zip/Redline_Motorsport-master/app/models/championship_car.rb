class ChampionshipCar < ApplicationRecord

  belongs_to :championship
  belongs_to :car

  validates_uniqueness_of(:car_id, scope: :championship_id)

end
