class Car < ApplicationRecord

  has_many :car_class_cars
  has_many :car_classes, through: :car_class_cars
  has_many :championship_cars, dependent: :destroy
  has_many :user_championships, dependent: :destroy

  belongs_to :championship, optional: true
  belongs_to :game

  validates_presence_of(:name)
  validates_uniqueness_of(:name, scope: :game_id)

end
