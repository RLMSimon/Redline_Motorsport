class UserChampionship < ApplicationRecord

  include Registratable

  require 'csv'
  
  belongs_to :user

  validates_presence_of(:car_class)

  validates_uniqueness_of(:car_number, scope: :championship_id, if: -> { championship.try(:game).try(:require_unique_livery) })
  validates_uniqueness_of(:user, scope: :championship_id, message: 'has already joined this championship.')

  validate :must_not_have_missing_attributes

  after_save    :handle_unregistration!, if: ->(uc){ uc.saved_change_to_attribute?(:disqualified, { from: false, to: true }) }
  after_create  :role_add
  after_create  :notify_admins_of_sign_in
  # before_destroy :ensure_destroyable
  after_destroy :handle_unregistration!
  after_destroy :notify_admins_of_sign_out

  def self.to_csv(user_championships)
    CSV.generate do |csv|
      csv << ['username', 'real name', 'steam64', 'car number', 'car name', 'registered at']

      user_championships.each do |uc|
        next if uc.user.blank?

        csv << [
          uc.user.username,
          uc.user.real_name,
          uc.user.steam64_id,
          uc.car_number,
          uc.car.name,
          uc.created_at,
        ]
      end
    end
  end

  def role_add
    return unless !reserve?

    if championship.present? && championship.role_id.present?
      message = "You have been added to #{championship.name}!"
      user.discord_role_add(championship.role_id, message)
    end

    if championship.try(:game).present? && championship.game.role_id.present?
      message = "You have been added to #{championship.game.name}!"
      user.discord_role_add(championship.game.role_id, message)
    end
  end

  def role_remove
    message = "You have been removed from #{championship.name}."
    user.discord_role_remove(championship.role_id, message)

    next_reserve = championship.next_reserve_driver_in_class(car_class)

    if next_reserve.present?
      if championship.try(:game).present? && championship.game.role_id.present?
        message = "You have been added to #{championship.game.name}!"
        next_reserve.discord_role_add(championship.game.role_id, message)
      end
    end
  end

  private

  # TODO: Known issue, awaiting answer to: https://stackoverflow.com/questions/57128873/before-destroy-callback-in-rails-5-throwabort-but-also-modify-record?noredirect=1#comment100774932_57128873
  def ensure_destroyable
    unless self.destroyable?
      self.update(disqualified: true)
      throw(:abort)
    end
  end

  def handle_unregistration!
    self.role_remove

    # Promote next reserve
    reserve = championship.next_reserve_driver_in_class(car_class)
    championship.user_championships.find_by(user_id: reserve.id).update(reserve: false) if reserve.present?

    self.notify_admins_of_sign_out
  end

  def must_not_have_missing_attributes
    if user && championship && user.missing_attributes_for(championship.game).present?
      errors.add(:base, "You must supply additional information.")
    end
  end

end
