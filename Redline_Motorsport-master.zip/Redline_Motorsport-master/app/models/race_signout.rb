class RaceSignout < ApplicationRecord

  belongs_to :race
  belongs_to :signoutable, polymorphic: true

  validate :user_must_have_available_signouts

  after_create :notify

  def can_sign_back_in?
    race.starts_at > Time.now
  end

  private

  def notify
    return unless Rails.env.production?

    message = ":door: #{signoutable.user.username} signed out of #{race.track} for #{signoutable.championship.name}"
    DiscordBot::BOT.send_message(DiscordBot::SIGN_OUT_CHANNEL, message)
  end

  def user_must_have_available_signouts
    unless signoutable && signoutable.signouts_remaining > 0
      errors.add(:base, "You have used up all of your signouts.")
    end
  end

end
