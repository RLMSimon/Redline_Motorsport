class Game < ApplicationRecord

  has_many :cars, dependent: :destroy
  has_many :car_classes, dependent: :destroy
  has_many :championships, dependent: :destroy

end
