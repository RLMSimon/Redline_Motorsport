class IncidentReport < ApplicationRecord

  belongs_to :race
  belongs_to :user
  # belongs_to :driver_a, class_name: 'User'
  # belongs_to :driver_b, class_name: 'User', optional: true
  # belongs_to :driver_c, class_name: 'User', optional: true
  # belongs_to :driver_d, class_name: 'User', optional: true

  has_one :championship, through: :race

  validates_presence_of(:description)
  validates_presence_of(:video_url)

  validate :ensure_reportable, on: :create
  validate :ensure_user_registered_for_championship, on: :create

  # Need to define these dynamically as the association type is dynamic.
  [:driver_a, :driver_b, :driver_c, :driver_d].each do |driver|
    define_method(driver) do
      model = championship.teams_enabled? ? 'Team' : 'User'
      model.constantize.find_by(id: send("#{driver.to_s}_id"))
    end
  end

  REPORTING_WINDOW_HOURS = 26

  private

  def ensure_reportable
    unless race.try(:reportable?)
      errors.add(:base, "The reporting window is closed.")
    end
  end

  def ensure_user_registered_for_championship
    unless race && race.championship && race.championship.user_registered?(user)
      errors.add(:base, "You are not registered for this Championship.")
    end
  end

end

