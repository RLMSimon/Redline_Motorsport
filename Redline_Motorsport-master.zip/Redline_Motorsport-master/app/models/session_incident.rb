class SessionIncident < ApplicationRecord

  include Sessionable

  scope :car_accidents, -> { where(incident_type: 0) }

end
