class ChampionshipCarClass < ApplicationRecord

  belongs_to(:championship)
  belongs_to(:car_class)

  has_many :championship_car_class_car_class_cars, dependent: :destroy
  has_many :car_class_cars, through: :championship_car_class_car_class_cars, dependent: :destroy

  validates_uniqueness_of(:car_class, scope: :championship_id)

end
