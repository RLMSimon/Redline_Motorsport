class Race < ApplicationRecord

  belongs_to :championship, counter_cache: true

  has_many :incident_reports, dependent: :destroy
  has_many :race_signouts, dependent: :destroy
  has_many :session_incidents, dependent: :destroy
  has_many :session_laps, dependent: :destroy
  has_many :session_results, dependent: :destroy

  validates_presence_of :starts_at
  validates_presence_of :track

  def assign_dns_for_missing_registrants!(car_class_id, session_type)
    car_class           = CarClass.find(car_class_id)
    active_registrants  = championship.registrants_by_class(car_class).where(reserve: false).map(&"#{championship.teams_enabled? ? 'team' : 'user'}".to_sym)
    participants        = session_results.where(car_class: car_class).send(session_type).map(&:sessionable).compact
    missing_registrants = active_registrants - participants

    missing_registrants.each do |registrant|
      championship_registration = championship.registration_record(registrant.id)
      next if race_signouts.where(signoutable: championship_registration).present?

      session_results.create(
        sessionable:      registrant,
        car_class_id:     car_class_id,
        session_type:     session_type,
        dns:              true,
        penalty_points:   championship.missed_race_penalty.to_i,
        skip_recalculate: true,
      )
    end
  end

  def calculate_points(session_type)
    return if warm_up?

    championship.car_classes.each do |cc|
      ignore_result_count = 0

      session_results.where(car_class: cc).send(session_type).order_by_race_position.each_with_index do |result, i|
        if result.dns? || result.dnf?
          points = 0
          ignore_result_count += 1
        else
          index_offset = i - ignore_result_count
          points = championship.score_matrix[index_offset].to_i
        end

        # Store result points.
        # Intentionally bypassing callbacks here to prevent recursion.
        points_total = points - result.penalty_points.to_i + ((result.is_fastest_lap? && !result.dnf? && !result.dns?) ? championship.fastest_lap_bonus : 0)

        result.update_columns({
          points_given:   points,
          points_total:   points_total,
          position_cache: i+1,
          fastest_lap:    result.is_fastest_lap?,
        })

        # Calculate and store Championship standings.
        championship.calculate_participant_standings(result.sessionable_id) if result.sessionable_id
      end

      # Store position_cache
      championship.participant_registrations.where(car_class: cc).order(championship_score: :desc).each_with_index do |registration, i|
        registration.update_column(:position_cache, i+1)
      end
    end
  end

  def ended?
    (starts_at + 1.hour) < Time.now
  end

  def post_reminder
    role    = DiscordBot::BOT.server(ENV['RLM_DISCORD_SERVER_ID']).role(championship.role_id)
    message = "#{role.try(:mention)} #{championship.name} Round ##{self.round} starts soon! If you need to sign out, please do so as soon as possible. #{Rails.application.routes.url_helpers.championship_races_url(championship, host: 'www.redlinemotorsport.co.uk')}"
    
    DiscordBot::BOT.send_message(DiscordBot::LOBBY_CHANNEL, message)
  end

  def reportable?
    (starts_at < Time.now) && (starts_at + IncidentReport::REPORTING_WINDOW_HOURS.hours > Time.now)
  end

  def round
    return unless championship.present?
    championship.races.order(starts_at: :asc).index(self).to_i + 1
  end

  def starts_at_date
    starts_at&.strftime('%m/%d/%Y')
  end

  def starts_at_time
    starts_at&.strftime('%H:%M')
  end
  
end
