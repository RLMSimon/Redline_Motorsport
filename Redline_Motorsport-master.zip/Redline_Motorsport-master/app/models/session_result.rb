class SessionResult < ApplicationRecord

  include Sessionable

  after_save :recalculate_points

  attr_accessor :skip_recalculate

  scope :order_by_race_position, -> { order(dnf: :asc, dns: :asc, lap_count: :desc, total_time: :asc) }

  def self.order_by_position(session_type, options={})
    # Points not assigned so we just use the positioning.
    if !['practice', 'qualifying'].include?(session_type) && options[:warm_up] == true
      return self.order_by_race_position
    end

    position_hash = SessionResult.position_sort(session_type, { warm_up: options[:warm_up] })
    self.order("#{position_hash[:attr]} #{position_hash[:dir]}")
  end

  def self.position_sort(session_type, options={})
    if options[:warm_up] == true
      return { attr: 'total_time', gap_attr: 'total_time', dir: 'ASC' }
    end

    case session_type
    when 'practice', 'qualifying'
      { attr: 'best_lap', gap_attr: 'best_lap', dir: 'ASC' }
    when 'race_1', 'race_2', 'race_3'
      { attr: 'points_total', gap_attr: 'total_time', dir: 'DESC' }
    end
  end

  def best_sector_time(sector)
    race.session_laps.where(sessionable: sessionable).pluck(:times).flatten.map{ |l| l['sectors'][sector] if l['sectors'][1].to_i > 0 }.compact.min
  end

  def gap_to_leader(session_type, class_id, leader=nil)
    position_sort = SessionResult.position_sort(session_type)
    dir           = ['race_1', 'race_2', 'race_3'].include?(session_type) ? 'ASC' : position_sort[:dir]
    leader        ||= self.sibling_results.where(car_class_id: class_id).order("#{position_sort[:gap_attr]} #{dir}").first
    lap_diff      = leader.lap_count.to_i - self.lap_count.to_i

    if position(position_sort, class_id) == 1
      # P1
      gap = 0
    else
      if leader
        gap = self.send(position_sort[:gap_attr]).to_i - leader.send(position_sort[:gap_attr]).to_i
      else
        gap = 0
      end
    end

    if (dnf? || dns?) && race?
      return "DNS" if dns?
      return "DNF" if dnf?
    elsif (lap_diff > 0) && race?
      return "+#{lap_diff} Laps"
    else
      return "+" + '%.3f' % (gap / 1000.0)
    end
  end

  def is_fastest_lap?
    return false unless total_time.to_i > 0
    sibling_results(true).where('total_time > 0').order(dnf: :asc, best_lap: :asc).index(self) == 0
  end

  def position(attribute, class_id)
    sibling_results
    .where(car_class_id: class_id)
    .order("#{attribute[:attr]} #{attribute[:dir]}")
    .index(self).to_i + 1
  end

  def race?
    ['race_1', 'race_2', 'race_3'].include?(session_type)
  end

  def sibling_results(in_class=false)
    results = self.race.session_results.safe_send(SessionResult.session_types.keys, session_type)
    
    if in_class
      results = results.where(car_class: self.car_class)
    end

    return results
  end

  private

  def recalculate_points
    if self.race? && !skip_recalculate
      self.race.calculate_points(session_type)
    end
  end

end
