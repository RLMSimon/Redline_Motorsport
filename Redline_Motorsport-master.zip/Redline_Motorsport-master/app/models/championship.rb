class Championship < ApplicationRecord

  belongs_to :game

  has_many :races, dependent: :destroy
  has_many :team_registrations, dependent: :destroy
  has_many :teams, through: :team_registrations, dependent: :destroy
  has_many :team_members, through: :teams, dependent: :destroy
  has_many :user_championships, dependent: :destroy
  has_many :users, through: :user_championships, dependent: :destroy
  has_many :championship_car_classes, dependent: :destroy
  has_many :championship_car_class_car_class_cars, through: :championship_car_classes
  has_many :car_classes, through: :championship_car_classes
  has_many :legacy_cars, foreign_key: "championship_id", class_name: "Car" # TODO: Delete me

  scope :active, -> { where(active: true) }
  scope :inactive, -> { where(active: false) }
  scope :events, -> { where('races_count = 1') }
  scope :full_championships, -> { where('races_count > 1') }

  accepts_nested_attributes_for(:championship_car_classes)
  accepts_nested_attributes_for(:races)

  has_one_attached :backblaze_image

  def calculate_participant_standings(participant_id)
    participant = (teams_enabled? ? 'Team' : 'User').constantize.find(participant_id)

    if teams_enabled?
      participant_registration = self.team_registrations.find_by(team_id: participant_id)
    else
      participant_registration = self.user_championships.find_by(user_id: participant_id)
    end

    results        = SessionResult.where(race_id: races.where(warm_up: false).map(&:id)).where(session_type: ['race_1', 'race_2', 'race_3'], sessionable_id: participant_id)
    points_given   = results.sum{ |sr| sr.points_given.to_i }
    penalty_points = results.sum{ |sr| sr.penalty_points.to_i }
    score          = results.sum{ |sr| sr.points_total.to_i }

    if participant_registration.present?
      participant_registration.update({
        championship_points:    points_given,
        championship_penalties: penalty_points,
        championship_score:     score,
      })
    end

    session_results = participant.session_results.where(session_type: ['race_1', 'race_2', 'race_3'])
    participant.update_columns({
      total_races_started: session_results.count,
      total_wins:          session_results.where(position_cache: 1).count,
      total_podiums:       session_results.where('position_cache <= 3').count,
      total_penalty_rate:  (session_results.sum(:penalty_points).to_i / (session_results.present? ? session_results.count : 1)).to_f.round(2),
    })

    if participant_registration.present? && (penalty_points >= self.max_penalties) && !participant_registration.disqualified?
      participant_registration.update(disqualified: true)
    end
  end

  def capacity
    championship_car_classes.sum(&:capacity)
  end

  def capacity_by_class(car_class)
    championship_car_classes.find_by(car_class: car_class).try(:capacity).to_i
  end
  
  def capacity_met?(registration)
    self.reload if self.persisted? # Ensure race conditions are not an issue.

    _capacity = capacity_by_class(registration.car_class).to_i
    return true if _capacity == 0
    return false if registration.disqualified? || participant_registrations.blank?
    participant_registrations.qualified.where(reserve: false, car_class: registration.car_class).count >= _capacity
  end

  def cars
    championship_car_class_car_class_cars.collect{ |cccccc| cccccc.car_class_car.car }
  end

  def ended?
    races.order(starts_at: :asc).last.try(:ended?)
  end

  def multiclass?
    championship_car_classes.count > 1
  end

  def next_reserve_driver_in_class(car_class)
    user_championships.
    qualified.
    where(reserve: true).
    where(car_class: car_class).
    order(created_at: :asc).first.try(:user)
  end

  # TODO: DRY this up.
  def next_reserve_team_in_class(car_class)
    team_registrations.
    qualified.
    where(reserve: true).
    where(car_class: car_class).
    order(created_at: :asc).first.try(:team)
  end

  def next_upcoming_race
    races.order(starts_at: :asc).where('starts_at > ?', Time.now).first
  end
  
  def participants
    teams_enabled? ? teams : users
  end

  def participant_registrations
    teams_enabled? ? team_registrations : user_championships
  end

  def race_day
    return unless races.present?
    races.first.starts_at.strftime("%A")
  end

  def registration_record(object_id)
    if teams_enabled?
      team_registrations.find_by(team_id: object_id)
    else
      user_championships.find_by(user_id: object_id)
    end
  end

  def registration_record_from_user(user_id)
    if teams_enabled?
      team_registration_by_user(User.find(user_id))
    else
      user_championships.find_by(user_id: user_id)
    end
  end

  def registrants_by_class(car_class)
    if teams_enabled?
      team_registrations.where(car_class: car_class, disqualified: false)
    else
      user_championships.where(car_class: car_class, disqualified: false)
    end
  end

  def start_date
    races.order(starts_at: :asc).first.try(:starts_at)
  end

  def started?
    start_date && start_date < Time.now
  end

  def team_registration_by_user(user, participating_only=false)
    _registrations = team_registrations.where("team_id IN (?)", user.teams.pluck(:id))

    if participating_only
      # FIXME: An SQL-only call here would be ideal.
      _registrations = _registrations.select{ |r| r.participating_driver_ids.include?(user.id.to_s) }
    end

    _registrations.first
  end

  def user_registered?(user)
    registration_record_from_user(user.id).present?
  end

end
