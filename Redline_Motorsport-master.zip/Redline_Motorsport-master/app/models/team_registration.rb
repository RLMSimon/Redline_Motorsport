class TeamRegistration < ApplicationRecord

  include Registratable

  belongs_to :team

  validates_presence_of(:car_class)

  validates_uniqueness_of(:car_number, scope: :championship_id, if: -> { championship.try(:game).try(:require_unique_livery) })
  validates_uniqueness_of(:team, scope: :championship_id, message: 'has already joined this championship.')

  validate :must_have_unique_participating_driver_ids
  validate :must_have_unique_participating_driver_ids_per_championship
  validate :must_not_exceed_max_drivers_per_team
  validate :must_not_have_missing_attributes

  after_save    :handle_unregistration!, if: ->(uc){ uc.saved_change_to_attribute?(:disqualified, { from: false, to: true }) }
  after_create  :role_add
  after_create  :notify_admins_of_sign_in
  after_destroy :handle_unregistration!
  after_destroy :notify_admins_of_sign_out
  
  def self.to_csv(team_registrations)
    CSV.generate do |csv|
      csv << ['username', 'real name', 'team name', 'steam64', 'car number', 'car name', 'registered at']

      team_registrations.each do |tr|
        next if tr.team.blank?

        tr.participating_drivers.each do |driver|
          csv << [
            driver.username,
            driver.real_name,
            tr.team.name,
            driver.steam64_id,
            tr.car_number,
            tr.car.name,
            tr.created_at,
          ]
        end
      end
    end
  end

  def participating_drivers
    return [] if participating_driver_ids.blank?

    User.where(id: participating_driver_ids.reject{ |n| n.blank? }.map{ |i| i.to_i })
  end

  def role_add
    return if reserve?

    if championship.present? && championship.role_id.present?
      message = "You have been added to #{championship.name}!"

      participating_drivers.each do |user|
        user.discord_role_add(championship.role_id, message)
      end
    end

    if championship.try(:game).present? && championship.game.role_id.present?
      message = "You have been added to #{championship.game.name}!"

      participating_drivers.each do |user|
        user.discord_role_add(championship.game.role_id, message)
      end
    end
  end

  def role_remove
    message = "You have been removed from #{championship.name}."

    participating_drivers.each do |user|
      user.discord_role_remove(championship.role_id, message)
    end

    next_reserve = championship.next_reserve_driver_in_class(car_class)

    if next_reserve.present?
      if championship.try(:game).present? && championship.game.role_id.present?
        message = "You have been added to #{championship.game.name}!"
        next_reserve.discord_role_add(championship.game.role_id, message)
      end
    end
  end
  
  private

  def handle_unregistration!
    self.role_remove

    # Promote next reserve
    reserve = championship.next_reserve_team_in_class(car_class)
    championship.team_registrations.find_by(team_id: reserve.id).update(reserve: false) if reserve.present?

    self.notify_admins_of_sign_out
  end

  def must_have_unique_participating_driver_ids
    if participating_driver_ids.to_a.detect{ |id| participating_driver_ids.to_a.count(id) > 1 }.present?
      errors.add(:base, "You cannot assign the same driver twice.")
    end
  end

  def must_have_unique_participating_driver_ids_per_championship
    return true unless championship.present? && championship.teams_enabled? && participating_driver_ids.present?

    global_registered_ids = championship.reload.team_registrations.reject{ |tr| tr == self }.map(&:participating_driver_ids).flatten.reject(&:blank?)

    if global_registered_ids.present? && (global_registered_ids & self.participating_driver_ids).any?
      errors.add(:base, "A driver on this team has already been entered")
    end
  end

  def must_not_exceed_max_drivers_per_team
    if championship.present? && championship.max_drivers_per_team.present? && (participating_drivers.count > championship.max_drivers_per_team.to_i)
      errors.add(:base, "Only #{championship.max_drivers_per_team} drivers may be registered per team.")
    end
  end

  def must_not_have_missing_attributes
    if participating_drivers && championship && participating_drivers.any?{ |u| u.missing_attributes_for(championship.game).present? }
      errors.add(:base, "Some team members must supply additional account information.")
    end
  end

end
