class Team < ApplicationRecord

  has_many :session_results, as: :sessionable
  has_many :team_members, dependent: :destroy
  has_many :users, through: :team_members
  has_many :team_registrations, dependent: :destroy
  has_many :championships, through: :team_registrations, dependent: :destroy

  accepts_nested_attributes_for(:team_members)

  validates_presence_of :name
  validates_uniqueness_of :name
  validates_format_of :name, without: /\./
  
  def display_name
    name
  end

end
