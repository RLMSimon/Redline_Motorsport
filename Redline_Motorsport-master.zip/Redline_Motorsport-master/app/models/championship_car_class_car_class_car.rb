class ChampionshipCarClassCarClassCar < ApplicationRecord

  belongs_to(:championship_car_class)
  belongs_to(:car_class_car)

  validates_uniqueness_of(:car_class_car_id, scope: :championship_car_class_id)

end
