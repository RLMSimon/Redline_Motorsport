class CarClass < ApplicationRecord

  has_many :car_class_cars
  has_many :cars, through: :car_class_cars
  has_many :championship_car_classes
  has_many :championships, through: :championship_car_classes
  has_many :session_incidents
  has_many :session_laps
  has_many :session_results
  has_many :user_championships

  belongs_to(:game)

  validates_presence_of(:name)

  validates_uniqueness_of(:name)

end
