module Sessionable
  extend ActiveSupport::Concern

  included do
    belongs_to :car_class
    belongs_to :race
    belongs_to :sessionable, polymorphic: true, optional: true

    enum session_type: [:practice, :qualifying, :race_1, :race_2, :race_3]

    validates_presence_of(:race_id)
    validates_presence_of(:session_type)
  end

  module ClassMethods
    
    def safe_send(options=[], method_name)
      if self.respond_to?(method_name) && options.include?(method_name)
        self.public_send(method_name)
      end
    end

  end

end
