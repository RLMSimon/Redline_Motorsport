module Registratable

  extend ActiveSupport::Concern

  included do
    belongs_to :car
    belongs_to :car_class
    belongs_to :championship, counter_cache: :users_count, touch: true

    has_many :race_signouts, as: :signoutable, dependent: :destroy

    validate :must_belong_to_open_championship, on: :create
    validate :must_not_exceed_max_reserves
    validates :car_number, length: { maximum: 3 }, unless: :test_env?

    before_validation :set_reserve!, on: :create
    
    before_save :store_car_name
    after_save  :handle_roles!, if: ->(uc){ uc.saved_change_to_attribute?(:reserve) }

    attr_accessor :skip_validations
    
    scope :qualified,    -> { where(disqualified: false) }
    scope :disqualified, -> { where(disqualified: true) }

    def destroyable?
      championship.start_date > Time.now
    end

    def notify_admins_of_sign_in
      return if championship.blank? || !Rails.env.production?

      message = ":handshake: #{participant.class.to_s} #{participant.display_name} registered for #{championship.name}"
      DiscordBot::BOT.send_message(DiscordBot::SIGN_OUT_CHANNEL, message)
    end

    def notify_admins_of_sign_out
      return if championship.blank? || !Rails.env.production?

      message = ":wave: #{participant.class.to_s} #{participant.display_name} has left #{championship.name}"
      DiscordBot::BOT.send_message(DiscordBot::SIGN_OUT_CHANNEL, message)
    end

    def participant
      case self.class.to_s
      when 'TeamRegistration'
        team
      when 'UserChampionship'
        user
      end
    end

    def signouts_remaining
      championship.max_signouts - race_signouts.count
    end

    private
    
    def handle_roles!
      if saved_change_to_attribute?(:reserve, { from: true, to: false })
        self.role_add
      elsif saved_change_to_attribute?(:reserve, { from: false, to: true })
        self.role_remove
      end
    end

    def must_belong_to_open_championship
      if championship.present? && !championship.accepting_registrations? && !skip_validations
        errors.add(:base, "This championship is not currently open for registrations.")
      end
    end
    
    def must_not_exceed_max_reserves
      if championship.present? && reserve? && (championship.participant_registrations.where(car_class: car_class, reserve: true).count >= championship.max_reserves)
        errors.add(:base, "Unfortunately there are no more reserve slots available.")
      end
    end

    def set_reserve!
      return unless championship.present?
      self.reserve = championship.capacity_met?(self)
    end
    
    def store_car_name
      self.car_name = car.name
    end

    def test_env?
      Rails.env.test?
    end

  end

end
