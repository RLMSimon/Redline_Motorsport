class User < ApplicationRecord

  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable, :recoverable, :rememberable, :validatable
  devise :omniauthable, omniauth_providers: [:discord]
  
  has_many :session_results, as: :sessionable
  has_many :user_championships, dependent: :destroy
  has_many :championships, through: :user_championships, dependent: :destroy
  has_many :races, through: :championships
  has_many :incident_reports, dependent: :destroy
  has_many :team_members, dependent: :destroy
  has_many :teams, through: :team_members, dependent: :destroy
  
  validates_uniqueness_of(:raceroom_username, allow_blank: true)
  validates_uniqueness_of(:steam64_id, allow_blank: true)
  validates_uniqueness_of(:username)
  validates(:steam64_id, length: { is: 17 }, exclusion: { in: ['76561197960287930'], message: "must be your own. You may not use a sample Steam64 ID." }, allow_blank: true)
  validates :real_name, length: { minimum: 3 }, allow_blank: true

  def self.clean_username(username)
    username.gsub('/', '').gsub('.', '')
  end

  def avatar
    if self.read_attribute(:avatar).present?
      self.read_attribute(:avatar).gsub('.webp', '.png')
    else
      "default-avatar.png"
    end
  end

  def discord_role_add(role_id, message=nil)
    return unless role_id.present? && uid.present? && Rails.env.production?
    return if discord_account.blank?

    Discordrb::API::Server.add_member_role(ENV['DISCORD_BOT_TOKEN'], ENV['RLM_DISCORD_SERVER_ID'], uid, role_id)

    if message.present?
      begin
        self.discord_account.pm(message)
      rescue Discordrb::Errors::NoPermission => e
        # do nothing
      end
    end
  end

  def discord_role_remove(role_id, message=nil)
    return unless role_id.present? && uid.present? && Rails.env.production?
    return if discord_account.blank?

    Discordrb::API::Server.remove_member_role(ENV['DISCORD_BOT_TOKEN'], ENV['RLM_DISCORD_SERVER_ID'], uid, role_id)

    if message.present?
      begin
        self.discord_account.pm(message)
      rescue Discordrb::Errors::NoPermission => e
        # do nothing
      end
    end
  end

  def discord_account
    DiscordBot::BOT.server(ENV['RLM_DISCORD_SERVER_ID']).member(uid)
  end
  
  def display_name
    username
  end

  def missing_attributes_for(game)
    attributes.select{ |k,v| game.required_user_attributes.to_a.include?(k) && v.blank? }.keys
  end

end
