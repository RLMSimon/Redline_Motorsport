class Admin::ChampionshipsController < ApplicationController

  before_action :require_admin

  def create
    @championship = Championship.new(championship_params)

    if @championship.save
      flash[:notice] = "#{@championship.name} successfully created!"
    else
      flash[:alert] = @championship.errors.full_messages.to_sentence
    end

    redirect_to(admin_championships_path)
  end

  def destroy
    @championship = Championship.find(params[:id])
    @championship.destroy

    flash[:notice] = "#{@championship.name} has been deleted."
    redirect_to(admin_championships_path)
  end

  def edit
    @championship = Championship.find(params[:id])
  end

  def index
    if params[:type] && params[:type] == 'inactive'
      @championships = Championship.inactive.order(name: :asc)
    else
      @championships = Championship.active.order(name: :asc)
    end
  end

  def new
    @championship = Championship.new
  end

  def scoring
    @championship = Championship.find(params[:id])
  end

  def update
    @championship = Championship.find(params[:id])

    if @championship.update(championship_params)
      flash[:notice] = "Changes saved."
    else
      flash[:alert] = @championship.errors.full_messages.to_sentence
    end

    redirect_back(fallback_location: edit_admin_championship_path(@championship))
  end

  private

  def championship_params
    params.require(:championship).permit!
  end

end
