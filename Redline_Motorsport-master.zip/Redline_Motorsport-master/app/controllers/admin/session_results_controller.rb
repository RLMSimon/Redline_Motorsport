class Admin::SessionResultsController < ApplicationController

  before_action :require_admin

  def create
    @session_result = SessionResult.new(session_result_params.merge(race_id: params[:race_id]))
    @race = Race.find(params[:race_id])

    if @session_result.save
      flash[:notice] = "Session Result successfully created!"
    else
      flash[:alert] = @session_result.errors.full_messages.to_sentence
    end

    redirect_to(edit_admin_championship_race_path(championship_id: @race.championship.id, id: @race.id))
  end

  def destroy
    @session_result = SessionResult.find(params[:id])
    @race           = @session_result.race

    @session_result.destroy

    flash[:notice] = "Result has been deleted."
    redirect_to(edit_admin_championship_race_path(championship_id: @race.championship.id, id: @race.id))
  end

  def edit
    @championship   = Championship.find(params[:championship_id])
    @race           = Race.find(params[:race_id])
    @session_result = @race.session_results.find(params[:id])
  end

  def update
    @session_result = SessionResult.find(params[:id])

    if @session_result.update(session_result_params)
      flash[:notice] = "Updated"
    end

    redirect_to(edit_admin_championship_race_path(championship_id: @session_result.race.championship.id, id: @session_result.race.id, session_type: @session_result.session_type))
  end

  private

  def session_result_params
    params.require(:session_result).permit!
  end

end
