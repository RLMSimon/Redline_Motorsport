class Admin::GamesController < ApplicationController

  before_action :require_admin

  def create
    @game = Game.new(game_params)

    if @game.save
      flash[:notice] = "#{@game.name} successfully created!"
    else
      flash[:alert] = @game.errors.full_messages.to_sentence
    end

    redirect_to(admin_games_path)
  end

  def destroy
    @game = Game.find(params[:id])
    @game.destroy

    flash[:notice] = "#{@game.name} has been deleted."
    redirect_to(admin_games_path)
  end

  def edit
    @game = Game.find(params[:id])
  end

  def index
    @games = Game.all
  end

  def new
    @game = Game.new
  end

  def update
    @game = Game.find(params[:id])
    @game.update(game_params)

    flash[:notice] = "#{@game.name} has been updated."
    redirect_to(admin_games_path)
  end

  private

  def game_params
    params.require(:game).permit!
  end

end
