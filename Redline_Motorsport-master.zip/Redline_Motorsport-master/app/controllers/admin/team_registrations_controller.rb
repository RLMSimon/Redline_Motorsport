class Admin::TeamRegistrationsController < ApplicationController

  before_action :require_admin

  def create
    @team_registration = TeamRegistration.new(team_registration_params.merge(championship_id: params[:championship_id]))

    if @team_registration.save
      flash[:notice] = "Registration added!"
    else
      flash[:alert] = @team_registration.errors.full_messages.to_sentence
    end

    redirect_to(admin_championship_team_registrations_path(action: :index))
  end

  def destroy
    @team_registration = TeamRegistration.find(params[:id])

    @team_registration.destroy
    flash[:notice] = "Registration removed."
    redirect_to(admin_championship_team_registrations_path(action: :index))
  end

  def index
    @championship = Championship.find(params[:championship_id])
    @team_registrations = @championship.team_registrations.order(disqualified: :asc, reserve: :asc, created_at: :asc).group_by(&:car_class)
    @team_registrations_format = @championship.team_registrations.where(disqualified: false, reserve: false).order(created_at: :asc)
    @team_registration = @championship.team_registrations.new
    @force_turbolinks_reload = true

    respond_to do |format|
      format.html
      format.ini do
        render 'index.ini.erb', layout: false, content_type: 'text/plain'
      end
      format.json
      format.csv{ send_data(TeamRegistration.to_csv(@championship.team_registrations), filename: "#{@championship.name.parameterize}-registrations.csv") }
    end
  end

  def edit
    @team_registration = TeamRegistration.find(params[:id])
    @force_turbolinks_reload = true
  end

  def update
    @team_registration = TeamRegistration.find(params[:id])

    if @team_registration.update(team_registration_params)
      flash[:notice] = "Updated"
    end

    redirect_to(admin_championship_team_registrations_path(action: :index))
  end

  private

  def team_registration_params
    params.require(:team_registration).permit!
  end

end
