class Admin::CarClassesController < ApplicationController

  before_action :require_admin

  def create
    @game      = Game.find(params[:game_id])
    @car_class = @game.car_classes.new(car_class_params)

    if @car_class.save
      flash[:notice] = "#{@car_class.name} successfully created!"
    else
      flash[:alert] = @car_class.errors.full_messages.to_sentence
    end

    redirect_to(admin_game_car_classes_path(game: @game))
  end

  def destroy
    @game      = Game.find(params[:game_id])
    @car_class = @game.car_classes.find(params[:id])
    @car_class.destroy

    flash[:notice] = "#{@car_class.name} has been deleted."
    redirect_to(admin_game_car_classes_path(game: @game))
  end

  def edit
    @game = Game.find(params[:game_id])
    @car_class = @game.car_classes.find(params[:id])
  end

  def index
    @game = Game.find(params[:game_id])
    @car_classes = @game.car_classes.order(name: :asc)
  end

  def new
    @game      = Game.find(params[:game_id])
    @car_class = @game.car_classes.new
  end

  def update
    @game = Game.find(params[:game_id])
    @car_class = CarClass.find(params[:id])
    @car_class.update(car_class_params)

    flash[:notice] = "#{@car_class.name} has been updated."
    redirect_to(edit_admin_game_car_class_path(@game, @car_class))
  end

  private

  def car_class_params
    params.require(:car_class).permit!
  end

end
