class Admin::IncidentReportsController < ApplicationController

  before_action :require_admin

  def destroy
    @race = Race.find(params[:race_id])
    @incident_report = @race.incident_reports.find(params[:id])

    if @incident_report.destroy
      flash[:notice] = "Incident Report has been deleted."
    end

    redirect_back(fallback_location: admin_championship_incident_reports_path(id: @race.id, championship_id: @race.championship.id))
  end

  def index
    @race = Race.find(params[:id])
    @incident_reports = @race.incident_reports.order(created_at: :asc)
  end

  def text_index
    @race = Race.find(params[:id])
    @incident_reports = @race.incident_reports.order(created_at: :asc)

    render layout: false
  end

end

