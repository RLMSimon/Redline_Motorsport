class Admin::RacesController < ApplicationController

  before_action :require_admin

  def bulk_update
    @race = Race.find(params[:id])

    @session_results = @race.session_results.find(params[:session_result_ids])

    if @session_results.each(&:destroy)
      flash[:notice] = "Results updated."
    end
    
    redirect_to(edit_admin_championship_race_path(action: :edit, id: @race.id, session_type: params[:session_type]))
  end

  def destroy
    @championship = Championship.find(params[:championship_id])
    @race         = @championship.races.find(params[:id])
    @race.destroy

    flash[:notice] = "#{@race.track} has been deleted."
    redirect_to(edit_admin_championship_path(@championship))
  end

  def destroy_results
    @championship      = Championship.find(params[:championship_id])
    @race              = @championship.races.find(params[:id])
    @session_results   = @race.session_results.safe_send(SessionResult.session_types.keys, params[:session_type])
    @session_laps      = @race.session_laps.safe_send(SessionResult.session_types.keys, params[:session_type])
    @session_incidents = @race.session_incidents.safe_send(SessionResult.session_types.keys, params[:session_type])

    @session_results.destroy_all
    @session_laps.destroy_all
    @session_incidents.destroy_all

    flash[:notice] = "Results removed."
    redirect_to(edit_admin_championship_race_path(championship_id: @championship.id, id: @race.id, session_type: params[:session_type]))
  end

  def edit
    @championship    = Championship.find(params[:championship_id])
    @race            = @championship.races.find(params[:id])
    @session_type    = params[:session_type] || 'qualifying'
    @result_type     = params[:result_type] || 'results'
    @filter_class_id = params[:filter_class] || @championship.championship_car_classes.first.try(:car_class_id)
    @force_turbolinks_reload = true

    case @result_type
    when 'results'
      if @filter_class_id.present?
        @session_results = @race.session_results.safe_send(SessionResult.session_types.keys, @session_type).where(car_class_id: @filter_class_id)
      else
        @session_results = @race.session_results.safe_send(SessionResult.session_types.keys, @session_type)
      end

      @session_results = @session_results.order_by_position(@session_type, { warm_up: @race.warm_up? })
    when 'laps'
      @session_laps = @race.session_laps.where('sessionable_id IS NOT NULL').where('times IS NOT NULL').safe_send(SessionResult.session_types.keys, @session_type)
    when 'incidents'
      if params[:type] && params[:type] == 'car_accidents'
        @session_incidents = @race.session_incidents.car_accidents.safe_send(SessionResult.session_types.keys, @session_type)
      else
        @session_incidents = @race.session_incidents.safe_send(SessionResult.session_types.keys, @session_type)
      end
    end
  end

  def index
    @championship = Championship.find(params[:championship_id])
    @races        = @championship.races
    @force_turbolinks_reload = true
  end

  def json_upload
    race            = Race.find(params[:id])
    session_type    = params[:session_type] || 'qualifying'
    filter_class_id = params[:filter_class_id] || race.championship.championship_car_classes.first.try(:car_class_id)

    Importer.public_send("#{race.championship.game.name.parameterize(separator: '_')}", params[:file], race, session_type, filter_class_id)

    flash[:notice] = 'Results imported.'
    redirect_to(edit_admin_championship_race_path(championship_id: race.championship.id, id: race.id, session_type: session_type, result_type: params[:result_type]))
  end

  def update
    @race = Race.find(params[:id])
    @race.update(race_params)

    flash[:notice] = "#{@race.track} has been updated."
    redirect_to(edit_admin_championship_race_path(action: :edit, id: @race.id))
  end

  private

  def race_params
    params.require(:race).permit!
  end

end
