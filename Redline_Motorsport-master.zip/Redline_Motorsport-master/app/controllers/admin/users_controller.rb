class Admin::UsersController < ApplicationController

  before_action :require_admin

  def edit
    @user = User.find_by(username: params[:username])
  end

  def index
    @users = User.all

    if params[:q]
      @users = @users.where("username ILIKE ?", "%#{params[:q]}%")
    end

    @users = @users.order("#{params[:order] || 'username'} ASC").paginate(page: params[:page], per_page: 100)
  end

  def update
    @user = User.find_by(username: params[:username])

    if @user.update(user_params)
      flash[:notice] = "#{@user.username} has been updated."
    else
      flash[:alert] = @user.errors.full_messages.to_sentence
    end
    
    redirect_to(admin_users_path)
  end

  private

  def user_params
    params.require(:user).permit!
  end

end
