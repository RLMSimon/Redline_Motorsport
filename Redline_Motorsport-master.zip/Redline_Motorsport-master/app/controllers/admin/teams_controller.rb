class Admin::TeamsController < ApplicationController

  before_action :require_admin

  def destroy
    @team = Team.find_by(name: params[:name])

    @team.destroy

    flash[:notice] = "#{@team.name} has been deleted."
    redirect_to(admin_teams_path)
  end

  def edit
    @team = Team.find_by(name: params[:name])
  end

  def index
    @teams = Team.all

    if params[:q]
      @teams = @teams.where("name ILIKE ?", "%#{params[:q]}%")
    end

    @teams = @teams.order("#{params[:order] || 'name'} ASC").paginate(page: params[:page], per_page: 100)
  end

  def update
    @team = Team.find_by(name: params[:name])

    if @team.update(team_params)
      flash[:notice] = "#{@team.name} has been updated."
    else
      flash[:alert] = @team.errors.full_messages.to_sentence
    end
    
    redirect_to(admin_teams_path)
  end

  private

  def team_params
    params.require(:team).permit!
  end

end
