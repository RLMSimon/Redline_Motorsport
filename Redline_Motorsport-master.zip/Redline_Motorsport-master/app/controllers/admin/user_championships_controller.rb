class Admin::UserChampionshipsController < ApplicationController

  before_action :require_admin

  def create
    @user_championship = UserChampionship.new(user_championship_params.merge(championship_id: params[:championship_id]))

    if @user_championship.save
      flash[:notice] = "Registration added!"
    else
      flash[:alert] = @user_championship.errors.full_messages.to_sentence
    end

    redirect_to(admin_championship_user_championships_path(action: :index))
  end

  def destroy
    @user_championship = UserChampionship.find(params[:id])

    @user_championship.destroy
    flash[:notice] = "Registration removed."
    redirect_to(admin_championship_user_championships_path(action: :index))
  end

  def index
    @championship = Championship.find(params[:championship_id])
    @user_championships = @championship.user_championships.order(disqualified: :asc, reserve: :asc, created_at: :asc).group_by(&:car_class)
    @user_championships_format = @championship.user_championships.where(disqualified: false).order(created_at: :asc)
    @user_championship = @championship.user_championships.new
    @force_turbolinks_reload = true
    respond_to do |format|
      format.html
      format.ini do
        render 'index.ini.erb', layout: false, content_type: 'text/plain'
      end
      format.json
      format.csv{ send_data(UserChampionship.to_csv(@championship.user_championships), filename: "#{@championship.name.parameterize}-registrations.csv") }
    end
  end

  def edit
    @user_championship = UserChampionship.find(params[:id])
    @force_turbolinks_reload = true
  end

  def update
    @user_championship = UserChampionship.find(params[:id])

    if @user_championship.update(user_championship_params)
      flash[:notice] = "Updated"
    end

    redirect_to(admin_championship_user_championships_path(action: :index))
  end

  private

  def user_championship_params
    params.require(:user_championship).permit!
  end

end
