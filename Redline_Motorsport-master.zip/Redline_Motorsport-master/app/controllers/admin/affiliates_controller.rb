class Admin::AffiliatesController < ApplicationController

  before_action :require_owner

  def create
    @affiliate = Affiliate.new(affiliate_params)

    if @affiliate.save
      flash[:notice] = "#{@affiliate.name} successfully created!"
    else
      flash[:alert] = @affiliate.errors.full_messages.to_sentence
    end

    redirect_to(admin_affiliates_path)
  end

  def destroy
    @affiliate = Affiliate.find(params[:id])
    @affiliate.destroy

    flash[:notice] = "#{@affiliate.name} has been deleted."
    redirect_to(admin_affiliates_path)
  end

  def edit
    @affiliate = Affiliate.find(params[:id])
  end

  def index
    @affiliates = Affiliate.all.order(position: :asc)
  end

  def new
    @affiliate = Affiliate.new
  end

  def update
    @affiliate = Affiliate.find(params[:id])
    @affiliate.update(affiliate_params)

    flash[:notice] = "#{@affiliate.name} has been updated."
    redirect_to(admin_affiliates_path)
  end

  private

  def affiliate_params
    params.require(:affiliate).permit!
  end

end
