class Admin::ChampionshipCarClassesController < ApplicationController

  before_action :require_admin

  def destroy
    @championship = Championship.find(params[:championship_id])
    @championship_car_class = @championship.championship_car_classes.find(params[:id])

    if @championship_car_class.destroy
      flash[:notice] = "#{@championship_car_class.car_class.name} removed."
    end

    redirect_to(edit_admin_championship_path(@championship))
  end

end
