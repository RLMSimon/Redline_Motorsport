class Admin::CarsController < ApplicationController

  before_action :require_admin

  def create
    @game = Game.find(params[:game_id])
    @car  = @game.cars.new(car_params)

    if @car.save
      flash[:notice] = "#{@car.name} successfully created!"
    else
      flash[:alert] = @car.errors.full_messages.to_sentence
    end

    redirect_to(admin_game_cars_path(@game))
  end

  def destroy
    @game = Game.find(params[:game_id])
    @car  = @game.cars.find(params[:id])
    @car.destroy

    flash[:notice] = "#{@car.name} has been deleted."
    redirect_to(admin_game_cars_path(@game))
  end

  def edit
    @car = Car.find(params[:id])
  end

  def index
    @game = Game.find(params[:game_id])
    @cars = @game.cars.all.order(name: :asc)
    @force_turbolinks_reload = true
  end

  def update
    @car = Car.find(params[:id])

    if @car.update(car_params)
      flash[:notice] = "#{@car.name} has been updated."
      redirect_to(admin_game_cars_path(action: :index))
    else
      flash[:alert] = @car.errors.full_messages.to_sentence
      render(:edit)
    end
  end

  private

  def car_params
    params.require(:car).permit!
  end

end
