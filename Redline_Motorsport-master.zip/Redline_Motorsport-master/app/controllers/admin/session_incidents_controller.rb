class Admin::SessionIncidentsController < ApplicationController

  before_action :require_admin

  def mark_as_reviewed
    championship     = Championship.find(params[:championship_id])
    race             = championship.races.find(params[:race_id])
    session_incident = race.session_incidents.find(params[:id])

    session_incident.update(reviewed: true)

    redirect_to(edit_admin_championship_race_path(championship_id: championship.id, id: race.id, session_type: params[:session_type], result_type: 'incidents'))
  end

end
