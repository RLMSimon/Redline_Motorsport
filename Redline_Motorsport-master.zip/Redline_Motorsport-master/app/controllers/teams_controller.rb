class TeamsController < ApplicationController

  before_action :authenticate_user!, only: [:destroy, :edit, :new, :update]
  before_action :authenticate_team_member!, only: [:edit, :update]

  def create
    @team = Team.new(team_params)

    if @team.save
      flash[:notice] = "Congratulations! You have formed a new Team!"
      redirect_to(teams_path)
    else
      render(:new)
    end
  end

  def destroy
    @team = Team.find_by(name: params[:name])

    @team.destroy

    flash[:notice] = "#{@team.name} has been deleted."
    redirect_to(teams_path)
  end

  def edit
  end

  def index
    @teams = Team.all

    if params[:q]
      @teams = @teams.where("name ILIKE ?", "%#{params[:q]}%")
    end

    @teams = @teams.order("#{params[:sort] || 'name ASC'} NULLS LAST").paginate(page: params[:page], per_page: 36)
  end

  def new
    @team = Team.new 
    @team.team_members.build(user: current_user, owner: true)
    @team.team_members.build
  end

  def remove_member
    @team = Team.find_by(name: params[:name])
    @team_member = @team.team_members.find(params[:id])

    if @team_member.destroy
      flash[:notice] = "#{@team_member.user.username} has been removed from this team."
    else
      flash[:alert] = @team_member.errors.full_messages.to_sentence
    end

    redirect_back(fallback_location: team_path(name: @team.name))
  end

  def show
    @team            = Team.find_by(name: params[:name])
    @championships   = @team.championships
    # @session_results = @team.session_results.where(session_type: ['race_1', 'race_2'])
  end

  def update
    if @team.update(team_params)
      flash[:notice] = "Team has been updated."
      redirect_to(team_path(name: @team.name))
    else
      flash.now[:alert] = @team.errors.full_messages.to_sentence
      render action: "edit"
    end
  end

  private

  def authenticate_team_member!
    @team = Team.find_by(name: params[:name])
    return render plain: 'unauthorized' unless @team.users.include?(current_user)
  end
  
  def team_params
    params.require(:team).permit!
  end

end
