class TeamRegistrationsController < ApplicationController

  before_action :authenticate_user!
  before_action :authenticate_team_member!, only: [:edit, :update, :destroy]
  before_action :block_banned, only: [:create, :destroy]

  def create
    @force_turbolinks_reload = true
    @team_registration       = TeamRegistration.new(team_registration_params)
    @championship            = @team_registration.championship
    @missing_attributes      = @team_registration.participating_drivers.any?{ |u| u.missing_attributes_for(@championship.game).present? }
    @car_class               = @team_registration.car_class
    @championship_car_class  = @championship.championship_car_classes.find_by(car_class: @car_class)
    @cccccc                  = @championship_car_class.championship_car_class_car_class_cars.joins(car_class_car: :car).order('cars.name asc')

    if @team_registration.save
      flash[:notice] = "Congratulations! Your team has been added to this championship!"
      redirect_to(championship_path(id: params[:team_registration][:championship_id], complete: true))
    else
      render(:new)
    end
  end

  def destroy
    if @team_registration.destroyable?
      @team_registration.destroy
    else
      @team_registration.update(disqualified: true)
    end

    flash[:notice] = "Your team has left #{@team_registration.championship.name}"

    redirect_to championship_path(@team_registration.championship)
  end

  def edit
    @force_turbolinks_reload = true
    @championship            = @team_registration.championship
    @missing_attributes      = @team_registration.participating_drivers.any?{ |u| u.missing_attributes_for(@championship.game).present? }
    @car_class               = @team_registration.car_class
    @championship_car_class  = @championship.championship_car_classes.find_by(car_class: @car_class)
    @cccccc                  = @championship_car_class.championship_car_class_car_class_cars.joins(car_class_car: :car).order('cars.name asc')
  end

  def new
    @force_turbolinks_reload = true
    @championship            = Championship.find(params[:championship_id])
    @team_registration       = @championship.team_registrations.new
    @missing_attributes      = @team_registration.participating_drivers.any?{ |u| u.missing_attributes_for(@championship.game).present? }
    @cccccc                  = {}
  end

  def update
    @force_turbolinks_reload = true
    @championship            = @team_registration.championship
    @missing_attributes      = @team_registration.participating_drivers.any?{ |u| u.missing_attributes_for(@championship.game).present? }
    @car_class               = @team_registration.car_class
    @championship_car_class  = @championship.championship_car_classes.find_by(car_class: @car_class)
    @cccccc                  = @championship_car_class.championship_car_class_car_class_cars.joins(car_class_car: :car).order('cars.name asc')
    
    if @team_registration.championship.started?
      flash[:alert] = "Registration cannot be updated; the Championship has already started."
    elsif @team_registration.update(team_registration_params)
      flash[:notice] = "Registrations has been updated."
    else
      return render(:edit)
    end

    redirect_to(championship_path(@team_registration.championship))
  end

  private
  
  def authenticate_team_member!
    @team_registration = TeamRegistration.find(params[:id])
   
    unless @team_registration.team.users.include?(current_user)
      return render plain: 'unauthorized', status: :unprocessable_entity
    end
  end

  def team_registration_params
    params.require(:team_registration).permit!
  end

end
