class RacesController < ApplicationController

  def index
    @championship = Championship.find(params[:championship_id])
    @races        = @championship.races.order(starts_at: :asc)

    if current_user.present?
      @registration_record = @championship.registration_record_from_user(current_user.id) 
    end
  end

  def show
    @championship       = Championship.find(params[:championship_id])
    @race               = @championship.races.find(params[:id])
    @session_type       = params[:session_type] || 'race_1'
    @result_type        = params[:result_type] || 'results'
    @filter_class_id    = params[:filter_class] || @championship.championship_car_classes.first.try(:car_class_id)

    case @result_type
    when 'results'
      if @filter_class_id.present?
        @session_results = @race.session_results.includes(:sessionable).safe_send(SessionResult.session_types.keys, @session_type).where(car_class_id: @filter_class_id)
      else
        @session_results = @race.session_results.includes(:sessionable).safe_send(SessionResult.session_types.keys, @session_type)
      end

      @session_results = @session_results.order_by_position(@session_type, { warm_up: @race.warm_up? })
    when 'laps'
      @session_laps = @race.session_laps.where('sessionable_id IS NOT NULL').where('times IS NOT NULL').safe_send(SessionResult.session_types.keys, @session_type)
    when 'incidents'
      @session_incidents = @race.session_incidents.where('sessionable_id IS NOT NULL').safe_send(SessionResult.session_types.keys, @session_type)
    end
  end

end
