class ChampionshipsController < ApplicationController

  def drivers
    @championship = Championship.find(params[:id])

    if @championship.teams_enabled?
      @team_registrations = @championship.team_registrations.order(reserve: :asc, created_at: :asc).group_by(&:car_class)
    else
      @user_championships = @championship.user_championships.includes(:user).order(reserve: :asc, created_at: :asc).group_by(&:car_class)
    end
  end

  def index
    @championships = Championship.active
  end
  
  def results
    @championship = Championship.find(params[:id])
    @races        = @championship.races.order(starts_at: :asc)
  end

  def show
    @championship = Championship.find(params[:id])

    if current_user
      @user_championship = current_user.user_championships.where(championship: @championship).first
      @team_registration = @championship.team_registration_by_user(current_user)
    end
  end

  def standings
    @championship       = Championship.find(params[:id])
    @filter_class_id    = params[:filter_class] || @championship.championship_car_classes.first.try(:car_class_id)
    @participant_registrations = @championship.participant_registrations.where(car_class_id: @filter_class_id, reserve: false).order(championship_score: :desc)
    @complete_races     = @championship.races.order(starts_at: :asc).includes(:session_results).select{ |r| r.session_results.present? }
  end

end
