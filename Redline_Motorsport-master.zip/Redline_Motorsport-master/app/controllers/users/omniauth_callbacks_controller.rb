class Users::OmniauthCallbacksController < Devise::OmniauthCallbacksController

  def discord
    access_token = exchange_code_for_token!
    user_info    = get_user_info(access_token)
    user         = User.where(provider: 'discord', uid: user_info['id']).first

    if user.blank?
      user = User.create({
        email:    user_info['email'],
        password: Devise.friendly_token[0,20],
        username: User.clean_username(user_info['username']),
        avatar:   user_info['avatar'].present? ? Discordrb::API::User.avatar_url(user_info['id'], user_info['avatar']) : nil,
        provider: 'discord',
        uid:      user_info['id'],
      })

      # Join user to RLM server
      server = DiscordBot::BOT.server(ENV['RLM_DISCORD_SERVER_ID'])
      # TODO: There should be a fix for this coming to the discordrb gem. https://github.com/meew0/discordrb/pull/643#pullrequestreview-263555794
      begin
        server.add_member_using_token(user.uid, access_token)
      rescue JSON::ParserError => e
      end
    end

    if user.persisted?
      admin = user.discord_account ? user.discord_account.roles.include?(DiscordBot::ADMIN_ROLE) : false

      user.update_columns({
        admin:    admin,
        username: User.clean_username(user_info['username']),
        uid:      user_info['id'], # Apparently uids can change, so making sure we are always current.
        avatar:   user_info['avatar'].present? ? Discordrb::API::User.avatar_url(user_info['id'], user_info['avatar']) : nil,
      })

      sign_in_and_redirect(user, event: :authentication)
      set_flash_message(:notice, :success, kind: "Discord") if is_navigational_format?
    else
      session["devise.discord_data"] = request.env["omniauth.auth"]
      set_flash_message(:alert, :failure, kind: 'Error', reason: user.errors.full_messages.to_sentence)
      redirect_to root_url
    end
  end

  def discord_auth
    authorization_url = generate_url(
      "https://discordapp.com/api/oauth2/authorize",
      {
        client_id:     ENV['DISCORD_APP_ID'],
        scope:         "email guilds.join identify",
        redirect_uri:  user_discord_omniauth_callback_url,
        response_type: "code",
      }
    )
    redirect_to(authorization_url)
  end

  def failure
    redirect_to root_path
  end

  private

  def generate_url(url, params = {})
    uri = URI(url)
    uri.query = params.to_query
    uri.to_s
  end

  def get_user_info(access_token)
    response = RestClient.get(
      "https://discordapp.com/api/users/@me",
      { Authorization: "Bearer #{access_token}" }
    )
    return JSON.parse(response.body)
  end

  def exchange_code_for_token!
    response = RestClient.post(
      "https://discordapp.com/api/oauth2/token",
      {
        client_id:     ENV['DISCORD_APP_ID'],
        client_secret: ENV['DISCORD_APP_SECRET'],
        scope:         "email guilds.join identify",
        code:          params[:code],
        redirect_uri:  user_discord_omniauth_callback_url,
        grant_type:    "authorization_code"
      }
    )
    formatted_response = JSON.parse(response.body)
    return formatted_response["access_token"]
  end

end
