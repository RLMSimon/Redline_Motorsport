class RaceSignoutsController < ApplicationController

  before_action :authenticate_user!

  def create
    @championship        = Championship.find(params[:championship_id])
    @race                = @championship.races.find(params[:race_id])
    @signoutable_id      = @championship.teams_enabled? ? @championship.team_registration_by_user(current_user.id).team.id : current_user.id 
    @registration_record = @championship.registration_record(@signoutable_id)
    @race_signout        = @race.race_signouts.new(race: @race, signoutable: @registration_record)

    if @race_signout.save
      flash[:notice] = "You have signed out of #{@race.track}."
    else
      flash[:alert] = @race_signout.errors.full_messages.to_sentence
    end

    redirect_back(fallback_location: championship_races_path(championship_id: @championship.id))
  end

  def destroy
    @championship = Championship.find(params[:championship_id])
    @race         = @championship.races.find(params[:race_id])
    @race_signout = @race.race_signouts.find(params[:id])

    if @race_signout && @race_signout.destroy
      flash[:notice] = "You have signed back in to #{@race.track}"
    end

    redirect_back(fallback_location: championship_races_path(championship_id: @championship.id))
  end

end
