class IncidentReportsController < ApplicationController

  before_action :authenticate_user!

  def create
    @incident_report = IncidentReport.new(incident_report_params.merge(user: current_user))
    @race            = @incident_report.race
    @championship    = @race.championship
    assign_driver_list

    if @incident_report.save
      flash[:notice] = "Your report has been filed and will be reviewed shortly."
      redirect_to(championship_races_path(championship_id: @championship.id))
    else
      render(:new)
    end
  end

  def new
    @race            = Race.find(params[:race_id])
    @championship    = @race.championship
    @incident_report = @race.incident_reports.new(user: current_user)
    assign_driver_list
  end

  private

  def assign_driver_list
    if @championship.teams_enabled?
      @driver_list = @championship.participant_registrations.joins(:team).order('teams.name asc').collect{ |tr| ["#{tr.team.name} (##{tr.car_number})", tr.team.id] }
    else
      @driver_list = @championship.participants.order(username: :asc).collect{ |u| ["#{u.username} (#{u.try(:real_name)})", u.id] }
    end
  end

  def incident_report_params
    params.require(:incident_report).permit!
  end

end

