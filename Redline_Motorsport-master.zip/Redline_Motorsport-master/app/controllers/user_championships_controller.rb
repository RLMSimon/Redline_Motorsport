class UserChampionshipsController < ApplicationController

  before_action :authenticate_user!
  before_action :block_banned, only: [:create, :destroy]

  def create
    user_championship = current_user.user_championships.new(user_championship_params)

    if user_championship.save
      flash[:notice] = "Congratulations! You have been added to this championship!"
      redirect_to(championship_path(id: params[:user_championship][:championship_id], complete: true))
    else
      flash[:alert] = user_championship.errors.full_messages.to_sentence
      redirect_back(fallback_location: root_url)
    end
  end

  def destroy
    user_championship = UserChampionship.find(params[:id])

    if user_championship.destroyable?
      user_championship.destroy
    else
      user_championship.update(disqualified: true)
    end

    flash[:notice] = "You have left #{user_championship.championship.name}"

    redirect_to(user_path(current_user.username))
  end

  def edit
    @force_turbolinks_reload = true
    @user_championship       = current_user.user_championships.find(params[:id])
    @championship            = @user_championship.championship
    @missing_attributes      = current_user.missing_attributes_for(@championship.game)
    @car_class               = @user_championship.car_class
    @championship_car_class  = @championship.championship_car_classes.find_by(car_class: @car_class)
    @cccccc                  = @championship_car_class.championship_car_class_car_class_cars.joins(car_class_car: :car).order('cars.name asc')
  end

  def new
    @force_turbolinks_reload = true
    @championship            = Championship.find(params[:championship_id])
    @user_championship       = @championship.user_championships.new(user: current_user)
    @missing_attributes      = current_user.missing_attributes_for(@championship.game)
    @cccccc                  = {}
  end

  def update
    @user_championship = current_user.user_championships.find(params[:id])

    if @user_championship.championship.started?
      flash[:alert] = "Registration cannot be updated; the Championship has already started."
    elsif @user_championship.update(user_championship_params)
      flash[:notice] = "Registrations has been updated."
    else
      flash[:alert] = @user_championship.errors.full_messages.to_sentence
    end

    redirect_back(fallback_location: championship_path(@user_championship.championship))
  end

  private

  def user_championship_params
    params.require(:user_championship).permit!
  end

end
