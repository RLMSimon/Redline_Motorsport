class ApplicationController < ActionController::Base
  
  before_action :configure_permitted_parameters, if: :devise_controller?
  before_action :assign_variables

  protected

  def assign_variables
    @nav_games = Game.all.order(name: :asc)
  end

  def block_banned
    if current_user.try(:banned?)
      return render plain: 'Not permitted', status: :forbidden
    end
  end

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up, keys: [:username])
  end

  def require_admin
    unless current_user.try(:admin?)
      return render plain: 'Not found', status: :forbidden
    end
  end

  def require_owner
    unless current_user.try(:owner?)
      return render plain: 'Not found', status: :forbidden
    end
  end

end
