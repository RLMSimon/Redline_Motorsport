class AffiliatesController < ApplicationController

  def index
    @affiliates = Affiliate.all.order(position: :asc)
  end

end
