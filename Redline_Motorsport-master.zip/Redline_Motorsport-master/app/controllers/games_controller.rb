class GamesController < ApplicationController

  def show
    @game = Game.find(params[:id])

    if params[:type] && params[:type] == 'inactive'
      @championships = @game.championships.inactive.order(name: :asc)
    else
      @championships = @game.championships.active.order(name: :asc)
    end
  end

end
