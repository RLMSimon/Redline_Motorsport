class Api::V1::TeamsController < ApplicationController
  
  respond_to :json

  def show
    team = Team.find(params[:id])

    json = []
    team.team_members.each do |tm|
      json << {
        id: tm.user.id,
        name: tm.user.username,
      }
    end

    render json: json, status: :ok
  end

end
