class Api::V1::CarClassCarsController < ApplicationController
  
  respond_to :json

  def index
    car_class      = CarClass.find(params[:car_class_id])
    json           = []
    car_class_cars = car_class.car_class_cars.includes(:car).order('cars.name asc')

    car_class_cars.each do |car_class_car|
      json << car_class_car.attributes.merge(name: car_class_car.name)
    end
    
    render json: json, status: :ok
  end

end
