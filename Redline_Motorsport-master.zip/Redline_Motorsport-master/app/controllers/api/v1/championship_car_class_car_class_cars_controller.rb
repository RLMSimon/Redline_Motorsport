class Api::V1::ChampionshipCarClassCarClassCarsController < ApplicationController
  
  respond_to :json

  def index
    car_class              = CarClass.find(params[:car_class_id])
    championship           = Championship.find(params[:championship_id])
    championship_car_class = championship.championship_car_classes.find_by(car_class: car_class)
    json                   = []

    championship_car_class.championship_car_class_car_class_cars.joins(car_class_car: :car).order('cars.name asc').each do |cccccc|
      json << cccccc.attributes.merge(car_id: cccccc.car_class_car.car.id, car_name: cccccc.car_class_car.car.name)
    end
    
    render json: json, status: :ok
  end

end
