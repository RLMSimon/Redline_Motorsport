class UsersController < ApplicationController

  before_action :authenticate_user!, only: [:edit, :update]

  def edit
    @user = current_user
  end

  def index
    @users = User.all

    if params[:q]
      @users = @users.where("username ILIKE ?", "%#{params[:q]}%")
    end

    @users = @users.order("#{params[:sort] || 'username ASC'} NULLS LAST").paginate(page: params[:page], per_page: 36)
  end

  def show
    @user                 = User.find_by(username: params[:username])
    @championships = @user.championships
    @session_results      = @user.session_results.where(session_type: ['race_1', 'race_2', 'race_3'])
  end

  def update
    @user = current_user

    if @user.update(user_params)
      flash[:notice] = "Driver profile has been updated."
      redirect_to(user_path(username: @user.username))
    else
      flash[:alert] = @user.errors.full_messages.to_sentence
      render action: "edit"
    end
  end

  private

  def user_params
    params.require(:user).permit!
  end

end
