class PagesController < ApplicationController

  def calendar
    if params[:scope] && params[:scope] == 'mine'
      @races = current_user.races
    else
      @races = Race.all
    end
  end

  def esports
    @esports_users = User.where(esports: true)
  end
    
  def fuel_estimator    
  end
  
  def index
    @championships = Championship.active.includes([:races, :game, :car_classes, :user_championships])
    @future_championships = @championships.order(name: :asc).select{ |c| !c.started? }
    @active_championships = @championships.order(name: :asc).select{ |c| c.started? }
    @most_recent_winner = SessionResult.race_1.last.race.session_results.race_1.order(points_total: :desc).first.sessionable
    @uncontain_width = true
    @force_turbolinks_reload = true
  end

  def privacy_policy
  end

  def rules
  end

  def sponsors
  end

  def terms_of_use
  end
  
end
