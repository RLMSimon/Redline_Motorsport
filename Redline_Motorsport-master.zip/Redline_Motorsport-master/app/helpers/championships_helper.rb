module ChampionshipsHelper

  def championship_registrants_by_class(championship, car_class)
    registered = championship.registrants_by_class(car_class).count
    capacity   = championship.capacity_by_class(car_class)

    "#{registered}/#{capacity}"
  end

end
