module AffiliatesHelper

  def affiliate_image(affiliate, options={})
    if ActionController::Base.helpers.resolve_asset_path(affiliate.image_path)
      image_tag(affiliate.image_path, options)
    end    
  end

end
