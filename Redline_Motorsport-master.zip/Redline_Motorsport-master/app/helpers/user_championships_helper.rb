module UserChampionshipsHelper

  def check_name(name)
    return name.to_s.mb_chars.normalize(:kd).gsub(/[^\x00-\x7F]/n,'').gsub(/[^A-Za-z]/, '')
  end

  def check_short_name(first_name, last_name)
    if (last_name.length > 2)
      return last_name.first(3).upcase
    elsif (first_name.length > 2)
      return first_name.first(3).upcase
    else
      return "DRI"
    end
  end

  def get_driver_category(driver_category, category)
    if (category == 'Cup')
      case driver_category
      when 1
        return 0
      when 2
        return 1
      when 3
        return 2
      when 4
        return 3
      when 5
        return 4
      else
        return 3
      end
    else
      case driver_category
      when 1
        return 3
      when 2
        return 2
      when 3
        return 1
      when 4..5
        return 0
      else
        return 3
      end
    end
  end

  def driver_index(user_championship, index)
    if (user_championship.disqualified)
      return 'DQ'
    elsif (user_championship.reserve)
      return 'R'
    else
      return index + 1
    end
  end
end
