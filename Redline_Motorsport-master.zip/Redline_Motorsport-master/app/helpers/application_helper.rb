module ApplicationHelper

  def display_local_time(time)
    show_year = time.strftime('%Y').to_i != Time.now.year

    content_tag(:span, data: { toggle: "tooltip" }, title: time) do
      content_tag(:span, local_time(time, "%B %e, #{show_year ? '%Y' : ''} %l:%M%P"), class: 'mr-1') +
      content_tag(:span, local_time(time, '%Z'), class: "text-white-50")
    end
  end

  def ms_to_minutes(ms)
    ms      =  ms.to_i.divmod(60000.0)
    minutes = '%02d' % ms[0]
    seconds = '%06.3f' % (ms[1]/1000).round(3)

    "#{minutes}:#{seconds}"
  end

  def age(dob)
    now = Time.now
    now.year - dob.year - ((now.month > dob.month || (now.month == dob.month && now.day >= dob.day)) ? 0 : 1)
  end

end
