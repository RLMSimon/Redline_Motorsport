class AddRequireUniqueLiveryToGames < ActiveRecord::Migration[5.2]
  def change
    add_column :games, :require_unique_livery, :boolean, default: false
  end
end
