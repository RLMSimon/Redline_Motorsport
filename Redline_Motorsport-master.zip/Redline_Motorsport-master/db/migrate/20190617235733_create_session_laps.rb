class CreateSessionLaps < ActiveRecord::Migration[5.2]
  def change
    create_table :session_laps do |t|
      t.timestamps

      t.references :race, index: true, foreign_key: true
      t.references :user, index: true, foreign_key: true
      t.integer :session_type
      t.integer :total_time
      t.integer :sector_1_time
      t.integer :sector_2_time
      t.integer :sector_3_time
    end
  end
end
