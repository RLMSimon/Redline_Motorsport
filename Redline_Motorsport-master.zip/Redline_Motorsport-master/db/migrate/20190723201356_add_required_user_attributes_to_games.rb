class AddRequiredUserAttributesToGames < ActiveRecord::Migration[5.2]
  def change
    add_column :games, :required_user_attributes, :json
  end
end
