class AddIncidentTypeToSessionIncidents < ActiveRecord::Migration[5.2]
  def change
    add_column :session_incidents, :incident_type, :integer, default: 0
  end
end
