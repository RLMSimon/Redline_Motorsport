class AddLobbyNameToRaces < ActiveRecord::Migration[5.2]
  def change
    add_column :races, :lobby_name, :string
  end
end
