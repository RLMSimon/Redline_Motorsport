class AddFieldsToUsers < ActiveRecord::Migration[5.2]
  def change
    add_column(:users, :country_code, :string)
    add_column(:users, :real_name, :string)
    add_column(:users, :date_of_birth, :datetime)
    add_column(:users, :hardware, :string)
  end
end
