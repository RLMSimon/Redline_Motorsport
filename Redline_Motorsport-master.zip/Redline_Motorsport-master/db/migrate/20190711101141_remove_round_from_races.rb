class RemoveRoundFromRaces < ActiveRecord::Migration[5.2]
  def change
    remove_column(:races, :round, :integer)
  end
end
