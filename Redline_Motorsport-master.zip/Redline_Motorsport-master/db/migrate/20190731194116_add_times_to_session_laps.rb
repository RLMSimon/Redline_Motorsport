class AddTimesToSessionLaps < ActiveRecord::Migration[5.2]
  def change
    add_column    :session_laps, :times, :json
    remove_column :session_laps, :total_time, :integer
    remove_column :session_laps, :sector_1_time, :integer
    remove_column :session_laps, :sector_2_time, :integer
    remove_column :session_laps, :sector_3_time, :integer
  end
end
