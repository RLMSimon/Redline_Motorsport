class AddParticipatingDriversToTeamRegistration < ActiveRecord::Migration[5.2]
  def change
    add_column :team_registrations, :participating_driver_ids, :json
  end
end
