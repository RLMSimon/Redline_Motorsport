class AddSessionableIdToSessionTables < ActiveRecord::Migration[5.2]
  def change
    add_column :session_incidents, :sessionable_id, :integer
    add_column :session_incidents, :sessionable_type, :string
    add_column :session_laps, :sessionable_id, :integer
    add_column :session_laps, :sessionable_type, :string
    add_column :session_results, :sessionable_id, :integer
    add_column :session_results, :sessionable_type, :string
  end
end
