class AddVideoUrlToRaces < ActiveRecord::Migration[5.2]
  def change
    add_column :races, :video_url, :string
  end
end
