class CreateCars < ActiveRecord::Migration[5.2]
  def change
    create_table :cars do |t|
      t.references :championship, foreign_key: true, index: true
      t.string :name

      t.timestamps
    end

    add_reference :user_championships, :car, foreign_key: true, index: true
    remove_column :user_championships, :car_name, :string
  end
end
