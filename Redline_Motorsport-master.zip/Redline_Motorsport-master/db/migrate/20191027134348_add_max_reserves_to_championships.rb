class AddMaxReservesToChampionships < ActiveRecord::Migration[5.2]
  def change
    add_column :championships, :max_reserves, :integer, default: 10
  end
end
