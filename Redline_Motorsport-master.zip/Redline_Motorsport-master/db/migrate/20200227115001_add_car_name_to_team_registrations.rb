class AddCarNameToTeamRegistrations < ActiveRecord::Migration[5.2]
  def change
    add_column :team_registrations, :car_name, :string
  end
end
