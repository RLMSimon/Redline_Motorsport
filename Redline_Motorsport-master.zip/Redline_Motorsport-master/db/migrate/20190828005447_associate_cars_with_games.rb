class AssociateCarsWithGames < ActiveRecord::Migration[5.2]
  def change
    rename_column(:cars, :game_id, :in_game_id)
    rename_column(:cars, :game_name, :in_game_name)
    add_reference(:cars, :game, foreign_key: true, index: true)
    # remove_reference(:cars, :championship)

    create_table :championship_cars do |t|
      t.references :car, index: true, foreign_key: true
      t.references :championship, index: true, foreign_key: true
    end
  end
end
