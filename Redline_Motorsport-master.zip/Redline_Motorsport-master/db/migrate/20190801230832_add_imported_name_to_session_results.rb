class AddImportedNameToSessionResults < ActiveRecord::Migration[5.2]
  def change
    add_column :session_results, :imported_name, :string
    add_column :session_laps, :imported_name, :string
    add_column :session_incidents, :imported_name, :string
  end
end
