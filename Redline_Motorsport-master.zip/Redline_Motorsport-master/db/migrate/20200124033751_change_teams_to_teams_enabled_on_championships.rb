class ChangeTeamsToTeamsEnabledOnChampionships < ActiveRecord::Migration[5.2]
  def change
    rename_column(:championships, :teams, :teams_enabled)
  end
end
