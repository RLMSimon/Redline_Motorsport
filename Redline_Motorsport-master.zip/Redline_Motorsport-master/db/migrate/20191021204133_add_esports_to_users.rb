class AddEsportsToUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :users, :esports, :boolean, default: false
  end
end
