class AddDriverCategoryToUserChampionships < ActiveRecord::Migration[5.2]
  def change
    add_column :user_championships, :driver_category, :integer
  end
end
