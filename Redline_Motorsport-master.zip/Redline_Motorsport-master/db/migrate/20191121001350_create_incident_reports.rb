class CreateIncidentReports < ActiveRecord::Migration[5.2]
  def change
    create_table :incident_reports do |t|
      t.references :race, foreign_key: true
      t.references :user, foreign_key: true
      t.references :driver_a
      t.references :driver_b
      t.references :driver_c
      t.references :driver_d
      t.string :incident_time
      t.string :video_url
      t.text :description

      t.timestamps
    end
  end
end
