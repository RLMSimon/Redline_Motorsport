class AssociateCarClassesWithGames < ActiveRecord::Migration[5.2]
  def change
    add_reference :car_classes, :game, foreign_key: true, index: true

    create_table :car_class_cars do |t|
      t.references :car_class, index: true, foreign_key: true
      t.references :car, index: true, foreign_key: true
    end
  end
end
