class AddPasswordToRaces < ActiveRecord::Migration[5.2]
  def change
    add_column :races, :password, :string
  end
end
