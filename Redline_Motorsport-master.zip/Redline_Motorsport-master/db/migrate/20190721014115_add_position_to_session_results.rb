class AddPositionToSessionResults < ActiveRecord::Migration[5.2]
  def change
    add_column :session_results, :position_cache, :integer
    add_column :session_results, :fastest_lap, :boolean, default: false
  end
end
