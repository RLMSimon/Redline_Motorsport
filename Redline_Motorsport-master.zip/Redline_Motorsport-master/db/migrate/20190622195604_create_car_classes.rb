class CreateCarClasses < ActiveRecord::Migration[5.2]
  def change
    create_table :car_classes do |t|
      t.timestamps
      t.string :name
    end

    add_reference :user_championships, :car_class, foreign_key: true, index: true
  end
end
