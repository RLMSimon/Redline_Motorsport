class AddWarmUpToRaces < ActiveRecord::Migration[5.2]
  def change
    add_column :races, :warm_up, :boolean
  end
end
