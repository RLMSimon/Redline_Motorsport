class AddStatCacheColumnsToTeams < ActiveRecord::Migration[5.2]
  def change
    add_column :teams, :total_races_started, :integer
    add_column :teams, :total_wins, :integer
    add_column :teams, :total_podiums, :integer
    add_column :teams, :total_penalty_rate, :float
  end
end
