class AddDefaultForWarmUpToRaces < ActiveRecord::Migration[5.2]
  def change
    change_column :races, :warm_up, :boolean, default: false
  end
end
