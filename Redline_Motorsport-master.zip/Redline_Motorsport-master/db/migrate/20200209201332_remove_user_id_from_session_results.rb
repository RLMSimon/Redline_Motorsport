class RemoveUserIdFromSessionResults < ActiveRecord::Migration[5.2]
  def change
    remove_column :session_results, :user_id, :integer
    remove_column :session_laps, :user_id, :integer
    remove_column :session_incidents, :user_id, :integer
  end
end
