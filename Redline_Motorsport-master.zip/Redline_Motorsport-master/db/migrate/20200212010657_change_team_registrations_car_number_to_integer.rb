class ChangeTeamRegistrationsCarNumberToInteger < ActiveRecord::Migration[5.2]
  def change
    change_column :team_registrations, :car_number, 'integer USING CAST(car_number AS integer)'
    change_column :user_championships, :car_number, 'integer USING CAST(car_number AS integer)'
  end
end
