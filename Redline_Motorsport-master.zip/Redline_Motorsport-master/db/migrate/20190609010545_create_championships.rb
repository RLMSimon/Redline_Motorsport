class CreateChampionships < ActiveRecord::Migration[5.2]
  def change
    create_table :championships do |t|
      t.references :game, foreign_key: true
      t.string :name
      t.boolean :active, default: true
      t.integer :users_count
      t.json :score_matrix
      t.string :notes
      t.integer :races_count

      t.timestamps
    end
  end
end
