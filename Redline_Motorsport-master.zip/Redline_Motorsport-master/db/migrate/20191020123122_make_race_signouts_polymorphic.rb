class MakeRaceSignoutsPolymorphic < ActiveRecord::Migration[5.2]
  def change
    remove_foreign_key(:race_signouts, :user_championships)
    rename_column(:race_signouts, :user_championship_id, :signoutable_id)
    add_column(:race_signouts, :signoutable_type, :string)
  end
end
