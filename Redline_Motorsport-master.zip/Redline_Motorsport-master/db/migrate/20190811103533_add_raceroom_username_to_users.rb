class AddRaceroomUsernameToUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :users, :raceroom_username, :string
  end
end
