class AddDetailsToUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :users, :residence, :string
    add_column :users, :fun_fact, :string
    add_column :users, :accomplishments, :text
  end
end
