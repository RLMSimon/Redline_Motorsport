class AddTeamsToChampionships < ActiveRecord::Migration[5.2]
  def change
    add_column :championships, :teams, :boolean, default: false
  end
end
