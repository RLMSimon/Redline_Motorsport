class AddMaxDriversPerTeamToChampionships < ActiveRecord::Migration[5.2]
  def change
    add_column :championships, :max_drivers_per_team, :integer
  end
end
