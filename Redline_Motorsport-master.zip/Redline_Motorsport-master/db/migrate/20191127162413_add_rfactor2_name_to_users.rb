class AddRfactor2NameToUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :users, :rfactor_2_name, :string
  end
end
