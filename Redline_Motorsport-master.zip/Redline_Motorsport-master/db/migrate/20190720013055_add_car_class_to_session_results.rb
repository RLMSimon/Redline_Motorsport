class AddCarClassToSessionResults < ActiveRecord::Migration[5.2]
  def change
    add_reference :session_incidents, :car_class, foreign_key: true, index: true
    add_reference :session_laps, :car_class, foreign_key: true, index: true
    add_reference :session_results, :car_class, foreign_key: true, index: true
  end
end
