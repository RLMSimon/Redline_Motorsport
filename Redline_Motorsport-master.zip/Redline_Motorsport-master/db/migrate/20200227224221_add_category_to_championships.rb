class AddCategoryToChampionships < ActiveRecord::Migration[5.2]
  def change
    add_column :championships, :category, :string
  end
end
