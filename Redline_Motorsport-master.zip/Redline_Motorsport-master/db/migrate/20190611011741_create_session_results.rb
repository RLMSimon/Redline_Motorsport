class CreateSessionResults < ActiveRecord::Migration[5.2]
  def change
    create_table :session_results do |t|
      t.timestamps

      t.references :race, index: true, foreign_key: true
      t.references :user, index: true, foreign_key: true
      t.integer :session_type
      t.integer :lap_count
      t.integer :best_lap
      t.bigint :total_time
      t.integer :points_given
      t.integer :penalty_points
      t.integer :points_total
    end
  end
end
