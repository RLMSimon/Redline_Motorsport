class CreateTeams < ActiveRecord::Migration[5.2]
  def change
    create_table :teams do |t|
      t.timestamps
      t.string :name
      t.text :body
    end

    create_table :team_members do |t|
      t.timestamps
      t.references :team, index: true, foreign_key: true
      t.references :user, index: true, foreign_key: true
      t.boolean :owner, default: false
    end

    create_table :team_registrations do |t|
      t.timestamps
      t.references :team, index: true, foreign_key: true
      t.references :championship, index: true, foreign_key: true
      t.references :car_class, index: true, foreign_key: true
      t.references :car, index: true, foreign_key: true
      t.string :car_number
      t.boolean :disqualified, default: false
      t.integer :championship_points, default: 0
      t.integer :championship_penalties, default: 0
      t.integer :championship_score, default: 0
      t.integer :position_cache
      t.boolean :reserve, default: false
    end
  end
end
