class RenameStartTimeToStartsAtOnRaces < ActiveRecord::Migration[5.2]
  def change
    rename_column(:races, :start_time, :starts_at)
  end
end
