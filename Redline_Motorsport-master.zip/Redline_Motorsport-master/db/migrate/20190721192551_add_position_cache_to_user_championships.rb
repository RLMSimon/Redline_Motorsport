class AddPositionCacheToUserChampionships < ActiveRecord::Migration[5.2]
  def change
    add_column :user_championships, :position_cache, :integer
  end
end
