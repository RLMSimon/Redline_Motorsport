class CreateChampionshipCarClassCarClassCars < ActiveRecord::Migration[5.2]
  def change
    create_table :championship_car_class_car_class_cars do |t|
      t.references :championship_car_class, foreign_key: true, index: false
      t.references :car_class_car, foreign_key: true
    end
  end
end
