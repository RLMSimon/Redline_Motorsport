class CreateRaces < ActiveRecord::Migration[5.2]
  def change
    create_table :races do |t|
      t.timestamps
      
      t.references :championship, index: true, foreign_key: true
      t.string :track
      t.datetime :start_time
      t.integer :round
    end
  end
end
