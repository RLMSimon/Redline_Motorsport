class AddGameNameToCars < ActiveRecord::Migration[5.2]
  def change
    add_column :cars, :game_name, :string
  end
end
