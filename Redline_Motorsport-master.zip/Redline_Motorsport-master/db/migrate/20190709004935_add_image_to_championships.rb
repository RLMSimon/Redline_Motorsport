class AddImageToChampionships < ActiveRecord::Migration[5.2]
  def change
    add_column :championships, :image, :string
  end
end
