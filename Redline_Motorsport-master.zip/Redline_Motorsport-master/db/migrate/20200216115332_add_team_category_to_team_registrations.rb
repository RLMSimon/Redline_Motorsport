class AddTeamCategoryToTeamRegistrations < ActiveRecord::Migration[5.2]
  def change
    add_column :team_registrations, :team_category, :integer
  end
end
