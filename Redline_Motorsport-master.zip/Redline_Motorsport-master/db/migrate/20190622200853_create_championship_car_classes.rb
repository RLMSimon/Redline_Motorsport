class CreateChampionshipCarClasses < ActiveRecord::Migration[5.2]
  def change
    create_table :championship_car_classes do |t|
      t.references :car_class, index: true, foreign_key: true
      t.references :championship, index: true, foreign_key: true
      t.integer :capacity
    end
  end
end
