class AddGameIdToCars < ActiveRecord::Migration[5.2]
  def change
    add_column :cars, :game_id, :integer
  end
end
