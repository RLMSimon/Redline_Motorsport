class AddDefaultForCategoriesToRegistrations < ActiveRecord::Migration[5.2]
  def change
    change_column :user_championships, :driver_category, :integer, default: 3
    change_column :team_registrations, :team_category, :integer, default: 3
  end
end
