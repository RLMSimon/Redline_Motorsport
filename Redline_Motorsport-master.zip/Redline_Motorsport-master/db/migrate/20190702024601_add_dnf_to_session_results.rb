class AddDnfToSessionResults < ActiveRecord::Migration[5.2]
  def change
    add_column :session_results, :dnf, :boolean, default: false
    add_column :session_results, :dns, :boolean, default: false
  end
end
