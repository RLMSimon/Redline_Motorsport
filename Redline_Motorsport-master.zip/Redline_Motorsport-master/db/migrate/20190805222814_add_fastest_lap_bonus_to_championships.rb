class AddFastestLapBonusToChampionships < ActiveRecord::Migration[5.2]
  def change
    add_column :championships, :fastest_lap_bonus, :integer, default: 0
  end
end
