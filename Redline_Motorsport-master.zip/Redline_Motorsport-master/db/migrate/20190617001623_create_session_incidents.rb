class CreateSessionIncidents < ActiveRecord::Migration[5.2]
  def change
    create_table :session_incidents do |t|
      t.timestamps

      t.references :race, index: true, foreign_key: true
      t.references :user, index: true, foreign_key: true
      t.integer :session_type
      t.string :description
      t.boolean :reviewed, default: false
    end
  end
end
