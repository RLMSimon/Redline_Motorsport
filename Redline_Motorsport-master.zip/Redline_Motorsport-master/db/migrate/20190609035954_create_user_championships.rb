class CreateUserChampionships < ActiveRecord::Migration[5.2]
  def change
    create_table :user_championships do |t|
      t.timestamps
      t.references :user, index: true, foreign_key: true
      t.references :championship, index: true, foreign_key: true
      t.string :car_name
      t.string :car_number
      t.integer :championship_points, default: 0
      t.integer :championship_penalties, default: 0
      t.integer :championship_score, default: 0
    end
  end
end
