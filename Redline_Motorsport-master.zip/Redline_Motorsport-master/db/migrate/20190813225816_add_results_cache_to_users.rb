class AddResultsCacheToUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :users, :total_races_started, :integer
    add_column :users, :total_wins, :integer
    add_column :users, :total_podiums, :integer
    add_column :users, :total_penalty_rate, :float
  end
end
