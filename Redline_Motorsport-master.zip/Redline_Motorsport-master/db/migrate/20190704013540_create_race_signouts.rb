class CreateRaceSignouts < ActiveRecord::Migration[5.2]
  def change
    create_table :race_signouts do |t|
      t.references :race, foreign_key: true, index: true
      t.references :user_championship, foreign_key: true, index: true
    end

    add_column(:championships, :max_signouts, :integer, default: 2)
    add_column(:championships, :missed_race_penalty, :integer, default: 5)
    add_column(:championships, :max_penalties, :integer, default: 10)

    add_column(:user_championships, :disqualified, :boolean, default: false)
  end
end
