# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2020_02_27_234346) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "active_storage_attachments", force: :cascade do |t|
    t.string "name", null: false
    t.string "record_type", null: false
    t.bigint "record_id", null: false
    t.bigint "blob_id", null: false
    t.datetime "created_at", null: false
    t.index ["blob_id"], name: "index_active_storage_attachments_on_blob_id"
    t.index ["record_type", "record_id", "name", "blob_id"], name: "index_active_storage_attachments_uniqueness", unique: true
  end

  create_table "active_storage_blobs", force: :cascade do |t|
    t.string "key", null: false
    t.string "filename", null: false
    t.string "content_type"
    t.text "metadata"
    t.bigint "byte_size", null: false
    t.string "checksum", null: false
    t.datetime "created_at", null: false
    t.index ["key"], name: "index_active_storage_blobs_on_key", unique: true
  end

  create_table "affiliates", force: :cascade do |t|
    t.string "name"
    t.string "description"
    t.string "url"
    t.integer "position"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "car_class_cars", force: :cascade do |t|
    t.bigint "car_class_id"
    t.bigint "car_id"
    t.index ["car_class_id"], name: "index_car_class_cars_on_car_class_id"
    t.index ["car_id"], name: "index_car_class_cars_on_car_id"
  end

  create_table "car_classes", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "name"
    t.bigint "game_id"
    t.index ["game_id"], name: "index_car_classes_on_game_id"
  end

  create_table "cars", force: :cascade do |t|
    t.bigint "championship_id"
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "in_game_id"
    t.string "in_game_name"
    t.bigint "game_id"
    t.index ["championship_id"], name: "index_cars_on_championship_id"
    t.index ["game_id"], name: "index_cars_on_game_id"
  end

  create_table "championship_car_class_car_class_cars", force: :cascade do |t|
    t.bigint "championship_car_class_id"
    t.bigint "car_class_car_id"
    t.index ["car_class_car_id"], name: "index_championship_car_class_car_class_cars_on_car_class_car_id"
  end

  create_table "championship_car_classes", force: :cascade do |t|
    t.bigint "car_class_id"
    t.bigint "championship_id"
    t.integer "capacity"
    t.index ["car_class_id"], name: "index_championship_car_classes_on_car_class_id"
    t.index ["championship_id"], name: "index_championship_car_classes_on_championship_id"
  end

  create_table "championship_cars", force: :cascade do |t|
    t.bigint "car_id"
    t.bigint "championship_id"
    t.index ["car_id"], name: "index_championship_cars_on_car_id"
    t.index ["championship_id"], name: "index_championship_cars_on_championship_id"
  end

  create_table "championships", force: :cascade do |t|
    t.bigint "game_id"
    t.string "name"
    t.boolean "active", default: true
    t.integer "users_count"
    t.json "score_matrix"
    t.string "notes"
    t.integer "races_count"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "role_id"
    t.integer "max_signouts", default: 2
    t.integer "missed_race_penalty", default: 5
    t.integer "max_penalties", default: 10
    t.string "image"
    t.integer "fastest_lap_bonus", default: 0
    t.boolean "accepting_registrations", default: true
    t.boolean "fixed_setup", default: false
    t.integer "max_reserves", default: 10
    t.boolean "teams_enabled", default: false
    t.integer "max_drivers_per_team"
    t.string "category"
    t.index ["game_id"], name: "index_championships_on_game_id"
  end

  create_table "games", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "name"
    t.boolean "active", default: true
    t.json "required_user_attributes"
    t.string "role_id"
    t.boolean "require_unique_livery", default: false
  end

  create_table "incident_reports", force: :cascade do |t|
    t.bigint "race_id"
    t.bigint "user_id"
    t.bigint "driver_a_id"
    t.bigint "driver_b_id"
    t.bigint "driver_c_id"
    t.bigint "driver_d_id"
    t.string "incident_time"
    t.string "video_url"
    t.text "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["driver_a_id"], name: "index_incident_reports_on_driver_a_id"
    t.index ["driver_b_id"], name: "index_incident_reports_on_driver_b_id"
    t.index ["driver_c_id"], name: "index_incident_reports_on_driver_c_id"
    t.index ["driver_d_id"], name: "index_incident_reports_on_driver_d_id"
    t.index ["race_id"], name: "index_incident_reports_on_race_id"
    t.index ["user_id"], name: "index_incident_reports_on_user_id"
  end

  create_table "race_signouts", force: :cascade do |t|
    t.bigint "race_id"
    t.bigint "signoutable_id"
    t.string "signoutable_type"
    t.index ["race_id"], name: "index_race_signouts_on_race_id"
    t.index ["signoutable_id"], name: "index_race_signouts_on_signoutable_id"
  end

  create_table "races", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "championship_id"
    t.string "track"
    t.datetime "starts_at"
    t.string "password"
    t.string "lobby_name"
    t.string "video_url"
    t.boolean "warm_up", default: false
    t.index ["championship_id"], name: "index_races_on_championship_id"
  end

  create_table "session_incidents", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "race_id"
    t.integer "session_type"
    t.string "description"
    t.boolean "reviewed", default: false
    t.bigint "car_class_id"
    t.string "imported_name"
    t.integer "incident_type", default: 0
    t.integer "sessionable_id"
    t.string "sessionable_type"
    t.index ["car_class_id"], name: "index_session_incidents_on_car_class_id"
    t.index ["race_id"], name: "index_session_incidents_on_race_id"
  end

  create_table "session_laps", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "race_id"
    t.integer "session_type"
    t.bigint "car_class_id"
    t.json "times"
    t.string "imported_name"
    t.integer "sessionable_id"
    t.string "sessionable_type"
    t.index ["car_class_id"], name: "index_session_laps_on_car_class_id"
    t.index ["race_id"], name: "index_session_laps_on_race_id"
  end

  create_table "session_results", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "race_id"
    t.integer "session_type"
    t.integer "lap_count"
    t.integer "best_lap"
    t.bigint "total_time"
    t.integer "points_given"
    t.integer "penalty_points"
    t.integer "points_total"
    t.boolean "dnf", default: false
    t.boolean "dns", default: false
    t.bigint "car_class_id"
    t.integer "position_cache"
    t.boolean "fastest_lap", default: false
    t.string "imported_name"
    t.integer "sessionable_id"
    t.string "sessionable_type"
    t.index ["car_class_id"], name: "index_session_results_on_car_class_id"
    t.index ["race_id"], name: "index_session_results_on_race_id"
  end

  create_table "team_members", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "team_id"
    t.bigint "user_id"
    t.boolean "owner", default: false
    t.index ["team_id"], name: "index_team_members_on_team_id"
    t.index ["user_id"], name: "index_team_members_on_user_id"
  end

  create_table "team_registrations", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "team_id"
    t.bigint "championship_id"
    t.bigint "car_class_id"
    t.bigint "car_id"
    t.integer "car_number"
    t.boolean "disqualified", default: false
    t.integer "championship_points", default: 0
    t.integer "championship_penalties", default: 0
    t.integer "championship_score", default: 0
    t.integer "position_cache"
    t.boolean "reserve", default: false
    t.json "participating_driver_ids"
    t.integer "team_category", default: 3
    t.string "car_name"
    t.index ["car_class_id"], name: "index_team_registrations_on_car_class_id"
    t.index ["car_id"], name: "index_team_registrations_on_car_id"
    t.index ["championship_id"], name: "index_team_registrations_on_championship_id"
    t.index ["team_id"], name: "index_team_registrations_on_team_id"
  end

  create_table "teams", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "name"
    t.text "body"
    t.integer "total_races_started"
    t.integer "total_wins"
    t.integer "total_podiums"
    t.float "total_penalty_rate"
  end

  create_table "user_championships", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id"
    t.bigint "championship_id"
    t.integer "car_number"
    t.integer "championship_points", default: 0
    t.integer "championship_penalties", default: 0
    t.integer "championship_score", default: 0
    t.bigint "car_class_id"
    t.boolean "disqualified", default: false
    t.bigint "car_id"
    t.integer "position_cache"
    t.boolean "reserve", default: false
    t.string "car_name"
    t.integer "driver_category", default: 3
    t.index ["car_class_id"], name: "index_user_championships_on_car_class_id"
    t.index ["car_id"], name: "index_user_championships_on_car_id"
    t.index ["championship_id"], name: "index_user_championships_on_championship_id"
    t.index ["user_id"], name: "index_user_championships_on_user_id"
  end

  create_table "users", force: :cascade do |t|
    t.string "username"
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.boolean "admin", default: false
    t.string "steam64_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "country_code"
    t.string "real_name"
    t.date "date_of_birth"
    t.string "hardware"
    t.string "provider"
    t.string "uid"
    t.string "avatar"
    t.boolean "owner", default: false
    t.string "raceroom_username"
    t.integer "total_races_started"
    t.integer "total_wins"
    t.integer "total_podiums"
    t.float "total_penalty_rate"
    t.string "steam_username"
    t.boolean "esports", default: false
    t.string "residence"
    t.string "fun_fact"
    t.text "accomplishments"
    t.string "rfactor_2_name"
    t.boolean "banned"
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
  end

  add_foreign_key "active_storage_attachments", "active_storage_blobs", column: "blob_id"
  add_foreign_key "car_class_cars", "car_classes"
  add_foreign_key "car_class_cars", "cars"
  add_foreign_key "car_classes", "games"
  add_foreign_key "cars", "championships"
  add_foreign_key "cars", "games"
  add_foreign_key "championship_car_class_car_class_cars", "car_class_cars"
  add_foreign_key "championship_car_class_car_class_cars", "championship_car_classes"
  add_foreign_key "championship_car_classes", "car_classes"
  add_foreign_key "championship_car_classes", "championships"
  add_foreign_key "championship_cars", "cars"
  add_foreign_key "championship_cars", "championships"
  add_foreign_key "championships", "games"
  add_foreign_key "incident_reports", "races"
  add_foreign_key "incident_reports", "users"
  add_foreign_key "race_signouts", "races"
  add_foreign_key "races", "championships"
  add_foreign_key "session_incidents", "car_classes"
  add_foreign_key "session_incidents", "races"
  add_foreign_key "session_laps", "car_classes"
  add_foreign_key "session_laps", "races"
  add_foreign_key "session_results", "car_classes"
  add_foreign_key "session_results", "races"
  add_foreign_key "team_members", "teams"
  add_foreign_key "team_members", "users"
  add_foreign_key "team_registrations", "car_classes"
  add_foreign_key "team_registrations", "cars"
  add_foreign_key "team_registrations", "championships"
  add_foreign_key "team_registrations", "teams"
  add_foreign_key "user_championships", "car_classes"
  add_foreign_key "user_championships", "cars"
  add_foreign_key "user_championships", "championships"
  add_foreign_key "user_championships", "users"
end
