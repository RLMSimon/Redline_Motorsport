# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).

raise "DO NOT RUN IN PRODUCTION" if Rails.env.production?

puts "Deleting records..."

SessionResult.destroy_all
SessionIncident.destroy_all
SessionLap.destroy_all
User.delete_all
Game.destroy_all
Car.destroy_all
CarClass.destroy_all
ChampionshipCarClass.destroy_all
Championship.destroy_all
UserChampionship.destroy_all
Race.destroy_all

# Games
puts "Creating Games..."
game_1 = Game.create(name: 'Assetto Corsa')
game_2 = Game.create(name: 'Assetto Corsa Competizione')
game_3 = Game.create(name: 'RaceRoom')
game_4 = Game.create(name: 'iRacing')
game_5 = Game.create(name: 'Dirt Rally')

# CarClasses
car_class_1 = CarClass.create(name: 'GT3')
car_class_2 = CarClass.create(name: 'P2')
car_class_3 = CarClass.create(name: 'GTR 2')
car_class_4 = CarClass.create(name: 'F1')
car_class_5 = CarClass.create(name: 'GTE')
car_class_6 = CarClass.create(name: 'GT3 Pro')
car_class_7 = CarClass.create(name: 'GT3 Am')
car_class_8 = CarClass.create(name: 'WTCR')
car_class_9 = CarClass.create(name: 'FR2')

puts "Complete!"
