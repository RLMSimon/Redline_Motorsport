require 'rails_helper'

RSpec.describe IncidentReportsController, type: :controller do

  let!(:user) { FactoryBot.create(:user) }

  describe '#create' do
    let(:user_2)             { FactoryBot.create(:user) }
    let!(:championship)      { FactoryBot.create(:championship) }
    let!(:race)              { FactoryBot.create(:race, championship: championship) }
    let!(:user_championship) { FactoryBot.create(:user_championship, championship: championship, user: user) }
    let(:incident_report)    { FactoryBot.build(:incident_report, user: user, race: race, driver_a_id: user_2.id) }

    before do
      sign_in(user)
      post :create, params: { incident_report: incident_report.attributes }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(championship_races_path(championship_id: championship.id)) }
    it { expect(user.incident_reports.count).to eq(1) }
  end
  
  describe '#new' do
    let!(:championship) { FactoryBot.create(:championship) }
    let!(:race) { FactoryBot.create(:race, championship: championship) }

    before do
      sign_in(user)
      get :new, params: { race_id: race.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:new) }
    it { expect(assigns(:incident_report)).to be_a_kind_of(IncidentReport) }
  end

end

