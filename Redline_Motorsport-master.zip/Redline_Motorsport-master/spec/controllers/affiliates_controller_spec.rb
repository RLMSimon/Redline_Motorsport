require 'rails_helper'

RSpec.describe AffiliatesController, type: :controller do

  let!(:affiliate) { FactoryBot.create(:affiliate) }

  describe 'GET #index' do
    before { get :index }

    it { expect(response).to render_template(:index) }
    it { expect(response).to have_http_status(:success) }
    it { expect(assigns(:affiliates)).to eq([affiliate]) }
  end

end
