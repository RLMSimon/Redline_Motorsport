require 'rails_helper'

RSpec.describe UserChampionshipsController, type: :controller do

  let!(:user) { FactoryBot.create(:user) }

  describe '#create' do
    let!(:championship)     { FactoryBot.create(:championship) }
    let(:car)               { FactoryBot.create(:car) }
    let(:car_class)         { FactoryBot.create(:car_class) }
    let(:user_championship) { FactoryBot.build(:user_championship, championship: championship, user: user, car: car, car_class: car_class) }

    before do
      sign_in(user)
      post :create, params: { user_championship: user_championship.attributes }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(championship_path(id: championship.id, complete: true)) }
    it { expect(user.user_championships.count).to eq(1) }
  end

  describe '#destroy' do
    context "when championship has not yet started" do
      let!(:championship)     { FactoryBot.create(:championship) }
      let!(:race)             { FactoryBot.create(:race, championship: championship, starts_at: 1.week.from_now)}
      let!(:user_championship) { FactoryBot.create(:user_championship, championship: championship, user: user) }
      let!(:race_signout)     { FactoryBot.create(:race_signout, signoutable: user_championship) }

      before do
        sign_in(user)
        delete :destroy, params: { id: user_championship.id }
      end

      it { expect(response).to have_http_status(:found) }
      it { expect(subject).to redirect_to(user_path(user.username)) }
      it { expect(UserChampionship.find_by(id: user_championship.id).blank?).to be(true) }
    end

    context "when championship has already started" do
      let!(:championship)     { FactoryBot.create(:championship) }
      let!(:race)             { FactoryBot.create(:race, championship: championship, starts_at: 1.week.ago)}
      let(:user_championship) { FactoryBot.create(:user_championship, championship: championship, user: user) }

      before do
        sign_in(user)
        delete :destroy, params: { id: user_championship.id }
      end

      it { expect(response).to have_http_status(:found) }
      it { expect(subject).to redirect_to(user_path(user.username)) }
      it { expect(UserChampionship.find_by(id: user_championship.id).blank?).to be(false) }
      it { expect(user_championship.reload.disqualified?).to be(true) }
    end
  end

  describe '#edit' do
    let!(:championship)           { FactoryBot.create(:championship) }
    let!(:car_class)              { FactoryBot.create(:car_class) }
    let!(:car)                    { FactoryBot.create(:car) }
    let!(:car_class_car)          { FactoryBot.create(:car_class_car, car_class: car_class, car: car) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class) }
    let!(:cccccc)                 { FactoryBot.create(:championship_car_class_car_class_car, championship_car_class: championship_car_class, car_class_car: car_class_car) }
    let!(:user_championship)      { FactoryBot.create(:user_championship, championship: championship, user: user, car_class: car_class) }

    context "when editing one's own user_championship" do
      before do
        sign_in(user)
        get :edit, params: { id: user_championship.id }
      end

      it { expect(response).to have_http_status(:success) }
      it { expect(response).to render_template(:edit) }
      it { expect(assigns(:user_championship)).to eq(user_championship) }
    end
  end

  describe '#new' do
    let!(:championship) { FactoryBot.create(:championship) }

    before do
      sign_in(user)
      get :new, params: { championship_id: championship.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:new) }
    it { expect(assigns(:user_championship)).to be_a_kind_of(UserChampionship) }
  end

  describe 'PATCH #update' do
    context "when championship has not started yet." do
      let!(:user_championship) { FactoryBot.create(:user_championship, car_number: 1, user: user) }

      before do
        sign_in(user)
        patch :update, params: { id: user_championship.id, user_championship: { car_number: 11 } }
      end

      it { expect(response).to have_http_status(:found) }
      it { expect(subject).to redirect_to(championship_path(user_championship.championship)) }
      it { expect(user_championship.reload.car_number).to eq(11) }
    end

    context "when championship has started already." do
      let!(:championship)      { FactoryBot.create(:championship) }
      let!(:race)              { FactoryBot.create(:race, championship: championship, starts_at: 1.week.ago) }
      let!(:user_championship) { FactoryBot.create(:user_championship, championship: championship, car_number: 1, user: user) }

      before do
        sign_in(user)
        patch :update, params: { id: user_championship.id, user_championship: { car_number: 11 } }
      end

      it { expect(controller).to set_flash[:alert] }
      it { expect(user_championship.reload.car_number).to eq(1) }
    end
  end

end
