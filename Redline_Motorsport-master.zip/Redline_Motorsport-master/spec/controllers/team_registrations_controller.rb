require 'rails_helper'

RSpec.describe TeamRegistrationsController, type: :controller do

  let!(:user) { FactoryBot.create(:user) }

  describe '#create' do
    let!(:championship)     { FactoryBot.create(:championship) }
    let(:car)               { FactoryBot.create(:car) }
    let(:car_class)         { FactoryBot.create(:car_class) }
    let(:team)              { FactoryBot.create(:team) }
    let(:team_registration) { FactoryBot.build(:team_registration, championship: championship, team: team, car: car, car_class: car_class) }

    before do
      sign_in(user)
      post :create, params: { team_registration: team_registration.attributes }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(championship_path(id: championship.id, complete: true)) }
    it { expect(championship.team_registrations.count).to eq(1) }
  end

  describe '#destroy' do
    context "when championship has not yet started" do
      let!(:championship)      { FactoryBot.create(:championship, teams_enabled: true) }
      let!(:race)              { FactoryBot.create(:race, championship: championship, starts_at: 1.week.from_now)}
      let!(:team)              { FactoryBot.create(:team) }
      let!(:team_registration) { FactoryBot.create(:team_registration, championship: championship, team: team) }
      let!(:team_member)       { FactoryBot.create(:team_member, team: team, user: user) }
      let!(:race_signout)      { FactoryBot.create(:race_signout, signoutable: team_registration) }

      before do
        sign_in(user)
        delete :destroy, params: { id: team_registration.id }
      end

      it { expect(response).to have_http_status(:found) }
      it { expect(subject).to redirect_to(championship_path(championship)) }
      it { expect(TeamRegistration.find_by(id: team_registration.id).blank?).to be(true) }
    end

    context "when championship has already started" do
      let!(:championship)      { FactoryBot.create(:championship) }
      let!(:race)              { FactoryBot.create(:race, championship: championship, starts_at: 1.week.ago)}
      let!(:team)              { FactoryBot.create(:team) }
      let!(:team_member)       { FactoryBot.create(:team_member, team: team, user: user) }
      let!(:team_registration) { FactoryBot.create(:team_registration, championship: championship, team: team) }

      before do
        sign_in(user)
        delete :destroy, params: { id: team_registration.id }
      end

      it { expect(response).to have_http_status(:found) }
      it { expect(subject).to redirect_to(championship_path(championship)) }
      it { expect(TeamRegistration.find_by(id: team_registration.id).blank?).to be(false) }
      it { expect(team_registration.reload.disqualified?).to be(true) }
    end
  end

  describe '#edit' do
    let!(:championship)           { FactoryBot.create(:championship) }
    let!(:car_class)              { FactoryBot.create(:car_class) }
    let!(:car)                    { FactoryBot.create(:car) }
    let!(:car_class_car)          { FactoryBot.create(:car_class_car, car_class: car_class, car: car) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class) }
    let!(:cccccc)                 { FactoryBot.create(:championship_car_class_car_class_car, championship_car_class: championship_car_class, car_class_car: car_class_car) }
    let!(:team)                   { FactoryBot.create(:team) }
    let!(:team_member)            { FactoryBot.create(:team_member, team: team, user: user) }
    let!(:team_registration)      { FactoryBot.create(:team_registration, championship: championship, team: team, car_class: car_class) }

    context "when editing one's team_registration" do
      before do
        sign_in(user)
        get :edit, params: { id: team_registration.id }
      end

      it { expect(response).to have_http_status(:success) }
      it { expect(response).to render_template(:edit) }
      it { expect(assigns(:team_registration)).to eq(team_registration) }
    end
    
    context "when editing someone else's team_registration" do
      let(:user_2) { FactoryBot.create(:user) }

      before do
        sign_in(user_2)
        get :edit, params: { id: team_registration.id }
      end

      it { expect(response).to have_http_status(:unprocessable_entity) }
    end
  end

  describe '#new' do
    let!(:championship) { FactoryBot.create(:championship) }

    before do
      sign_in(user)
      get :new, params: { championship_id: championship.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:new) }
    it { expect(assigns(:team_registration)).to be_a_kind_of(TeamRegistration) }
  end

  describe 'PATCH #update' do
    let!(:team) { FactoryBot.create(:team) }

    context "when championship has not started yet." do
      let!(:team_registration) { FactoryBot.create(:team_registration, car_number: 1, team: team) }
      let!(:team_member)       { FactoryBot.create(:team_member, team: team, user: user) }

      before do
        sign_in(user)
        patch :update, params: { id: team_registration.id, team_registration: { car_number: 11 } }
      end

      it { expect(response).to have_http_status(:found) }
      it { expect(subject).to redirect_to(championship_path(team_registration.championship)) }
      it { expect(team_registration.reload.car_number).to eq('11') }
    end

    context "when championship has started already." do
      let!(:championship)      { FactoryBot.create(:championship, teams_enabled: true) }
      let!(:race)              { FactoryBot.create(:race, championship: championship, starts_at: 1.week.ago) }
      let!(:team_registration) { FactoryBot.create(:team_registration, championship: championship, car_number: 1, team: team) }
      let!(:team_member)       { FactoryBot.create(:team_member, team: team, user: user) }

      before do
        sign_in(user)
        patch :update, params: { id: team_registration.id, team_registration: { car_number: 11 } }
      end

      it { expect(controller).to set_flash[:alert] }
      it { expect(team_registration.reload.car_number).to eq('1') }
    end
  end

end
