require 'rails_helper'

RSpec.describe ChampionshipsController, type: :controller do

  let!(:championship) { FactoryBot.create(:championship) }

  describe '#drivers' do
    let!(:car_class) { FactoryBot.create(:car_class) }
    let!(:car) { FactoryBot.create(:car) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class) }
    let!(:users) { Array.new(3) { FactoryBot.create(:user) }}

    before do
      users.each_with_index do |user, i|
        user.user_championships.create(championship: championship, car_class: car_class, car: car, car_number: i)
      end

      get :drivers, params: { id: championship.id }
    end

    it { expect(response).to render_template(:drivers) }
    it { expect(response).to have_http_status(:success) }
    it { expect(assigns(:user_championships)).to be_present }
  end

  describe '#index' do
    before { get :index }

    it { expect(response).to render_template(:index) }
    it { expect(response).to have_http_status(:success) }
    it { expect(assigns(:championships)).to eq([championship]) }
  end
  
  describe '#results' do
    let!(:race) { FactoryBot.create(:race, championship: championship) }

    before do
      get :results, params: { id: championship.id }
    end

    it { expect(response).to render_template(:results) }
    it { expect(response).to have_http_status(:success) }
    it { expect(assigns(:races)).to eq([race]) }
  end

  describe '#show' do
    context "when no user signed in" do
      before { get :show, params: { id: championship.id } }

      it { expect(response).to render_template(:show) }
      it { expect(response).to have_http_status(:success) }
      it { expect(assigns(:championship)).to eq(championship) }
    end

    context "when a user is signed in" do
      let!(:user)              { FactoryBot.create(:user) }
      let!(:user_championship) { FactoryBot.create(:user_championship, user: user, championship: championship) }

      before do
        sign_in(user)
        get :show, params: { id: championship.id }
      end

      it { expect(assigns(:user_championship)).to eq(user_championship) }
    end
  end

  describe '#standings' do
    let!(:car_class)         { FactoryBot.create(:car_class) }
    let!(:user_championship) { FactoryBot.create(:user_championship, championship: championship, car_class: car_class) }

    before do
      user_championship.update(reserve: false)
      get :standings, params: { id: championship.id, filter_class: car_class.id }
    end

    it { expect(response).to render_template(:standings) }
    it { expect(response).to have_http_status(:success) }
    it { expect(assigns(:participant_registrations)).to eq([user_championship]) }
  end

end
