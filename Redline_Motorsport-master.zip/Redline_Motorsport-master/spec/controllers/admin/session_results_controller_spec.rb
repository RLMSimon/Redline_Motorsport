require 'rails_helper'

RSpec.describe Admin::SessionResultsController, type: :controller do

  let(:admin) { FactoryBot.create(:user, admin: true) }

  describe '#create' do
    let(:user) { FactoryBot.create(:user) }
    let(:race) { FactoryBot.create(:race) }
    let(:car_class) { FactoryBot.create(:car_class) }
    let(:session_result) { FactoryBot.build(:session_result, :for_user, race: race, sessionable: user, car_class: car_class) }

    before do
      sign_in(admin)
      post :create, params: { championship_id: race.championship.id, race_id: race.id, session_result: session_result.attributes }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(controller).to set_flash[:notice] }
    it { expect(subject).to redirect_to(edit_admin_championship_race_path(championship_id: session_result.race.championship.id, id: session_result.race.id)) }
    it { expect(race.reload.session_results.count).to eq(1) }
  end
  
  describe '#destroy' do
    let(:session_result) { FactoryBot.create(:session_result) }

    before do
      sign_in(admin)
      delete :destroy, params: { championship_id: session_result.race.championship.id, race_id: session_result.race.id, id: session_result.id }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(edit_admin_championship_race_path(championship_id: session_result.race.championship.id, id: session_result.race.id)) }
    it { expect(SessionResult.find_by(id: session_result.id).blank?).to be true }
  end

  describe '#edit' do
    let(:session_result) { FactoryBot.create(:session_result) }

    before do
      sign_in(admin)
      get :edit, params: { championship_id: session_result.race.championship.id, race_id: session_result.race.id, id: session_result.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(assigns(:session_result)).to eq(session_result) }
  end

  describe '#update' do
    let(:session_result) { FactoryBot.create(:session_result) }

    before do
      sign_in(admin)
      patch :update, params: { championship_id: session_result.race.championship.id, race_id: session_result.race.id, id: session_result.id, session_result: { lap_count: 15 } }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(controller).to set_flash[:notice] }
    it { expect(subject).to redirect_to(edit_admin_championship_race_path(championship_id: session_result.race.championship.id, id: session_result.race.id, session_type: session_result.session_type)) }
    it { expect(session_result.reload.lap_count).to eq(15) }
  end

end
