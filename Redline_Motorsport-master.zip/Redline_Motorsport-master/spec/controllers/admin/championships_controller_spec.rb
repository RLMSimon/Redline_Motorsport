require 'rails_helper'

RSpec.describe Admin::ChampionshipsController, type: :controller do

  let(:admin)  { FactoryBot.create(:user, admin: true) }
  let(:game)   { FactoryBot.create(:game) }

  describe 'POST #create' do
    let(:championship) { FactoryBot.build(:championship, name: 'Foo Champ', game: game) }

    before do
      sign_in(admin)
      post :create, params: { championship: championship.attributes }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(admin_championships_path) }
    it { expect(Championship.find_by(name: 'Foo Champ').present?).to be true }
  end
  
  describe 'DELETE #destroy' do
    let!(:championship)      { FactoryBot.create(:championship, game: game) }
    let!(:car)               { FactoryBot.create(:car, game: game) }
    let!(:user_championship) { FactoryBot.create(:user_championship, championship: championship, car: car) }

    before do
      sign_in(admin)
      delete :destroy, params: { id: championship.id }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(admin_championships_path) }
    it { expect(Championship.find_by(id: championship.id).blank?).to be true }
  end

  describe 'GET #edit' do
    let!(:championship) { FactoryBot.create(:championship, game: game) }

    before do
      sign_in(admin)
      get :edit, params: { id: championship.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:edit) }
    it { expect(assigns(:championship)).to eq(championship) }
  end

  describe 'GET #index' do
    let!(:championship) { FactoryBot.create(:championship, game: game) }

    before do
      sign_in(admin)
      get :index
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:index) }
    it { expect(assigns(:championships)).to eq([championship]) }
  end

  describe 'GET #new' do
    before do
      sign_in(admin)
      get :new
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:new) }
    it { expect(assigns(:championship)).to be_a_kind_of(Championship) }
  end

  describe 'GET #scoring' do
    let!(:championship) { FactoryBot.create(:championship, game: game) }

    before do
      sign_in(admin)
      get :scoring, params: { id: championship.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:scoring) }
    it { expect(assigns(:championship)).to eq(championship) }
  end

end
