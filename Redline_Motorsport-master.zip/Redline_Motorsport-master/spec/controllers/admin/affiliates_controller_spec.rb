require 'rails_helper'

RSpec.describe Admin::AffiliatesController, type: :controller do

  let(:admin) { FactoryBot.create(:user, admin: true, owner: true) }

  describe 'POST #create' do
    let!(:affiliate) { FactoryBot.build(:affiliate, name: 'Foo Things') }

    before do
      sign_in(admin)
      post :create, params: { affiliate: affiliate.attributes }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(controller).to set_flash[:notice] }
    it { expect(subject).to redirect_to(admin_affiliates_path) }
    it { expect(Affiliate.find_by(name: 'Foo Things').present?).to be(true) }
  end

  describe 'DELETE #destroy' do
    let!(:affiliate) { FactoryBot.create(:affiliate, name: 'Foo Things') }

    before do
      sign_in(admin)
      delete :destroy, params: { id: affiliate.id }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(controller).to set_flash[:notice] }
    it { expect(subject).to redirect_to(admin_affiliates_path) }
    it { expect(Affiliate.find_by(id: affiliate.id).present?).to be(false) }
  end

  describe 'GET #edit' do
    let!(:affiliate) { FactoryBot.create(:affiliate) }

    before do
      sign_in(admin)
      get :edit, params: { id: affiliate.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:edit) }
    it { expect(assigns(:affiliate)).to eq(affiliate) }
  end

  describe 'GET #index' do
    let!(:affiliate) { FactoryBot.create(:affiliate) }

    before do
      sign_in(admin)
      get :index
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:index) }
    it { expect(assigns(:affiliates)).to eq([affiliate]) }
  end

  describe 'GET #new' do
    before do
      sign_in(admin)
      get :new
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:new) }
    it { expect(assigns(:affiliate)).to be_a_kind_of(Affiliate) }
  end

  describe 'PATCH #update' do
    let!(:affiliate) { FactoryBot.create(:affiliate, name: 'Cool Things') }

    before do
      sign_in(admin)
      patch :update, params: { id: affiliate.id, affiliate: { name: 'Really Cool Things' }}
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(controller).to set_flash[:notice] }
    it { expect(subject).to redirect_to(admin_affiliates_path) }
    it { expect(affiliate.reload.name).to eq('Really Cool Things') }
  end

end
