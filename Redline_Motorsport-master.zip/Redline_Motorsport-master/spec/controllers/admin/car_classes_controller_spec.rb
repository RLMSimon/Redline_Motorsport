require 'rails_helper'

RSpec.describe Admin::CarClassesController, type: :controller do

  let(:admin) { FactoryBot.create(:user, admin: true) }
  let!(:game) { FactoryBot.create(:game) }

  describe 'POST #create' do
    let(:car_class) { FactoryBot.build(:car_class, game: game) }

    before do
      sign_in(admin)
      post :create, params: { game_id: game.id, car_class: car_class.attributes }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(admin_game_car_classes_path(game: game)) }
    it { expect(game.reload.car_classes.count).to eq(1) }
  end

  describe 'DELETE #destroy' do
    let(:car_class) { FactoryBot.create(:car_class, game: game) }

    before do
      sign_in(admin)
      delete :destroy, params: { game_id: game.id, id: car_class.id }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(admin_game_car_classes_path(game: game)) }
    it { expect(CarClass.find_by(id: car_class.id).blank?).to be true }
  end

  describe 'GET #edit' do
    let(:car_class) { FactoryBot.create(:car_class, game: game) }

    before do
      sign_in(admin)
      get :edit, params: { game_id: game.id, id: car_class.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:edit) }
    it { expect(assigns(:car_class)).to eq(car_class) }
  end

  describe 'GET #index' do
    let(:car_class) { FactoryBot.create(:car_class, game: game) }

    before do
      sign_in(admin)
      get :index, params: { game_id: game.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:index) }
    it { expect(assigns(:car_classes)).to eq([car_class]) }
  end

  describe 'GET #new' do
    before do
      sign_in(admin)
      get :new, params: { game_id: game.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:new) }
    it { expect(assigns(:car_class)).to be_a_kind_of(CarClass) }
  end

  describe 'PATCH #update' do
    let(:car_class) { FactoryBot.create(:car_class, game: game) }

    before do
      sign_in(admin)
      patch :update, params: { game_id: game.id, id: car_class.id, car_class: { name: 'Kung Fu' } }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(edit_admin_game_car_class_path(game, car_class)) }
    it { expect(car_class.reload.name).to eq('Kung Fu') }
  end

end
