require 'rails_helper'

RSpec.describe Admin::CarsController, type: :controller do

  let(:admin) { FactoryBot.create(:user, admin: true) }
  let!(:game) { FactoryBot.create(:game) }
  let!(:car)  { FactoryBot.create(:car, game: game) }

  describe 'POST #create' do
    let(:car_2) { FactoryBot.build(:car, game: game) }

    before do
      sign_in(admin)
      post :create, params: { game_id: game.id, car: car_2.attributes }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(admin_game_cars_path(game)) }
    it { expect(game.reload.cars.count).to eq(2) }
  end
  
  describe '#destroy' do
    before do
      sign_in(admin)
      delete :destroy, params: { game_id: game.id, id: car.id }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(admin_game_cars_path(game)) }
    it { expect(Car.find_by(id: car.id).blank?).to be true }
  end

  describe '#edit' do
    before do
      sign_in(admin)
      get :edit, params: { game_id: game.id, id: car.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:edit) }
    it { expect(assigns(:car)).to eq(car) }
  end

  describe '#index' do
    before do
      sign_in(admin)
      get :index, params: { game_id: game.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:index) }
    it { expect(assigns(:cars)).to eq([car]) }
  end

  describe 'PATCH #update' do
    before do
      sign_in(admin)
      patch :update, params: { game_id: game.id, id: car.id, car: { name: 'Lotus Esprit', in_game_id: 2 } }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(admin_game_cars_path(action: :index)) }
    it { expect(car.reload.name).to eq('Lotus Esprit') }
    it { expect(car.reload.in_game_id).to eq(2) }
  end

end
