require 'rails_helper'

RSpec.describe Admin::SessionIncidentsController, type: :controller do

  describe '#mark_as_reviewed' do
    let!(:admin)            { FactoryBot.create(:user, admin: true) }
    let!(:championship)     { FactoryBot.create(:championship) }
    let!(:race)             { FactoryBot.create(:race, championship: championship) }
    let!(:session_incident) { FactoryBot.create(:session_incident, race: race) }

    before do
      sign_in(admin)
      patch :mark_as_reviewed, params: { championship_id: championship.id, race_id: race.id, id: session_incident.id }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(edit_admin_championship_race_path(championship_id: championship.id, id: race.id, result_type: 'incidents')) }
    it { expect(session_incident.reload.reviewed?).to be(true) }
  end

end
