require 'rails_helper'

RSpec.describe Admin::ChampionshipCarClassesController, type: :controller do

  describe 'DELETE #destroy' do
    let(:admin) { FactoryBot.create(:user, admin: true) }
    let(:championship) { FactoryBot.create(:championship) }
    let(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship) }

    before do
      sign_in(admin)
      delete :destroy, params: { championship_id: championship.id, id: championship_car_class.id }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(edit_admin_championship_path(championship)) }
    it { expect(ChampionshipCarClass.find_by(id: championship_car_class.id).blank?).to be true }
  end

end
