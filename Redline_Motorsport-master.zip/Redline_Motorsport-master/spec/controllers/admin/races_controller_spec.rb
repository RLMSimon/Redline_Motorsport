require 'rails_helper'

RSpec.describe Admin::RacesController, type: :controller do

  let(:admin)         { FactoryBot.create(:user, admin: true) }
  let!(:championship) { FactoryBot.create(:championship) }
  let!(:race)         { FactoryBot.create(:race, championship: championship) }

  describe 'PATCH #bulk_update' do 
    let!(:session_result_1) { FactoryBot.create(:session_result, :for_user, race: race, session_type: 'race_1') }
    let!(:session_result_2) { FactoryBot.create(:session_result, :for_user, race: race, session_type: 'race_1') }
    let!(:session_result_3) { FactoryBot.create(:session_result, :for_user, race: race, session_type: 'race_1') }
    let!(:session_result_4) { FactoryBot.create(:session_result, :for_user, race: race, session_type: 'race_1') }
    
    before do
      sign_in(admin)
      patch :bulk_update, params: { championship_id: championship.id, id: race.id, session_result_ids: [session_result_3.id, session_result_4.id], session_type: 'race_1' }
    end
    
    it { expect(response).to have_http_status(:found) }
    it { expect(controller).to set_flash[:notice] }
    it { expect(subject).to redirect_to(edit_admin_championship_race_path(action: :edit, id: race.id, session_type: 'race_1')) }
    it { expect(race.reload.session_results).to eq([session_result_1, session_result_2]) }
  end

  describe '#destroy' do
    before do
      sign_in(admin)
      delete :destroy, params: { championship_id: championship.id, id: race.id }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(edit_admin_championship_path(championship)) }
    it { expect(Race.find_by(id: race.id).blank?).to be true }
  end

  describe '#destroy_results' do
    let!(:session_result_1)   { FactoryBot.create(:session_result, :for_user, race: race, session_type: 'practice') }
    let!(:session_result_2)   { FactoryBot.create(:session_result, :for_user, race: race, session_type: 'race_1') }
    let!(:session_lap_1)      { FactoryBot.create(:session_lap, race: race, session_type: 'practice') }
    let!(:session_lap_2)      { FactoryBot.create(:session_lap, race: race, session_type: 'race_1') }
    let!(:session_incident_1) { FactoryBot.create(:session_incident, race: race, session_type: 'practice') }
    let!(:session_incident_2) { FactoryBot.create(:session_incident, race: race, session_type: 'race_1') }

    before do
      sign_in(admin)
      delete :destroy_results, params: { championship_id: championship.id, id: race.id, session_type: 'race_1' }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(controller).to set_flash[:notice] }
    it { expect(subject).to redirect_to(edit_admin_championship_race_path(championship_id: championship.id, id: race.id, session_type: 'race_1')) }
    it { expect(race.session_results).to eq([session_result_1]) }
    it { expect(race.session_laps).to eq([session_lap_1]) }
    it { expect(race.session_incidents).to eq([session_incident_1]) }
  end

  describe '#edit' do
    let(:user)                { FactoryBot.create(:user) }
    let(:car_class)           { FactoryBot.create(:car_class) }
    let(:car_class_2)         { FactoryBot.create(:car_class) }
    let!(:session_result_1)   { FactoryBot.create(:session_result, car_class: car_class, race: race, session_type: 'practice') }
    let!(:session_result_3)   { FactoryBot.create(:session_result, car_class: car_class_2, race: race, session_type: 'practice') }
    let!(:session_result_2)   { FactoryBot.create(:session_result, car_class: car_class, race: race, session_type: 'qualifying') }
    let!(:session_lap_1)      { FactoryBot.create(:session_lap, :for_user, sessionable: user, race: race, session_type: 'practice') }
    let!(:session_lap_2)      { FactoryBot.create(:session_lap, :for_user, sessionable: user, race: race, session_type: 'qualifying') }
    let!(:session_incident_1) { FactoryBot.create(:session_incident, :for_user, sessionable: user, race: race, session_type: 'qualifying') }
    let!(:session_incident_2) { FactoryBot.create(:session_incident, :for_user, sessionable: user, race: race, session_type: 'race_1') }

    context "when fetcing session results" do
      context "when filtering by class" do
        before do
          sign_in(admin)
          get :edit, params: { championship_id: championship.id, id: race.id, result_type: 'results', filter_class: car_class.id, session_type: 'practice' }
        end

        it { expect(assigns(:session_results)).to eq([session_result_1]) }
      end

      context "when not filtering by class" do
        before do
          sign_in(admin)
          get :edit, params: { championship_id: championship.id, id: race.id, result_type: 'results', session_type: 'practice' }
        end

        it { expect(response).to have_http_status(:success) }
        it { expect(response).to render_template(:edit) }
        it { expect(assigns(:session_results).count).to eq(2) }
      end
    end

    context "when fetcing session laps" do
      before do
        sign_in(admin)
        get :edit, params: { championship_id: championship.id, id: race.id, result_type: 'laps', session_type: 'qualifying' }
      end

      it { expect(assigns(:session_laps)).to eq([session_lap_2]) }
    end

    context "when fetcing session incidents" do
      before do
        sign_in(admin)
        get :edit, params: { championship_id: championship.id, id: race.id, result_type: 'incidents', session_type: 'race_1' }
      end

      it { expect(assigns(:session_incidents)).to eq([session_incident_2]) }
    end
  end

  describe '#index' do
    before do
      sign_in(admin)
      get :index, params: { championship_id: championship.id }
    end

    it { expect(response).to have_http_status(:success) }
    it { expect(response).to render_template(:index) }
    it { expect(assigns(:races)).to eq([race]) }
  end

  describe '#json_upload' do
    let!(:car_class)      { FactoryBot.create(:car_class) }
    let!(:game)           { FactoryBot.create(:game, name: 'Assetto Corsa Competizione') }
    let!(:championship_1) { FactoryBot.create(:championship, game: game) }
    let!(:race_1)         { FactoryBot.create(:race, championship: championship_1) }

    before do
      @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/acc-r.json'), 'application/json')

      sign_in(admin)
      post :json_upload, params: { championship_id: championship_1.id, id: race_1.id, session_type: 'race_1', filter_class_id: car_class.id, file: @file }
    end

    it { expect(response).to have_http_status(:found) }
    it { expect(subject).to redirect_to(edit_admin_championship_race_path(championship_id: championship_1.id, id: race_1.id, session_type: 'race_1')) }
    it { expect(race_1.session_results.present?).to be(true) }
  end

end
