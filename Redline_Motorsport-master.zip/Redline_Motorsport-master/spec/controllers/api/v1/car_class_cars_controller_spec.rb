require 'rails_helper'

RSpec.describe Api::V1::CarClassCarsController, type: :controller do

  before do
    request.accept = 'application/json'
  end

  describe 'GET #index' do
    let!(:car_class)     { FactoryBot.create(:car_class) }
    let!(:car)           { FactoryBot.create(:car) }
    let!(:car_class_car) { FactoryBot.create(:car_class_car, car_class: car_class, car: car) }

    before do
      get :index, params: { car_class_id: car_class.id }
    end

    it { should respond_with(:success) }
    it { expect(response.content_type).to eq('application/json') }
    it { expect(JSON.parse(response.body).count).to eq(1) }
  end

end
