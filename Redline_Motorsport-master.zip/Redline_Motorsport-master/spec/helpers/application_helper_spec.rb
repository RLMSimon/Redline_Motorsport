require 'rails_helper'

RSpec.describe ApplicationHelper, type: :helper do
  
  describe 'display_local_time' do
    it { expect(helper.display_local_time(Time.now).present?).to be(true) }
  end

  describe 'ms_to_minutes' do
    it { expect(helper.ms_to_minutes(100000)).to eq('01:40.000') }
  end

end
