require 'rails_helper'

RSpec.describe ChampionshipsHelper, type: :helper do
  
  describe 'championship_registrants_by_class' do
    let!(:car_class)              { FactoryBot.create(:car_class)}
    let!(:championship)           { FactoryBot.create(:championship) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 10) }
    let!(:user_championship)      { FactoryBot.create(:user_championship, championship: championship, car_class: car_class) }

    it { expect(helper.championship_registrants_by_class(championship, car_class)).to eq("1/10") }
  end

end
