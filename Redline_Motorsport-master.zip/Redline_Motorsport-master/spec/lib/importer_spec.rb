require_relative "../../lib/importer.rb"
require 'spec_helper'
require 'rails_helper'

RSpec.describe Importer, type: :lib do

  let!(:car_class)    { FactoryBot.create(:car_class) }

  describe '.assetto_corsa' do
    let!(:game)         { FactoryBot.create(:game, name: 'Assetto Corsa') }
    let!(:championship) { FactoryBot.create(:championship, game: game) }
    let!(:race)         { FactoryBot.create(:race, championship: championship) }

    context "when importing qualifying results" do
      before do
        @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/ac-qualifying.json'), 'application/json')
        Importer.assetto_corsa(@file, race, 'qualifying', car_class.id)
      end

      it { expect(race.session_results.qualifying.present?).to be(true) }
      it { expect(race.session_laps.qualifying.present?).to be(true) }
    end

    context "when importing race_1 results" do
      before do
        @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/ac-race.json'), 'application/json')
        Importer.assetto_corsa(@file, race, 'race_1', car_class.id)
      end

      it { expect(race.session_results.race_1.present?).to be(true) }
      it { expect(race.session_results.race_1.order(lap_count: :desc).first.lap_count).to be > 0 }
      it { expect(race.session_laps.race_1.present?).to be(true) }
    end
  end
  
  describe '.assetto_corsa_competizione' do
    let!(:game)         { FactoryBot.create(:game, name: 'Assetto Corsa Competizione') }

    context "when championship is for individuals" do
      let!(:championship) { FactoryBot.create(:championship, game: game) }
      let!(:race)         { FactoryBot.create(:race, championship: championship) }

      context "when importing qualifying results" do
        before do
          @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/acc-q.json'), 'application/json')
          Importer.assetto_corsa_competizione(@file, race, 'qualifying', car_class.id)
        end

        it { expect(race.session_results.qualifying.present?).to be(true) }
        it { expect(race.session_laps.qualifying.present?).to be(true) }
      end

      context "when importing race_1 results" do
        before do
          @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/acc-r.json'), 'application/json')
          Importer.assetto_corsa_competizione(@file, race, 'race_1', car_class.id)
        end

        it { expect(race.session_results.race_1.present?).to be(true) }
        it { expect(race.session_results.race_1.order(lap_count: :desc).first.lap_count).to be > 0 }
        it { expect(race.session_laps.race_1.present?).to be(true) }
      end
    end

    context "when championship is for teams" do
      let!(:championship) { FactoryBot.create(:championship, game: game, teams_enabled: true) }
      let!(:race)         { FactoryBot.create(:race, championship: championship) }
      
      context "when importing race_1 results" do
        before do
          @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/acc-r-teams.json'), 'application/json')
          Importer.assetto_corsa_competizione(@file, race, 'race_1', car_class.id)

          race.reload.session_results.count
        end

        it { expect(race.session_results.race_1.present?).to be(true) }
        it { expect(race.session_results.race_1.order(lap_count: :desc).first.lap_count).to be > 0 }
        it { expect(race.session_laps.race_1.present?).to be(true) }
      end
    end
  end

  describe '.project_cars_2' do
    let!(:game)         { FactoryBot.create(:game, name: 'Project Cars 2') }
    let!(:championship) { FactoryBot.create(:championship, game: game) }
    let!(:race)         { FactoryBot.create(:race, championship: championship) }

    context "when importing json 1" do
      before do
        @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/project-cars-2.json'), 'application/json')
        Importer.project_cars_2(@file, race, '', car_class.id)
      end

      it { expect(race.session_results.qualifying.present?).to be(true) }
      it { expect(race.session_results.race_1.present?).to be(true) }
      it { expect(race.session_results.race_1.order(lap_count: :desc).first.lap_count).to be > 0 }
      # it { expect(race.session_laps.qualifying.present?).to be(true) }
      # it { expect(race.session_laps.race_1.present?).to be(true) }
    end
    
    context "when importing json 2" do
      before do
        @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/project-cars-2-1.json'), 'application/json')
        Importer.project_cars_2(@file, race, '', car_class.id)
      end

      it { expect(race.session_results.qualifying.present?).to be(true) }
      it { expect(race.session_results.race_1.present?).to be(true) }
      it { expect(race.session_results.race_1.order(lap_count: :desc).first.lap_count).to be > 0 }
    end
  end

  describe '.raceroom' do
    let!(:game)         { FactoryBot.create(:game, name: 'RaceRoom') }
    let!(:championship) { FactoryBot.create(:championship, game: game) }
    let!(:race)         { FactoryBot.create(:race, championship: championship) }

    context "when importing results" do
      before do
        @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/raceroom.json'), 'application/json')
        Importer.raceroom(@file, race, '', car_class.id)
      end

      it { expect(race.session_results.qualifying.present?).to be(true) }
      it { expect(race.session_results.race_1.present?).to be(true) }
      it { expect(race.session_results.race_1.order(lap_count: :desc).first.lap_count).to be > 0 }
      it { expect(race.session_laps.qualifying.present?).to be(true) }
      it { expect(race.session_laps.race_1.present?).to be(true) }
      it { expect(race.session_results.race_2.present?).to be(true) }
      it { expect(race.session_results.race_2.order(lap_count: :desc).first.lap_count).to be > 0 }
    end
  end
  
  describe '.rfactor_2' do
    let!(:game)         { FactoryBot.create(:game, name: 'rFactor 2') }
    let!(:championship) { FactoryBot.create(:championship, game: game) }
    let!(:race)         { FactoryBot.create(:race, championship: championship) }

    context "when importing qualifying results" do
      before do
        @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/rfactor-2-qualifying.xml'), 'text/xml')
        Importer.rfactor_2(@file, race, 'qualifying', car_class.id)
      end

      it { expect(race.session_results.qualifying.present?).to be(true) }
    end

    context "when importing race_1 results" do
      before do
        @file = Rack::Test::UploadedFile.new(Rails.root.join('test/fixtures/files/rfactor-2-race.xml'), 'text/xml')
        Importer.rfactor_2(@file, race, 'race_1', car_class.id)
      end

      it { expect(race.session_results.race_1.present?).to be(true) }
      it { expect(race.session_results.race_1.order(lap_count: :desc).first.lap_count).to be > 0 }
    end
  end

end
