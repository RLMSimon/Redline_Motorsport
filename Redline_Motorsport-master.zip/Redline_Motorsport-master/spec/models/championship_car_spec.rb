require 'rails_helper'

RSpec.describe ChampionshipCar, type: :model do

  it { should belong_to(:championship) }
  it { should belong_to(:car) }

  # it { should validate_uniqueness_of(:car_id).scoped_to(:championship_id) }

end
