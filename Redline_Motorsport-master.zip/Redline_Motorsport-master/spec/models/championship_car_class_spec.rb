require 'rails_helper'

RSpec.describe ChampionshipCarClass, type: :model do
  
  it { should belong_to(:championship) }
  it { should belong_to(:car_class) }

  it { should have_many(:championship_car_class_car_class_cars) }
  it { should have_many(:car_class_cars).through(:championship_car_class_car_class_cars) }

  # FIXME: Known bug: https://github.com/thoughtbot/shoulda-matchers/issues/814
  # it { should validate_uniqueness_of(:car_class).scoped_to(:championship_id) }

end
