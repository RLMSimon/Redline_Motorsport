require 'rails_helper'

RSpec.describe Car, type: :model do
  
  it { should have_many(:car_classes).through(:car_class_cars) }
  it { should have_many(:championship_cars) }
  it { should have_many(:user_championships) }

  it { should belong_to(:championship).optional }
  it { should belong_to(:game) }

  it { should validate_presence_of(:name) }
  it { should validate_uniqueness_of(:name).scoped_to(:game_id) }

end
