require 'rails_helper'

RSpec.describe TeamRegistration, type: :model do
  
  it { should belong_to(:car) }
  it { should belong_to(:car_class) }
  it { should belong_to(:championship) }
  it { should belong_to(:team) }

  it { should validate_presence_of(:car_class) }

  # it { should validate_uniqueness_of(:user).scoped_to(:championship_id).with_message('has already joined this championship.') }

  # describe '#must_belong_to_open_championship' do
    # let!(:car_class) { FactoryBot.create(:car_class) }
    # let!(:championship) { FactoryBot.create(:championship, accepting_registrations: false) }
    # let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 5) }
    # let(:team_registration) { FactoryBot.build(:team_registration, championship: championship, car_class: car_class) }

    # it { expect{ team_registration.save! }.to raise_error(ActiveRecord::RecordInvalid) }
  # end

  describe '#must_have_unique_participating_driver_ids' do
    let(:user)                { FactoryBot.create(:user) }
    let(:user_2)              { FactoryBot.create(:user) }
    let(:user_3)              { FactoryBot.create(:user) }
    let(:team_registration_1) { FactoryBot.build(:team_registration, participating_driver_ids: [user.id, user_2.id, user_3.id]) }
    let(:team_registration_2) { FactoryBot.build(:team_registration, participating_driver_ids: [user.id, user_2.id, user_2.id]) }

    it { expect{ team_registration_1.save! }.not_to raise_error }
    it { expect{ team_registration_2.save! }.to raise_error(ActiveRecord::RecordInvalid) }
  end

  describe '#must_have_unqiue_participating_driver_ids_per_championship' do
    let!(:user)               { FactoryBot.create(:user) }
    let!(:user_2)             { FactoryBot.create(:user) }
    let!(:user_3)             { FactoryBot.create(:user) }
    let!(:user_4)             { FactoryBot.create(:user) }
    let!(:user_5)             { FactoryBot.create(:user) }
    let!(:championship)       { FactoryBot.create(:championship, teams_enabled: true) }
    let!(:team_registration_1) { FactoryBot.create(:team_registration, championship: championship, participating_driver_ids: [user.id, user_2.id]) }
    let!(:team_registration_2) { FactoryBot.create(:team_registration, championship: championship, participating_driver_ids: [user_3.id, user_4.id]) }
    let!(:team_registration_3) { FactoryBot.build(:team_registration, championship: championship, participating_driver_ids: [user_5.id, user_4.id]) }

    it { expect{ team_registration_3.save! }.to raise_error(ActiveRecord::RecordInvalid) }
  end

  describe '#must_not_exceed_max_reserves' do
    let!(:car_class)              { FactoryBot.create(:car_class) }
    let!(:championship)           { FactoryBot.create(:championship, max_reserves: 2, teams_enabled: true) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 0) }
    let!(:team_registration_1)    { FactoryBot.create(:team_registration, championship: championship, car_class: car_class) }
    let!(:team_registration_2)    { FactoryBot.create(:team_registration, championship: championship, car_class: car_class) }
    let!(:team_registration_3)    { FactoryBot.build(:team_registration, championship: championship, car_class: car_class) }

    it { expect{ team_registration_3.save! }.to raise_error(ActiveRecord::RecordInvalid) }
  end

  describe '#participant' do
    let!(:team)                { FactoryBot.create(:team) }
    let!(:team_registration)   { FactoryBot.create(:team_registration, team: team) }

    it { expect(team_registration.participant).to eq(team) }
  end

  describe '#signouts_remaining' do
    let!(:team)                { FactoryBot.create(:team) }
    let!(:team_2)              { FactoryBot.create(:team) }
    let!(:game)                { FactoryBot.create(:game) }
    let!(:championship)        { FactoryBot.create(:championship, game: game, max_signouts: 4) }
    let!(:team_registration)   { FactoryBot.create(:team_registration, championship: championship, team: team) }
    let!(:team_registration_2) { FactoryBot.create(:team_registration, championship: championship, team: team_2) }
    let!(:team_registration_3) { FactoryBot.create(:team_registration, team: team) }
    let!(:race_signout)        { FactoryBot.create(:race_signout, signoutable: team_registration) }
    let!(:race_signout_2)      { FactoryBot.create(:race_signout, signoutable: team_registration_2) }
    let!(:race_signout_3)      { FactoryBot.create(:race_signout, signoutable: team_registration_3) }

    it { expect(team_registration.signouts_remaining).to eq(3) }
  end

  # PRIVATE

  describe '#handle_unregistration!' do
    let!(:car_class)              { FactoryBot.create(:car_class) }
    let!(:championship)           { FactoryBot.create(:championship, teams_enabled: true) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 1) }
    let!(:team_registration_1)    { FactoryBot.create(:team_registration, championship: championship, car_class: car_class) }
    let!(:team_registration_2)    { FactoryBot.create(:team_registration, championship: championship, car_class: car_class) }
    let!(:team_registration_3)    { FactoryBot.create(:team_registration, championship: championship, car_class: car_class) }

    context "when doing nothing" do
      before { team_registration_3.save }
      it { expect(team_registration_2.reload.reserve?).to eq(true) }
    end

    context "when disqualifying" do
      before { team_registration_3.update(disqualified: true) }
      it { expect(team_registration_2.reload.reserve?).to eq(false) }
    end

    context "when deleting registration" do
      before { team_registration_3.destroy }
      it { expect(team_registration_2.reload.reserve?).to eq(false) }
    end
  end

  describe '#must_not_have_missing_attributes' do
    let!(:user)              { FactoryBot.create(:user, steam64_id: nil, real_name: nil) }
    let!(:game)              { FactoryBot.create(:game, required_user_attributes: ['steam64_id', 'real_name']) }
    let!(:championship)      { FactoryBot.create(:championship, game: game) }
    let!(:team)              { FactoryBot.create(:team) }
    let!(:team_member)       { FactoryBot.create(:team_member, team: team, user: user) }
    let!(:team_registration) { FactoryBot.build(:team_registration, championship: championship, team: team, participating_driver_ids: [user.id]) }

    it { expect{ team_registration.save! }.to raise_error(ActiveRecord::RecordInvalid) }
  end

  describe '#set_reserve!' do
    let!(:car_class)              { FactoryBot.create(:car_class) }
    let!(:championship)           { FactoryBot.create(:championship, teams_enabled: true) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 1) }
    let!(:team_registration_1)    { FactoryBot.create(:team_registration, championship: championship, car_class: car_class) }
    let!(:team_registration_2)    { FactoryBot.create(:team_registration, championship: championship, car_class: car_class) }

    it { expect(team_registration_1.reload.reserve?).to eq(false) }
    it { expect(team_registration_2.reload.reserve?).to eq(true) }
  end

end
