require 'rails_helper'

RSpec.describe Game, type: :model do
  
  it { should have_many(:cars) }
  it { should have_many(:car_classes) }
  it { should have_many(:championships) }

end
