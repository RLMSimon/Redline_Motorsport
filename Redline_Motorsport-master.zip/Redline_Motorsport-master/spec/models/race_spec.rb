require 'rails_helper'

RSpec.describe Race, type: :model do
  
  it { should belong_to(:championship) }

  it { should have_many(:incident_reports) }
  it { should have_many(:session_incidents) }
  it { should have_many(:session_laps) }
  it { should have_many(:session_results) }

  it { should validate_presence_of(:starts_at) }
  it { should validate_presence_of(:track) }

  describe '#assign_dns_for_missing_registrants!' do
    context "when registrants are users" do
      let!(:user_1)                 { FactoryBot.create(:user) }
      let!(:user_2)                 { FactoryBot.create(:user) }
      let!(:user_3)                 { FactoryBot.create(:user) }
      let!(:user_4)                 { FactoryBot.create(:user) }
      let!(:user_5)                 { FactoryBot.create(:user) }
      let!(:user_6)                 { FactoryBot.create(:user) }
      let!(:user_7)                 { FactoryBot.create(:user) }
      let!(:car_class)              { FactoryBot.create(:car_class) }
      let!(:championship)           { FactoryBot.create(:championship, score_matrix: [25, 20, 15], fastest_lap_bonus: 2) }
      let!(:championship_car_class) { FactoryBot.create(:championship_car_class, car_class: car_class, championship: championship) }
      let!(:user_championship_1)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_1) }
      let!(:user_championship_2)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_2) }
      let!(:user_championship_3)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_3) }
      let!(:user_championship_4)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_4) }
      let!(:user_championship_5)    { FactoryBot.create(:user_championship, championship: championship, user: user_5) }
      let!(:user_championship_6)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_6, disqualified: true) }
      let!(:user_championship_7)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_7) }
      let!(:race)                   { FactoryBot.create(:race, championship: championship) }    
      let!(:session_1_results_1)    { FactoryBot.create(:session_result, :for_user, race: race, sessionable: user_1, car_class: car_class, lap_count: 10, total_time: 9000, session_type: 'race_1') }
      let!(:session_1_results_2)    { FactoryBot.create(:session_result, :for_user, race: race, sessionable: user_2, car_class: car_class, lap_count: 10, total_time: 10000, session_type: 'race_1') }
      let!(:session_1_results_3)    { FactoryBot.create(:session_result, :for_user, race: race, sessionable: user_3, car_class: car_class, lap_count: 10, total_time: 11000, session_type: 'race_1') }
      let!(:race_signout)           { FactoryBot.create(:race_signout, race: race, signoutable: user_championship_7) }

      before do
        race.assign_dns_for_missing_registrants!(car_class.id, 'race_1')
      end

      it { expect(race.session_results.race_1.find_by(sessionable: user_4).dns?).to be(true) }
      it { expect(race.session_results.race_1.find_by(sessionable: user_4).penalty_points).to eq(championship.missed_race_penalty) }
      it { expect(race.session_results.race_1.where(sessionable: user_5).present?).to be(false) }
      it { expect(race.session_results.race_1.where(sessionable: user_6).present?).to be(false) }
      it { expect(race.session_results.race_1.where(sessionable: user_7).present?).to be(false) }
    end
    
    context "when registrants are teams" do
      let!(:team_1)                 { FactoryBot.create(:team) }
      let!(:team_2)                 { FactoryBot.create(:team) }
      let!(:team_3)                 { FactoryBot.create(:team) }
      let!(:team_4)                 { FactoryBot.create(:team) }
      let!(:team_5)                 { FactoryBot.create(:team) }
      let!(:team_6)                 { FactoryBot.create(:team) }
      let!(:team_7)                 { FactoryBot.create(:team) }
      let!(:car_class)              { FactoryBot.create(:car_class) }
      let!(:championship)           { FactoryBot.create(:championship, score_matrix: [25, 20, 15], fastest_lap_bonus: 2, teams_enabled: true) }
      let!(:championship_car_class) { FactoryBot.create(:championship_car_class, car_class: car_class, championship: championship) }
      let!(:team_registration_1)    { FactoryBot.create(:team_registration, car_class: car_class, championship: championship, team: team_1) }
      let!(:team_registration_2)    { FactoryBot.create(:team_registration, car_class: car_class, championship: championship, team: team_2) }
      let!(:team_registration_3)    { FactoryBot.create(:team_registration, car_class: car_class, championship: championship, team: team_3) }
      let!(:team_registration_4)    { FactoryBot.create(:team_registration, car_class: car_class, championship: championship, team: team_4) }
      let!(:team_registration_5)    { FactoryBot.create(:team_registration, championship: championship, team: team_5) }
      let!(:team_registration_6)    { FactoryBot.create(:team_registration, car_class: car_class, championship: championship, team: team_6, disqualified: true) }
      let!(:team_registration_7)    { FactoryBot.create(:team_registration, car_class: car_class, championship: championship, team: team_7) }
      let!(:race)                   { FactoryBot.create(:race, championship: championship) }    
      let!(:session_1_results_1)    { FactoryBot.create(:session_result, :for_team, race: race, sessionable: team_1, car_class: car_class, lap_count: 10, total_time: 9000, session_type: 'race_1') }
      let!(:session_1_results_2)    { FactoryBot.create(:session_result, :for_team, race: race, sessionable: team_2, car_class: car_class, lap_count: 10, total_time: 10000, session_type: 'race_1') }
      let!(:session_1_results_3)    { FactoryBot.create(:session_result, :for_team, race: race, sessionable: team_3, car_class: car_class, lap_count: 10, total_time: 11000, session_type: 'race_1') }
      let!(:race_signout)           { FactoryBot.create(:race_signout, race: race, signoutable: team_registration_7) }

      before do
        race.assign_dns_for_missing_registrants!(car_class.id, 'race_1')
      end

      it { expect(race.session_results.race_1.find_by(sessionable: team_4).dns?).to be(true) }
      it { expect(race.session_results.race_1.find_by(sessionable: team_4).penalty_points).to eq(championship.missed_race_penalty) }
      it { expect(race.session_results.race_1.where(sessionable: team_5).present?).to be(false) }
      it { expect(race.session_results.race_1.where(sessionable: team_6).present?).to be(false) }
      it { expect(race.session_results.race_1.where(sessionable: team_7).present?).to be(false) }
    end
  end

  describe '#calculate_points' do
    context "when race is for teams" do
      let!(:team_1)                 { FactoryBot.create(:team) }
      let!(:team_2)                 { FactoryBot.create(:team) }
      let!(:team_3)                 { FactoryBot.create(:team) }
      let!(:car_class)              { FactoryBot.create(:car_class) }
      let!(:championship)           { FactoryBot.create(:championship, score_matrix: [25, 20, 15], fastest_lap_bonus: 2, teams_enabled: true) }
      let!(:championship_car_class) { FactoryBot.create(:championship_car_class, car_class: car_class, championship: championship) }
      let!(:team_registration_1)    { FactoryBot.create(:team_registration, car_class: car_class, championship: championship, team: team_1) }
      let!(:team_registration_2)    { FactoryBot.create(:team_registration, car_class: car_class, championship: championship, team: team_2) }
      let!(:team_registration_3)    { FactoryBot.create(:team_registration, car_class: car_class, championship: championship, team: team_3) }
      let!(:race)                   { FactoryBot.create(:race, championship: championship) }
      let!(:session_1_results_1)    { FactoryBot.create(:session_result, :for_user, race: race, sessionable: team_1, car_class: car_class, lap_count: 10, best_lap: 100, total_time: 10000, session_type: 'race_1') }
      let!(:session_1_results_2)    { FactoryBot.create(:session_result, :for_user, race: race, sessionable: team_2, car_class: car_class, lap_count: 10, best_lap: 110, total_time: 11000, session_type: 'race_1') }
      let!(:session_1_results_dnf)  { FactoryBot.create(:session_result, :for_user, race: race, sessionable: team_3, car_class: car_class, lap_count: 10, best_lap: 90, total_time: 9000, dnf: true, session_type: 'race_1') }

      before do
        race.calculate_points('race_1')

        session_1_results_1.reload
        session_1_results_2.reload
        session_1_results_dnf.reload
        team_registration_1.reload
        team_registration_2.reload
        team_registration_3.reload
      end

      it { expect(session_1_results_1.points_total).to eq(25 + championship.fastest_lap_bonus) }
      it { expect(session_1_results_2.points_total).to eq(20) }
      it { expect(session_1_results_dnf.points_total).to eq(0) }
      it { expect(team_registration_1.championship_score).to eq(25 + championship.fastest_lap_bonus) }
      it { expect(team_registration_2.championship_score).to eq(20) }
      it { expect(team_registration_1.position_cache).to eq(1) }
      it { expect(team_registration_2.position_cache).to eq(2) }
      it { expect(team_registration_3.position_cache).to eq(3) }
      # it { expect(user_1.reload.total_races_started).to eq(1) }
    end

    context "when race is for individuals" do
      context "when circumstances are normal" do
        let!(:user_1)                 { FactoryBot.create(:user) }
        let!(:user_2)                 { FactoryBot.create(:user) }
        let!(:user_3)                 { FactoryBot.create(:user) }
        let!(:car_class)              { FactoryBot.create(:car_class) }
        let!(:championship)           { FactoryBot.create(:championship, score_matrix: [25, 20, 15], fastest_lap_bonus: 2) }
        let!(:championship_car_class) { FactoryBot.create(:championship_car_class, car_class: car_class, championship: championship) }
        let!(:user_championship_1)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_1) }
        let!(:user_championship_2)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_2) }
        let!(:user_championship_3)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_3) }
        let!(:race)                   { FactoryBot.create(:race, championship: championship) }
        let!(:session_1_results_1)    { FactoryBot.create(:session_result, :for_user, race: race, sessionable: user_1, car_class: car_class, lap_count: 10, best_lap: 100, total_time: 10000, session_type: 'race_1') }
        let!(:session_1_results_2)    { FactoryBot.create(:session_result, :for_user, race: race, sessionable: user_2, car_class: car_class, lap_count: 10, best_lap: 110, total_time: 11000, session_type: 'race_1') }
        let!(:session_1_results_dnf)  { FactoryBot.create(:session_result, :for_user, race: race, sessionable: user_3, car_class: car_class, lap_count: 10, best_lap: 90, total_time: 9000, dnf: true, session_type: 'race_1') }

        before do
          race.calculate_points('race_1')

          session_1_results_1.reload
          session_1_results_2.reload
          session_1_results_dnf.reload
          user_championship_1.reload
          user_championship_2.reload
          user_championship_3.reload
        end

        it { expect(session_1_results_1.points_total).to eq(25 + championship.fastest_lap_bonus) }
        it { expect(session_1_results_2.points_total).to eq(20) }
        it { expect(session_1_results_dnf.points_total).to eq(0) }
        it { expect(user_championship_1.championship_score).to eq(25 + championship.fastest_lap_bonus) }
        it { expect(user_championship_2.championship_score).to eq(20) }
        it { expect(user_championship_1.position_cache).to eq(1) }
        it { expect(user_championship_2.position_cache).to eq(2) }
        it { expect(user_championship_3.position_cache).to eq(3) }
        it { expect(user_1.reload.total_races_started).to eq(1) }
      end

      context "when a driver got a dns" do
        let!(:user_1)                 { FactoryBot.create(:user) }
        let!(:user_2)                 { FactoryBot.create(:user) }
        let!(:user_3)                 { FactoryBot.create(:user) }
        let!(:car_class)              { FactoryBot.create(:car_class) }
        let!(:championship)           { FactoryBot.create(:championship, score_matrix: [25, 20, 15], fastest_lap_bonus: 2) }
        let!(:championship_car_class) { FactoryBot.create(:championship_car_class, car_class: car_class, championship: championship) }
        let!(:user_championship_1)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_1) }
        let!(:user_championship_2)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_2) }
        let!(:user_championship_3)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_3) }
        let!(:race)                   { FactoryBot.create(:race, championship: championship) }
        let!(:session_1_results_1)    { FactoryBot.create(:session_result, :for_user, race: race, sessionable: user_1, car_class: car_class, lap_count: 10, best_lap: 100, total_time: 10000, session_type: 'race_1') }
        let!(:session_1_results_2)    { FactoryBot.create(:session_result, :for_user, race: race, sessionable: user_2, car_class: car_class, lap_count: 10, best_lap: 110, total_time: 11000, session_type: 'race_1') }
        let!(:session_1_results_dnf)  { FactoryBot.create(:session_result, :for_user, race: race, sessionable: user_3, car_class: car_class, lap_count: 10, best_lap: 90, total_time: 9000, dnf: true, session_type: 'race_1') }

        before do
          session_1_results_1.update(dns: true, lap_count: 0)
          race.calculate_points('race_1')

          session_1_results_1.reload
          session_1_results_2.reload
          user_championship_1.reload
          user_championship_2.reload
        end

        it { expect(session_1_results_1.points_total).to eq(0) }
        it { expect(session_1_results_2.points_total).to eq(25) }
        it { expect(user_championship_1.championship_score).to eq(0) }
        it { expect(user_championship_2.championship_score).to eq(25) }
        it { expect(user_championship_1.position_cache).to eq(2) }
        it { expect(user_championship_2.position_cache).to eq(1) }
      end

      context "when penalties are assigned" do
        let!(:car_class)              { FactoryBot.create(:car_class) }
        let!(:championship_car_class) { FactoryBot.create(:championship_car_class, car_class: car_class, championship: championship) }
        let!(:championship)           { FactoryBot.create(:championship, score_matrix: [10, 9, 8, 7, 6, 5, 4, 3, 2, 1], fastest_lap_bonus: 0) }
        let!(:race)                   { FactoryBot.create(:race, championship: championship) }

        before do
          6.times{ |i| instance_variable_set("@user_#{i}", FactoryBot.create(:user)) }
          6.times{ |i| instance_variable_set("@user_championship_#{i}", FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: instance_variable_get("@user_#{i}"))) }
          6.times{ |i| instance_variable_set("@session_1_results_#{i}", FactoryBot.create(:session_result, :for_user, race: race, sessionable: instance_variable_get("@user_#{i}"), car_class: car_class, lap_count: 10, total_time: 1000+i, session_type: 'race_1')) }

          @session_1_results_0.update(penalty_points: 1)

          race.calculate_points('race_1')
        end

        it { expect(@session_1_results_0.reload.points_total).to eq(10-1) }
        it { expect(@session_1_results_1.reload.points_total).to eq(9) }
        it { expect(@session_1_results_2.reload.points_total).to eq(8) }

        # Even though P1 was penalized, we're ok with his recorded position still being P1.
        # This could change down the road.
        it { expect(@session_1_results_0.reload.position_cache).to eq(1) }
        it { expect(@session_1_results_1.reload.position_cache).to eq(2) }
        it { expect(@session_1_results_2.reload.position_cache).to eq(3) }
      end
      
      context "when race is a warm up event" do
        let!(:user_1)                 { FactoryBot.create(:user) }
        let!(:car_class)              { FactoryBot.create(:car_class) }
        let!(:championship)           { FactoryBot.create(:championship, score_matrix: [25, 20, 15], fastest_lap_bonus: 2) }
        let!(:championship_car_class) { FactoryBot.create(:championship_car_class, car_class: car_class, championship: championship) }
        let!(:user_championship_1)    { FactoryBot.create(:user_championship, car_class: car_class, championship: championship, user: user_1) }
        let!(:race)                   { FactoryBot.create(:race, championship: championship, warm_up: true) }
        let!(:session_1_results_1)    { FactoryBot.create(:session_result, :for_user, race: race, sessionable: user_1, car_class: car_class, lap_count: 10, best_lap: 100, total_time: 10000, session_type: 'race_1') }

        before do
          race.calculate_points('race_1')
          session_1_results_1.reload
        end

        it { expect(session_1_results_1.points_total.to_i).to eq(0) }
        # it { expect(user_1.reload.total_races_started).to eq(1) }
      end
    end
  end

  describe '#ended?' do
    let!(:race_1) { FactoryBot.create(:race, starts_at: 1.week.ago) }
    let!(:race_2) { FactoryBot.create(:race, starts_at: 1.week.from_now) }
    
    context 'race 1 did not start yet' do
      before do
        allow(Time).to receive(:now).and_return(2.weeks.ago)
      end

      it { expect(race_1.ended?()).to be(false) }
      it { expect(race_2.ended?()).to be(false) }      
    end

    context 'race 1 ended, but race 2 did not' do
      it { expect(race_1.ended?()).to be(true) }
      it { expect(race_2.ended?()).to be(false) }      
    end

    context 'both races ended' do
      before do
        allow(Time).to receive(:now).and_return(2.weeks.from_now)
      end

      it { expect(race_1.ended?()).to be(true) }
      it { expect(race_2.ended?()).to be(true) }   
    end
  end

  describe '#reportable?' do
    let!(:race_1) { FactoryBot.create(:race, starts_at: 1.week.from_now) }
    let!(:race_2) { FactoryBot.create(:race, starts_at: 2.hours.ago) }
    let!(:race_3) { FactoryBot.create(:race, starts_at: 2.days.ago) }

    it { expect(race_1.reportable?).to be(false) }
    it { expect(race_2.reportable?).to be(true) }
    it { expect(race_3.reportable?).to be(false) }
  end

  describe '#round' do
    let!(:championship) { FactoryBot.create(:championship) }
    let!(:race_1)       { FactoryBot.create(:race, championship: championship, starts_at: 1.week.from_now) }
    let!(:race_2)       { FactoryBot.create(:race, championship: championship, starts_at: 2.weeks.from_now) }

    it { expect(race_1.round).to eq(1) }
    it { expect(race_2.round).to eq(2) }
  end

end
