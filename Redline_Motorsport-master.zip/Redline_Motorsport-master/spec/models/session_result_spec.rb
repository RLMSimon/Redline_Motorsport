require 'rails_helper'

RSpec.describe SessionResult, type: :model do
  
  it { should belong_to(:race) }

  it { should validate_presence_of(:race_id) }
  it { should validate_presence_of(:session_type) }

  describe '#position' do
    let!(:car_class)        { FactoryBot.create(:car_class) }
    let!(:championship)     { FactoryBot.create(:championship) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class) }
    let!(:race)             { FactoryBot.create(:race, championship: championship) }
    let!(:users)            { Array.new(3) { FactoryBot.create(:user) }}
    let!(:session_result_1) { FactoryBot.create(:session_result, :for_user, best_lap: 1000, total_time: 12000, race: race, points_total: 7, sessionable: users[0], car_class: car_class) }
    let!(:session_result_2) { FactoryBot.create(:session_result, :for_user, best_lap: 1010, total_time: 13000, race: race, points_total: 5, sessionable: users[1], car_class: car_class) }
    let!(:session_result_3) { FactoryBot.create(:session_result, :for_user, best_lap: 1020, total_time: 10000, race: race, points_total: 10, sessionable: users[2], car_class: car_class) }

    before do
      users.each do |user|
        FactoryBot.create(:user_championship, user: user, championship: championship, car_class: car_class)
      end
    end

    it { expect(session_result_2.position({ attr: 'best_lap', dir: 'asc' }, car_class.id)).to eq(2) }
    it { expect(session_result_2.position({ attr: 'points_total', dir: 'desc' }, car_class.id)).to eq(3) }
  end

  describe '#sibling_results' do
    let!(:race) { FactoryBot.create(:race) }
    let!(:session_results) { Array.new(3) { FactoryBot.create(:session_result, race: race) } }
    let!(:session_result_1) { FactoryBot.create(:session_result) }

    it { expect(session_results[0].sibling_results).to match_array(session_results) }
  end

  describe '#gap_to_leader' do
    let!(:car_class)        { FactoryBot.create(:car_class) }
    let!(:championship)     { FactoryBot.create(:championship) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class) }
    let!(:race)             { FactoryBot.create(:race, championship: championship) }
    let!(:users)            { Array.new(3) { FactoryBot.create(:user) }}
    let!(:session_result_1) { FactoryBot.create(:session_result, :for_user, best_lap: 1000, total_time: 11000, race: race, sessionable: users[0], car_class: car_class) }
    let!(:session_result_2) { FactoryBot.create(:session_result, :for_user, best_lap: 1010, total_time: 12000, race: race, sessionable: users[1], car_class: car_class) }
    let!(:session_result_3) { FactoryBot.create(:session_result, :for_user, best_lap: 1020, total_time: 13000, race: race, sessionable: users[2], car_class: car_class) }

    before do
      users.each do |user|
        FactoryBot.create(:user_championship, user: user, championship: championship, car_class: car_class)
      end
    end

    it { expect(session_result_1.gap_to_leader('qualifying', car_class.id)).to eq("+0.000") }
    it { expect(session_result_2.gap_to_leader('qualifying', car_class.id)).to eq("+0.010") }
    it { expect(session_result_3.gap_to_leader('qualifying', car_class.id)).to eq("+0.020") }
    it { expect(session_result_3.gap_to_leader('race_1', car_class.id)).to eq("+2.000") }
  end

end
