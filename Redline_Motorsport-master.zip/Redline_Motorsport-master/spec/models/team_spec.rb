require 'rails_helper'

RSpec.describe Team, type: :model do

  it { should have_many(:team_members) }
  it { should have_many(:team_registrations) }

  it { should validate_presence_of(:name) }

end
