require 'rails_helper'

RSpec.describe CarClass, type: :model do

  it { should have_many(:car_class_cars) }
  it { should have_many(:cars).through(:car_class_cars) }
  it { should have_many(:championship_car_classes) }
  it { should have_many(:championships).through(:championship_car_classes) }
  it { should have_many(:user_championships) }

  it { should belong_to(:game) }

  it { should validate_presence_of(:name) }

  it { should validate_uniqueness_of(:name) }

end
