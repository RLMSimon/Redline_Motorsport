require 'rails_helper'

RSpec.describe UserChampionship, type: :model do
  
  it { should belong_to(:car) }
  it { should belong_to(:car_class) }
  it { should belong_to(:championship) }
  it { should belong_to(:user) }

  it { should validate_presence_of(:car_class) }

  # it { should validate_uniqueness_of(:user).scoped_to(:championship_id).with_message('has already joined this championship.') }
  
  describe '#car_number' do

    let!(:game_1) { FactoryBot.create(:game, require_unique_livery: false) }
    let!(:game_2) { FactoryBot.create(:game, require_unique_livery: true) }
    let!(:championship_1) { FactoryBot.create(:championship, game: game_1) }
    let!(:championship_2) { FactoryBot.create(:championship, game: game_2) }
    let!(:car_class) { FactoryBot.create(:car_class) }
    let!(:user_championship_1) { FactoryBot.create(:user_championship, championship: championship_1, car_class: car_class, car_number: 11) }
    let!(:user_championship_2) { FactoryBot.build(:user_championship, championship: championship_1, car_class: car_class, car_number: 11) }
    let!(:user_championship_3) { FactoryBot.create(:user_championship, championship: championship_2, car_class: car_class, car_number: 11) }
    let!(:user_championship_4) { FactoryBot.build(:user_championship, championship: championship_2, car_class: car_class, car_number: 11) }

    context 'when not requiring unique livery' do
      it { expect { user_championship_2.save! }.not_to raise_error }
    end

    context 'when requiring unique livery' do
      it { expect {user_championship_4.save! }.to raise_error(ActiveRecord::RecordInvalid) }
    end

  end

  # describe '#must_belong_to_open_championship' do
    # let!(:car_class) { FactoryBot.create(:car_class) }
    # let!(:championship) { FactoryBot.create(:championship, accepting_registrations: false) }
    # let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 5) }
    # let(:user_championship) { FactoryBot.build(:user_championship, championship: championship, car_class: car_class) }

    # it { expect{ user_championship.save! }.to raise_error(ActiveRecord::RecordInvalid) }
  # end

  describe '#must_not_exceed_max_reserves' do
    let!(:car_class)              { FactoryBot.create(:car_class) }
    let!(:championship)           { FactoryBot.create(:championship, max_reserves: 2) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 0) }
    let!(:user_championships)     { Array.new(2) { FactoryBot.create(:user_championship, championship: championship, car_class: car_class) }}
    let!(:user_championship)      { FactoryBot.build(:user_championship, championship: championship, car_class: car_class) }

    it { expect{ user_championship.save! }.to raise_error(ActiveRecord::RecordInvalid) }
  end

  describe '#must_not_have_missing_attributes' do
    let!(:user)              { FactoryBot.create(:user, steam64_id: nil, real_name: nil) }
    let!(:game)              { FactoryBot.create(:game, required_user_attributes: ['steam64_id', 'real_name']) }
    let!(:championship)      { FactoryBot.create(:championship, game: game) }
    let!(:user_championship) { FactoryBot.build(:user_championship, championship: championship, user: user) }

    it { expect{ user_championship.save! }.to raise_error(ActiveRecord::RecordInvalid) }
  end

  describe '#participant' do
    let!(:user)                { FactoryBot.create(:user) }
    let!(:user_championship)   { FactoryBot.create(:user_championship, user: user) }

    it { expect(user_championship.participant).to eq(user) }
  end

  describe '#signouts_remaining' do
    let!(:user)                { FactoryBot.create(:user) }
    let!(:user_2)              { FactoryBot.create(:user) }
    let!(:game)                { FactoryBot.create(:game) }
    let!(:championship)        { FactoryBot.create(:championship, game: game, max_signouts: 4) }
    let!(:user_championship)   { FactoryBot.create(:user_championship, championship: championship, user: user) }
    let!(:user_championship_2) { FactoryBot.create(:user_championship, championship: championship, user: user_2) }
    let!(:user_championship_3) { FactoryBot.create(:user_championship, user: user) }
    let!(:race_signout)        { FactoryBot.create(:race_signout, signoutable: user_championship) }
    let!(:race_signout_2)      { FactoryBot.create(:race_signout, signoutable: user_championship_2) }
    let!(:race_signout_3)      { FactoryBot.create(:race_signout, signoutable: user_championship_3) }

    it { expect(user_championship.signouts_remaining).to eq(3) }
  end

  # describe '#ensure_destroyable' do
  #   let!(:championship_1)      { FactoryBot.create(:championship) }
  #   let!(:race_1)              { FactoryBot.create(:race, championship: championship_1, starts_at: 1.week.from_now) }
  #   let!(:user_championship_1) { FactoryBot.create(:user_championship, championship: championship_1) }
  #   let!(:championship_2)      { FactoryBot.create(:championship) }
  #   let!(:race_2)              { FactoryBot.create(:race, championship: championship_2, starts_at: 1.week.ago) }
  #   let!(:user_championship_2) { FactoryBot.create(:user_championship, championship: championship_2) }

  #   before do
  #     user_championship_1.destroy
  #     user_championship_2.destroy
  #   end

  #   it { expect(UserChampionship.find_by(id: user_championship_1.id).blank?).to be true }
  #   it { expect(user_championship_2.reload.disqualified?).to be true }
  # end

  # PRIVATE

  describe '#handle_roles!' do
    let!(:car_class)                 { FactoryBot.create(:car_class) }
    let!(:championship)              { FactoryBot.create(:championship) }
    let!(:user_championship_reserve) { FactoryBot.create(:user_championship, championship: championship, reserve: true) }
    let!(:user_championship_active)  { FactoryBot.create(:user_championship, championship: championship, reserve: false) }

    before { user_championship_active.update_column(:reserve, false) }

    it 'when promoting a reserve' do
      expect(user_championship_reserve).to receive(:role_add)
      user_championship_reserve.update(reserve: false)
    end
    
    it 'when demoting an active driver' do
      expect(user_championship_active).to receive(:role_remove)
      user_championship_active.update(reserve: true)
    end
  end

  describe '#handle_unregistration!' do
    let!(:car_class)              { FactoryBot.create(:car_class) }
    let!(:championship)           { FactoryBot.create(:championship) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 1) }
    let!(:user_championship_1)    { FactoryBot.create(:user_championship, championship: championship, car_class: car_class) }
    let!(:user_championship_2)    { FactoryBot.create(:user_championship, championship: championship, car_class: car_class) }
    let!(:user_championship_3)    { FactoryBot.create(:user_championship, championship: championship, car_class: car_class) }

    context "when doing nothing" do
      before { user_championship_3.save }
      it { expect(user_championship_2.reload.reserve?).to eq(true) }
    end

    context "when disqualifying proper driver" do
      before { user_championship_1.update(disqualified: true) }
      it { expect(user_championship_2.reload.reserve?).to eq(false) }
    end
    
    context "when disqualifying reserver driver" do
      before { user_championship_3.update(disqualified: true) }
      # it { expect(user_championship_2.reload.reserve?).to eq(true) }
    end

    context "when deleting registration" do
      before { user_championship_3.destroy }
      it { expect(user_championship_2.reload.reserve?).to eq(false) }
    end
  end

  describe '#set_reserve!' do
    let!(:car_class)              { FactoryBot.create(:car_class) }
    let!(:championship)           { FactoryBot.create(:championship) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 1) }
    let!(:user_championship_1)    { FactoryBot.create(:user_championship, championship: championship, car_class: car_class) }
    let!(:user_championship_2)    { FactoryBot.create(:user_championship, championship: championship, car_class: car_class) }

    it { expect(user_championship_1.reload.reserve?).to eq(false) }
    it { expect(user_championship_2.reload.reserve?).to eq(true) }
  end

end
