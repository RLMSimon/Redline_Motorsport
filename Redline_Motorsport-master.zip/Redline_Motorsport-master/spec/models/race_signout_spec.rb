require 'rails_helper'

RSpec.describe RaceSignout, type: :model do
  
  it { should belong_to(:race) }
  it { should belong_to(:signoutable) }

  describe '#can_sign_back_in?' do
    let!(:race_1) { FactoryBot.create(:race, starts_at: 1.day.from_now) }
    let!(:race_2) { FactoryBot.create(:race, starts_at: 1.hour.ago) }
    let!(:race_signout_1) { FactoryBot.create(:race_signout, race: race_1) }
    let!(:race_signout_2) { FactoryBot.create(:race_signout, race: race_2) }

    it { expect(race_signout_1.can_sign_back_in?).to be true }
    it { expect(race_signout_2.can_sign_back_in?).to be false }
  end

  describe '#user_must_have_available_signouts' do
    let!(:championship)      { FactoryBot.create(:championship, max_signouts: 2) }
    let!(:user_championship) { FactoryBot.create(:user_championship, championship: championship) }
    let!(:race_signout_1)    { FactoryBot.create(:race_signout, signoutable: user_championship) }
    let!(:race_signout_2)    { FactoryBot.create(:race_signout, signoutable: user_championship) }
    let!(:race_signout_3)    { FactoryBot.build(:race_signout, signoutable: user_championship) }

    it { expect { race_signout_3.save! }.to raise_error(ActiveRecord::RecordInvalid) }
  end

end
