require 'rails_helper'

RSpec.describe Affiliate, type: :model do

  it { should validate_presence_of(:name) }
  it { should validate_presence_of(:url) }
  
  describe '#image_path' do
    let(:affiliate) { FactoryBot.create(:affiliate, name: 'foo') }

    it { expect(affiliate.image_path).to eq('affiliates/thumbnail/foo.jpg') }
  end

end
