require 'rails_helper'

RSpec.describe CarClassCar, type: :model do
  
  it { should belong_to(:car) }
  it { should belong_to(:car_class) }

  it { should have_many(:championship_car_class_car_class_cars) }
  it { should have_many(:car_class_cars).through(:championship_car_class_car_class_cars) }

  # it { should validate_uniqueness_of(:car_id).scoped_to(:car_class_id) }

  describe '#name' do
    let(:car) { FactoryBot.create(:car, name: 'Supa GT') }
    let(:car_class_car) { FactoryBot.create(:car_class_car, car: car) }

    it { expect(car_class_car.name).to eq('Supa GT') }
  end

end
