require 'rails_helper'

RSpec.describe ChampionshipCarClassCarClassCar, type: :model do
  
  it { should belong_to(:championship_car_class) }
  it { should belong_to(:car_class_car) }

  # it { should validate_uniqueness_of(:car_class_car_id).scoped_to(:championship_car_class_id) }

end
