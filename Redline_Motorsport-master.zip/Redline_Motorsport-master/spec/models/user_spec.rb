require 'rails_helper'

RSpec.describe User, type: :model do
  
  it { should have_many(:session_results) }
  it { should have_many(:user_championships) }
  it { should have_many(:championships).through(:user_championships) }
  it { should have_many(:incident_reports) }
  it { should have_many(:team_members) }
  it { should have_many(:teams).through(:team_members) }

  it { should validate_uniqueness_of(:raceroom_username) }
  it { should validate_uniqueness_of(:steam64_id) }
  it { should validate_length_of(:steam64_id).is_equal_to(17) }
  it { should validate_uniqueness_of(:username) }

  describe 'steam64 exclusion validation' do
    let(:user) { FactoryBot.build(:user, steam64_id: '76561197960287930') }

    it { expect{ user.save! }.to raise_error(ActiveRecord::RecordInvalid) }
  end

  describe '#avatar' do
    let(:user) { FactoryBot.create(:user, avatar: 'http://foo.com/image.jpg', steam64_id: '76561197960287931') }

    it { expect(user.avatar).to eq('http://foo.com/image.jpg') }
  end

  describe '#missing_attributes_for' do
    let!(:user_1) { FactoryBot.create(:user, steam64_id: '76561197960287931', real_name: nil) }
    let!(:game_1) { FactoryBot.create(:game) }
    let!(:game_2) { FactoryBot.create(:game, required_user_attributes: ['steam64_id', 'real_name']) }

    it { expect(user_1.missing_attributes_for(game_1).present?).to be(false) }
    it { expect(user_1.missing_attributes_for(game_2).present?).to be(true) }
  end

end
