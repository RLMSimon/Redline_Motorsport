require 'rails_helper'

RSpec.describe Championship, type: :model do
  
  it { should belong_to(:game) }

  it { should have_many(:races) }
  it { should have_many(:user_championships) }
  it { should have_many(:team_registrations) }
  it { should have_many(:users).through(:user_championships) }
  it { should have_many(:championship_car_classes) }
  it { should have_many(:car_classes).through(:championship_car_classes) }

  describe '#calculate_participant_standings' do
    context "championship is for individuals" do
      let!(:user)              { FactoryBot.create(:user) }
      let!(:championship)      { FactoryBot.create(:championship, max_penalties: 10) }
      let!(:user_championship) { FactoryBot.create(:user_championship, user: user, championship: championship) }
      let!(:race)              { FactoryBot.create(:race, championship: championship) }
      let!(:race_2)            { FactoryBot.create(:race, championship: championship) }
      let!(:race_3)            { FactoryBot.create(:race, championship: championship, warm_up: true) }

      context "when circumstances are normal" do
        let!(:session_result_1) { FactoryBot.create(:session_result, :for_user, sessionable: user, race: race, session_type: 'race_1', points_given: 20, penalty_points: 1, points_total: 19) }
        let!(:session_result_2) { FactoryBot.create(:session_result, :for_user, sessionable: user, race: race_2, session_type: 'race_1', points_given: 20, penalty_points: 0, points_total: 20) }
        let!(:session_result_3) { FactoryBot.create(:session_result, :for_user, sessionable: user, race: race_3, session_type: 'race_1', points_given: 20, penalty_points: 0, points_total: 20) }

        before do
          championship.calculate_participant_standings(user.id)
          user_championship.reload
          user.reload
        end

        it { expect(user_championship.championship_points).to eq(40) }
        it { expect(user_championship.championship_penalties).to eq(1) }
        it { expect(user_championship.championship_score).to eq(39) }
        it { expect(user.total_races_started).to eq(3) }
        it { expect(user.total_wins.present?).to be true }
        it { expect(user.total_podiums.present?).to be true }
        it { expect(user.total_penalty_rate).to eq(0.0) }
      end

      context "when driver has exceeded max penalties" do
        let!(:session_result_1) { FactoryBot.create(:session_result, :for_user, sessionable: user, race: race, session_type: 'race_1', points_given: 20, penalty_points: 1, points_total: 19) }
        let!(:session_result_2) { FactoryBot.create(:session_result, :for_user, sessionable: user, race: race_2, session_type: 'race_1', points_given: 20, penalty_points: 10, points_total: 10) }

        before do
          championship.calculate_participant_standings(user.id)
          user_championship.reload
        end

        it { expect(user_championship.disqualified?).to be(true) }
      end
    end

    context "when championship is for teams" do
      let!(:championship)      { FactoryBot.create(:championship, max_penalties: 10, teams_enabled: true) }
      let!(:team)              { FactoryBot.create(:team) }
      let!(:team_registration) { FactoryBot.create(:team_registration, team: team, championship: championship) }
      let!(:race)              { FactoryBot.create(:race, championship: championship) }
      let!(:race_2)            { FactoryBot.create(:race, championship: championship) }
      let!(:race_3)            { FactoryBot.create(:race, championship: championship, warm_up: true) }
      let!(:session_result_1)  { FactoryBot.create(:session_result, :for_team, sessionable: team, race: race, session_type: 'race_1', points_given: 20, penalty_points: 1, points_total: 19) }
      let!(:session_result_2)  { FactoryBot.create(:session_result, :for_team, sessionable: team, race: race_2, session_type: 'race_1', points_given: 20, penalty_points: 0, points_total: 20) }
      let!(:session_result_3)  { FactoryBot.create(:session_result, :for_team, sessionable: team, race: race_3, session_type: 'race_1', points_given: 20, penalty_points: 0, points_total: 20) }

      before do
        championship.calculate_participant_standings(team.id)
        team_registration.reload
        team.reload
      end

      it { expect(team_registration.championship_points).to eq(40) }
      it { expect(team_registration.championship_penalties).to eq(1) }
      it { expect(team_registration.championship_score).to eq(39) }
      it { expect(team.total_races_started).to eq(3) }
      it { expect(team.total_wins.present?).to be true }
      it { expect(team.total_podiums.present?).to be true }
      it { expect(team.total_penalty_rate).to eq(0.0) }
    end
  end

  describe '#capacity' do
    let!(:championship) { FactoryBot.create(:championship) }
    let!(:car_class_1)  { FactoryBot.create(:car_class) }
    let!(:car_class_2)  { FactoryBot.create(:car_class) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class_1, capacity: 10) }
    let!(:championship_car_class_2) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class_2, capacity: 10) }

    it { expect(championship.capacity).to eq(20) }
  end

  describe '#capacity_by_class' do
    let!(:championship) { FactoryBot.create(:championship) }
    let!(:car_class_1)  { FactoryBot.create(:car_class) }
    let!(:car_class_2)  { FactoryBot.create(:car_class) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class_1, capacity: 10) }
    let!(:championship_car_class_2) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class_2, capacity: 10) }

    it { expect(championship.capacity_by_class(car_class_1)).to eq(10) }
  end

  describe '#capacity_met?' do
    context "when capacity is not met" do
      let!(:car_class) { FactoryBot.create(:car_class) }
      let!(:championship) { FactoryBot.create(:championship, teams_enabled: true) }
      let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 5) }
      let!(:team_registration) { FactoryBot.create(:team_registration, championship: championship, car_class: car_class) }

      it { expect(championship.capacity_met?(team_registration)).to be false }
    end
    
    context "when capacity is met" do
      let!(:car_class) { FactoryBot.create(:car_class) }
      let!(:championship) { FactoryBot.create(:championship, teams_enabled: true) }
      let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 5) }
      let!(:team_registrations) { Array.new(5) { FactoryBot.create(:team_registration, championship: championship, car_class: car_class) }}

      it { expect(championship.capacity_met?(team_registrations.first)).to be true }
    end
  end
  
  describe '#cars' do
    let!(:championship)  { FactoryBot.create(:championship) }
    let!(:car_class)     { FactoryBot.create(:car_class) }
    let!(:car)           { FactoryBot.create(:car) }
    let!(:car_2)         { FactoryBot.create(:car) }
    let!(:car_class_car) { FactoryBot.create(:car_class_car, car: car, car_class: car_class) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class) }
    let!(:championship_car_class_car_class_car) { FactoryBot.create(:championship_car_class_car_class_car, championship_car_class: championship_car_class, car_class_car: car_class_car) }

    it { expect(championship.cars).to eq([car]) }
  end

  describe '#ended?' do
    let!(:championship_1) { FactoryBot.create(:championship) }
    let!(:championship_2) { FactoryBot.create(:championship) }
    let!(:race_1)         { FactoryBot.create(:race, championship: championship_1, starts_at: 1.week.from_now) }
    let!(:race_2)         { FactoryBot.create(:race, championship: championship_2, starts_at: 1.week.ago) }

    it { expect(championship_1.ended?).to be(false) }
    it { expect(championship_2.ended?).to be(true) }
  end

  describe '#multiclass?' do
    let!(:championship_1) { FactoryBot.create(:championship) }
    let!(:championship_2) { FactoryBot.create(:championship) }
    let!(:car_class_1)    { FactoryBot.create(:car_class) }
    let!(:car_class_2)    { FactoryBot.create(:car_class) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship_1, car_class: car_class_1) }
    let!(:championship_car_class_2) { FactoryBot.create(:championship_car_class, championship: championship_1, car_class: car_class_2) }
    let!(:championship_car_class_3) { FactoryBot.create(:championship_car_class, championship: championship_2, car_class: car_class_2) }

    it { expect(championship_1.multiclass?).to be(true) }
    it { expect(championship_2.multiclass?).to be(false) }
  end

  describe '#next_reserve_driver_in_class' do
    let!(:car_class)    { FactoryBot.create(:car_class) }
    let!(:championship) { FactoryBot.create(:championship) }
    let!(:championship_car_class) { FactoryBot.create(:championship_car_class, championship: championship, car_class: car_class, capacity: 3) }
    let!(:user_1) { FactoryBot.create(:user) }
    let!(:user_2) { FactoryBot.create(:user) }
    let!(:user_3) { FactoryBot.create(:user) }
    let!(:user_4) { FactoryBot.create(:user) }
    let!(:user_5) { FactoryBot.create(:user) }
    let!(:user_6) { FactoryBot.create(:user) }
    let!(:user_championship_1) { FactoryBot.create(:user_championship, user: user_1, championship: championship, car_class: car_class) }
    let!(:user_championship_2) { FactoryBot.create(:user_championship, user: user_2, championship: championship, car_class: car_class) }
    let!(:user_championship_3) { FactoryBot.create(:user_championship, user: user_3, championship: championship, car_class: car_class) }
    let!(:user_championship_4) { FactoryBot.create(:user_championship, user: user_4, championship: championship, car_class: car_class) }
    let!(:user_championship_5) { FactoryBot.create(:user_championship, user: user_5, championship: championship, car_class: car_class) }
    let!(:user_championship_6) { FactoryBot.create(:user_championship, user: user_6, championship: championship, car_class: car_class) }

    context "when there are no disqualifications" do
      it { expect(championship.next_reserve_driver_in_class(car_class)).to eq(user_4) }
    end

    context "when there is 1 disqualification" do
      before do
        user_championship_2.update(disqualified: true)
      end

      it { expect(championship.next_reserve_driver_in_class(car_class)).to eq(user_5) }
    end

    context "when there are 2 disqualifications" do
      before do
        user_championship_2.update(disqualified: true)
        user_championship_3.update(disqualified: true)
      end

      it { expect(championship.next_reserve_driver_in_class(car_class)).to eq(user_6) }
    end
  end

  describe '#participants' do
    let!(:championship_1)    { FactoryBot.create(:championship, teams_enabled: false) }
    let!(:championship_2)    { FactoryBot.create(:championship, teams_enabled: true) }
    let!(:user)              { FactoryBot.create(:user) }
    let!(:user_championship) { FactoryBot.create(:user_championship, user: user, championship: championship_1) }
    let!(:team)              { FactoryBot.create(:team) }
    let!(:team_member)       { FactoryBot.create(:team_member, team: team, user: user) }
    let!(:team_registration) { FactoryBot.create(:team_registration, team: team, championship: championship_2) }

    it { expect(championship_1.participants).to eq([user]) }
    it { expect(championship_2.participants).to eq([team]) }
  end
  
  describe '#participant_registrations' do
    let!(:championship_1)    { FactoryBot.create(:championship, teams_enabled: false) }
    let!(:championship_2)    { FactoryBot.create(:championship, teams_enabled: true) }
    let!(:user)              { FactoryBot.create(:user) }
    let!(:user_championship) { FactoryBot.create(:user_championship, user: user, championship: championship_1) }
    let!(:team)              { FactoryBot.create(:team) }
    let!(:team_member)       { FactoryBot.create(:team_member, team: team, user: user) }
    let!(:team_registration) { FactoryBot.create(:team_registration, team: team, championship: championship_2) }

    it { expect(championship_1.participant_registrations).to eq([user_championship]) }
    it { expect(championship_2.participant_registrations).to eq([team_registration]) }
  end

  describe '#start_date' do
    let!(:championship) { FactoryBot.create(:championship) }
    let!(:race)         { FactoryBot.create(:race, championship: championship, starts_at: 1.week.from_now) }

    it { expect(championship.start_date).to be_within(1.minute).of(race.starts_at) }
  end

  describe '#team_registration_by_user' do
    let!(:championship)        { FactoryBot.create(:championship) }
    let!(:user_1)              { FactoryBot.create(:user) }
    let!(:user_2)              { FactoryBot.create(:user) }
    let!(:user_3)              { FactoryBot.create(:user) }
    let!(:team_1)              { FactoryBot.create(:team) }
    let!(:team_2)              { FactoryBot.create(:team) }
    let!(:team_member_1)       { FactoryBot.create(:team_member, team: team_1, user: user_1) }
    let!(:team_member_1_2)     { FactoryBot.create(:team_member, team: team_1, user: user_3) }
    let!(:team_member_2)       { FactoryBot.create(:team_member, team: team_2, user: user_2) }
    let!(:team_member_2_2)     { FactoryBot.create(:team_member, team: team_2, user: user_3) }
    let!(:team_registration_1) { FactoryBot.create(:team_registration, team: team_1, championship: championship, participating_driver_ids: [user_1.id.to_s]) }
    let!(:team_registration_2) { FactoryBot.create(:team_registration, team: team_2, championship: championship, participating_driver_ids: [user_2.id.to_s, user_3.id.to_s]) }

    it { expect(championship.team_registration_by_user(user_1, true)).to eq(team_registration_1) }
    it { expect(championship.team_registration_by_user(user_2, true)).to eq(team_registration_2) }
    it { expect(championship.team_registration_by_user(user_3, true)).to eq(team_registration_2) }
  end

  describe '#user_registered?' do
    let!(:user)              { FactoryBot.create(:user) }
    let!(:user_2)            { FactoryBot.create(:user) }
    let!(:championship)      { FactoryBot.create(:championship) }
    let!(:user_championship) { FactoryBot.create(:user_championship, championship: championship, user: user) }

    it { expect(championship.user_registered?(user)).to be(true) }
    it { expect(championship.user_registered?(user_2)).to be(false) }
  end

end
