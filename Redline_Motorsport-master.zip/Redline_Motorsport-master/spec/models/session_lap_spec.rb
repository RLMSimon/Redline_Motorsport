require 'rails_helper'

RSpec.describe SessionLap, type: :model do
  
  it { should belong_to(:race) }

  it { should validate_presence_of(:race_id) }
  it { should validate_presence_of(:session_type) }
  
end
