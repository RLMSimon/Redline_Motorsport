FactoryBot.define do
  factory :car_class do
    game    
    name { Faker::Games::Pokemon.location + Random.rand(1000).to_s }
  end
end
