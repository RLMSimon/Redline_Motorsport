FactoryBot.define do
  factory :race do
    championship
    starts_at { Time.now }
    track { Faker::Demographic.demonym }
  end
end
