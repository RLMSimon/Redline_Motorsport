FactoryBot.define do
  factory :team_member do
    team
    user
  end
end
