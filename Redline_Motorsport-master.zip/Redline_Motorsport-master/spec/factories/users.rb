FactoryBot.define do
  factory :user do
    username { Faker::Internet.username(specifier: 15) }
    email { Faker::Internet.email }
    password { 'testing' }
  end
end
