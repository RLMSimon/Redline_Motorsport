FactoryBot.define do
  factory :affiliate do
    name { "MyString" }
    description { "MyString" }
    url { "MyString" }
  end
end
