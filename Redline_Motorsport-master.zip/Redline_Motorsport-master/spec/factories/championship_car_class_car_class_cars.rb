FactoryBot.define do
  factory :championship_car_class_car_class_car do
    championship_car_class
    car_class_car
  end
end
