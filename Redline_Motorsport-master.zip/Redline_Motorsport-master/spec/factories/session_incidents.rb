FactoryBot.define do
  factory :session_incident do
    car_class
    race
    session_type { 1 }
    description { "MyString" }
    reviewed { false }
    
    for_user

    trait :for_user do
      association :sessionable, factory: :user
    end
  end
end
