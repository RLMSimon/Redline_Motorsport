FactoryBot.define do
  factory :session_lap do
    car_class
    race
    session_type { 1 }
    times {{ lap_time: 1, sectors: [1, 1, 1] }}
    
    for_user

    trait :for_user do
      association :sessionable, factory: :user
    end
  end
end
