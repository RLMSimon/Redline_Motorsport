FactoryBot.define do
  factory :team_registration do
    car_class
    championship
    team
    car
    car_number { Faker::Number.number(digits: 5) }
  end
end
