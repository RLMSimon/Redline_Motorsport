FactoryBot.define do
  factory :car do
    championship
    game
    name { Faker::Vehicle.make_and_model + Random.rand(1000).to_s }
  end
end
