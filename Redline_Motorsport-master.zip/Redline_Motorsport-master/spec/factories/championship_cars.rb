FactoryBot.define do
  factory :championship_car do
    championship
    car
  end
end
