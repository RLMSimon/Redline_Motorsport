FactoryBot.define do
  factory :championship_car_class do
    championship
    car_class
    capacity { 10 }
  end
end
