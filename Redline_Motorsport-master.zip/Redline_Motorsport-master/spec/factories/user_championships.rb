FactoryBot.define do
  factory :user_championship do
    car_class
    championship
    user
    car
    car_number { Faker::Number.number(digits: 3) }
  end
end
