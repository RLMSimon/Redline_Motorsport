FactoryBot.define do
  factory :team do
    name { Faker::Games::SuperSmashBros.fighter.gsub('.', '-') + Random.rand(1000).to_s}
  end
end
