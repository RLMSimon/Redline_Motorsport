FactoryBot.define do
  factory :championship do
    game
  end
end
