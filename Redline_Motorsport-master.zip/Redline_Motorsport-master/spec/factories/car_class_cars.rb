FactoryBot.define do
  factory :car_class_car do
    car
    car_class
  end
end
