FactoryBot.define do
  factory :session_result do
    car_class
    race
    session_type  { 1 }
    
    for_user

    trait :for_user do
      association :sessionable, factory: :user
    end

    trait :for_team do
      association :sessionable, factory: :team
    end
  end
end
