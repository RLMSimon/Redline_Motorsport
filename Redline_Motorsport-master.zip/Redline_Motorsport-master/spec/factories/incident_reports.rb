FactoryBot.define do
  factory :incident_report do
    race
    user
    # driver_a
    # driver_b
    incident_time { "MyString" }
    video_url { "MyString" }
    description { "MyText" }
  end
end
