FactoryBot.define do
  factory :game do
    name { Faker::Dessert.topping }
  end
end
