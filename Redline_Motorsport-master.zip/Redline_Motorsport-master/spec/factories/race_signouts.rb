FactoryBot.define do
  factory :race_signout do
    race

    for_user_championship

    trait :for_user_championship do
      association :signoutable, factory: :user_championship
    end
  end
end
